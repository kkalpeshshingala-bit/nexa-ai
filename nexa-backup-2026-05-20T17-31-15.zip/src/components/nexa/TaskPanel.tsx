'use client'

import { useNexaStore, type NexaTask } from '@/lib/nexa-store'
import { Timer, ExternalLink, Search, Music, Phone, MessageCircle, StickyNote, Mail, MessageSquare, MapPin, CheckCircle2, Loader2, X, Trash2, Zap } from 'lucide-react'

function getTaskIcon(type: string) {
  switch (type) {
    case 'open': return ExternalLink
    case 'search': return Search
    case 'whatsapp': return MessageCircle
    case 'call': return Phone
    case 'sms': return MessageSquare
    case 'email': return Mail
    case 'timer': return Timer
    case 'map': return MapPin
    case 'play': return Music
    case 'note': return StickyNote
    default: return Zap
  }
}

function getStatusColor(status: NexaTask['status']) {
  switch (status) {
    case 'pending': return '#FFB74D'
    case 'running': return '#40C4FF'
    case 'completed': return '#4CAF50'
    case 'failed': return '#FF1744'
  }
}

function getStatusLabel(status: NexaTask['status']) {
  switch (status) {
    case 'pending': return 'Pending'
    case 'running': return 'Running'
    case 'completed': return 'Done'
    case 'failed': return 'Failed'
  }
}

export default function TaskPanel() {
  const tasks = useNexaStore((s) => s.tasks)
  const clearCompletedTasks = useNexaStore((s) => s.clearCompletedTasks)
  const removeTask = useNexaStore((s) => s.removeTask)

  const activeTasks = tasks.filter(t => t.status === 'running' || t.status === 'pending')
  const completedTasks = tasks.filter(t => t.status === 'completed' || t.status === 'failed')

  if (tasks.length === 0) return null

  return (
    <div className="w-full">
      {/* Active task cards */}
      {activeTasks.length > 0 && (
        <div className="flex flex-col gap-1.5">
          {/* Active tasks header */}
          <div className="flex items-center gap-2 mb-1">
            <div className="flex items-center gap-1.5">
              <Zap className="size-3" style={{ color: '#40C4FF' }} />
              <span className="text-[10px] font-bold tracking-wider uppercase" style={{ color: '#40C4FF' }}>
                {activeTasks.length} Task{activeTasks.length > 1 ? 's' : ''} Active
              </span>
            </div>
            <div className="flex-1 h-px" style={{ background: 'rgba(64,196,255,0.2)' }} />
          </div>

          {activeTasks.map((task) => {
            const Icon = getTaskIcon(task.type)
            const color = getStatusColor(task.status)
            return (
              <div
                key={task.id}
                className="flex items-center gap-2.5 px-3 py-2 rounded-xl animate-slide-up"
                style={{
                  background: `linear-gradient(135deg, ${color}10 0%, ${color}05 100%)`,
                  border: `1px solid ${color}30`,
                  backdropFilter: 'blur(10px)',
                }}
              >
                {/* Status spinner / icon */}
                <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${color}20` }}>
                  {task.status === 'running' && task.type !== 'timer' ? (
                    <Loader2 className="size-3.5 animate-spin" style={{ color }} />
                  ) : task.status === 'completed' ? (
                    <CheckCircle2 className="size-3.5" style={{ color }} />
                  ) : (
                    <Icon className="size-3.5" style={{ color }} />
                  )}
                </div>

                {/* Label */}
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white truncate">{task.label}</p>
                  <p className="text-[9px] font-medium uppercase tracking-wider" style={{ color }}>
                    {getStatusLabel(task.status)}
                  </p>
                </div>

                {/* Progress bar for timers */}
                {task.type === 'timer' && task.progress !== undefined && task.status === 'running' && (
                  <div className="w-14 h-1.5 rounded-full overflow-hidden flex-shrink-0" style={{ background: `${color}20` }}>
                    <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${task.progress}%`, background: `linear-gradient(90deg, ${color}, #FF1744)` }} />
                  </div>
                )}

                {/* Remove button */}
                <button onClick={() => removeTask(task.id)} className="p-1 rounded-lg hover:bg-white/5 transition-colors flex-shrink-0">
                  <X className="size-3 text-gray-600 hover:text-gray-400" />
                </button>
              </div>
            )
          })}
        </div>
      )}

      {/* Completed tasks (collapsed) */}
      {completedTasks.length > 0 && activeTasks.length === 0 && (
        <div className="flex items-center gap-2 px-2">
          <div className="flex -space-x-1">
            {completedTasks.slice(-4).map((task) => {
              const Icon = getTaskIcon(task.type)
              const color = getStatusColor(task.status)
              return (
                <div key={task.id} className="w-5 h-5 rounded-full flex items-center justify-center border border-[#0a0a0a]" style={{ background: `${color}20` }}>
                  <Icon className="size-2.5" style={{ color }} />
                </div>
              )
            })}
          </div>
          <span className="text-[9px] text-gray-500">
            {completedTasks.length} task{completedTasks.length > 1 ? 's' : ''} done
          </span>
          <button onClick={clearCompletedTasks} className="p-1 rounded hover:bg-white/5 transition-colors">
            <Trash2 className="size-2.5 text-gray-600 hover:text-gray-400" />
          </button>
        </div>
      )}
    </div>
  )
}
