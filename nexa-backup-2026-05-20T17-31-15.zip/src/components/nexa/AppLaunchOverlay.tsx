'use client'

import { useEffect, useState } from 'react'
import type { NexaAction, AppMatchInfo } from '@/lib/nexa-actions'
import { ExternalLink, Search, X, Zap, Check, Copy, ArrowRight } from 'lucide-react'

interface AppLaunchOverlayProps {
  action: NexaAction
  onDismiss: () => void
  onOpenUrl: (url: string) => void
  autoOpened?: boolean  // If true, the app was already opened — show success
}

// App launch overlay with multiple open methods for sandbox compatibility
export default function AppLaunchOverlay({ action, onDismiss, onOpenUrl, autoOpened }: AppLaunchOverlayProps) {
  const matches = action.matches || []
  const initialPhase = matches.length > 1 ? 'multiplematch' 
    : action.type === 'appnotfound' ? 'notfound' 
    : autoOpened ? 'opened' 
    : 'ready'
  const [phase, setPhase] = useState<'ready' | 'opened' | 'notfound' | 'multiplematch'>(initialPhase)
  const [copied, setCopied] = useState(false)
  const appName = action.label.replace(/Opening\s*/i, '').replace(/Launching\s*/i, '').replace(/Starting\s*/i, '').trim()
  const icon = action.icon || '🔮'
  const category = action.category || ''
  const url = action.url || action.appUrl || ''

  // Auto-dismiss after successful opening
  useEffect(() => {
    if (phase === 'opened') {
      const timer = setTimeout(onDismiss, 2500)
      return () => clearTimeout(timer)
    }
  }, [phase, onDismiss])

  // Copy URL to clipboard
  const handleCopyLink = async () => {
    if (!url) return
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Fallback for older browsers
      const textArea = document.createElement('textarea')
      textArea.value = url
      textArea.style.position = 'fixed'
      textArea.style.left = '-9999px'
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand('copy')
      document.body.removeChild(textArea)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  // Open in this tab (always works, even in sandbox iframes)
  const handleOpenHere = () => {
    if (url) {
      window.location.href = url
    }
  }

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(12px)' }}
      onClick={phase === 'multiplematch' || phase === 'notfound' || phase === 'ready' ? onDismiss : undefined}
    >
      <div
        className="relative w-full max-w-sm mx-4 rounded-3xl overflow-hidden animate-slide-up"
        style={{
          background: 'linear-gradient(135deg, #0d0d0d 0%, #1a0a1a 50%, #0d0d0d 100%)',
          border: '1px solid rgba(255,23,68,0.3)',
          boxShadow: '0 0 60px rgba(255,23,68,0.15), 0 0 120px rgba(213,0,249,0.08)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* ===== READY TO OPEN PHASE ===== */}
        {phase === 'ready' && (
          <div className="px-6 py-7 flex flex-col items-center">
            {/* App icon with glow */}
            <div className="relative mb-4">
              <div
                className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl"
                style={{
                  background: 'linear-gradient(135deg, rgba(255,23,68,0.15) 0%, rgba(213,0,249,0.15) 100%)',
                  border: '1px solid rgba(255,23,68,0.3)',
                  boxShadow: '0 0 30px rgba(255,23,68,0.15)',
                }}
              >
                {icon}
              </div>
            </div>

            <h2 className="text-lg font-bold text-white mb-0.5 text-center">
              {appName}
            </h2>
            {category && (
              <span className="text-[10px] uppercase tracking-widest mb-3" style={{ color: '#FF6D6D' }}>
                {category}
              </span>
            )}

            {/* PRIMARY: Open in this tab — ALWAYS works! */}
            {url && (
              <button
                onClick={handleOpenHere}
                className="flex items-center gap-3 px-8 py-4 rounded-2xl text-base font-bold mb-3 transition-all hover:scale-[1.03] active:scale-[0.97] w-full justify-center"
                style={{
                  background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)',
                  color: 'white',
                  boxShadow: '0 6px 25px rgba(255,23,68,0.5)',
                }}
              >
                <ArrowRight className="size-5" />
                Open {appName}
              </button>
            )}

            {/* SECONDARY: Try new tab (works in standalone browser) */}
            {url && (
              <a
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium no-underline mb-2 transition-all hover:scale-[1.02] active:scale-[0.98] w-full justify-center"
                style={{
                  background: 'rgba(255,255,255,0.06)',
                  border: '1px solid rgba(255,255,255,0.12)',
                  color: '#ccc',
                }}
              >
                <ExternalLink className="size-4" />
                Open in new tab
              </a>
            )}

            {/* Copy link button */}
            {url && (
              <button
                onClick={handleCopyLink}
                className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-medium mb-3 transition-all hover:scale-[1.02]"
                style={{
                  background: copied ? 'rgba(76,175,80,0.15)' : 'rgba(255,255,255,0.04)',
                  border: copied ? '1px solid rgba(76,175,80,0.3)' : '1px solid rgba(255,255,255,0.06)',
                  color: copied ? '#4CAF50' : '#888',
                }}
              >
                {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
                {copied ? 'Link copied!' : 'Copy link'}
              </button>
            )}

            {/* URL display for manual copy */}
            {url && (
              <div 
                className="w-full px-3 py-2 rounded-lg mb-3 text-center"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <p className="text-[10px] text-gray-600 break-all font-mono">{url}</p>
              </div>
            )}

            <button onClick={onDismiss} className="text-xs text-gray-500 hover:text-gray-300">
              Cancel
            </button>
          </div>
        )}

        {/* ===== OPENED PHASE ===== */}
        {phase === 'opened' && (
          <div className="px-6 py-8 flex flex-col items-center">
            <div
              className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mb-4"
              style={{
                background: 'linear-gradient(135deg, rgba(76,175,80,0.2) 0%, rgba(0,188,212,0.2) 100%)',
                border: '1px solid rgba(76,175,80,0.4)',
                animation: 'scale-in 0.3s ease-out',
              }}
            >
              <Check className="size-10 text-green-400" />
            </div>
            <h2 className="text-lg font-bold text-white mb-1 text-center">
              {appName} Launched!
            </h2>
            <p className="text-xs text-gray-400 text-center mb-3">App is opening...</p>
            {/* Show Open button in case new tab was blocked */}
            {url && (
              <button
                onClick={handleOpenHere}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold mb-2 transition-all hover:scale-[1.02]"
                style={{
                  background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)',
                  color: 'white',
                  boxShadow: '0 4px 15px rgba(255,23,68,0.4)',
                }}
              >
                <ArrowRight className="size-3.5" />
                Open here if not loaded
              </button>
            )}
          </div>
        )}

        {/* ===== APP NOT FOUND PHASE ===== */}
        {phase === 'notfound' && (
          <div className="px-6 py-8 flex flex-col items-center">
            <div
              className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mb-4"
              style={{
                background: 'linear-gradient(135deg, rgba(255,23,68,0.15) 0%, rgba(255,87,34,0.15) 100%)',
                border: '1px solid rgba(255,23,68,0.3)',
              }}
            >
              ❓
            </div>
            <h2 className="text-lg font-bold text-white mb-1 text-center">
              App not found
            </h2>
            <p className="text-sm text-gray-400 text-center mb-4">
              &quot;{action.data || action.query}&quot; was not recognized.
            </p>
            <div className="flex gap-2">
              {url && (
                <a
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium no-underline"
                  style={{
                    background: 'rgba(255,255,255,0.08)',
                    border: '1px solid rgba(255,255,255,0.15)',
                    color: '#ccc',
                  }}
                  onClick={onDismiss}
                >
                  <Search className="size-3" />
                  Search Google
                </a>
              )}
              <button
                onClick={onDismiss}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium"
                style={{
                  background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)',
                  color: 'white',
                }}
              >
                <X className="size-3" />
                Close
              </button>
            </div>
          </div>
        )}

        {/* ===== MULTIPLE MATCH PHASE ===== */}
        {phase === 'multiplematch' && (
          <div className="px-6 py-6">
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
                style={{ background: 'rgba(255,23,68,0.15)', border: '1px solid rgba(255,23,68,0.3)' }}
              >
                {icon}
              </div>
              <div>
                <h2 className="text-sm font-bold text-white">Multiple apps found</h2>
                <p className="text-[10px] text-gray-400">Select the app you want to open</p>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              {matches.map((match: AppMatchInfo, i: number) => (
                <button
                  key={match.key}
                  onClick={() => {
                    const matchUrl = match.webUrl || match.appUrl
                    if (matchUrl) {
                      // Open in this tab — always works
                      window.location.href = matchUrl
                    }
                    onDismiss()
                  }}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all hover:scale-[1.02] active:scale-[0.98]"
                  style={{
                    background: i === 0 ? 'linear-gradient(135deg, rgba(255,23,68,0.15) 0%, rgba(213,0,249,0.15) 100%)' : 'rgba(255,255,255,0.05)',
                    border: i === 0 ? '1px solid rgba(255,23,68,0.3)' : '1px solid rgba(255,255,255,0.08)',
                  }}
                >
                  <span className="text-2xl">{match.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{match.name}</p>
                    <p className="text-[10px] text-gray-500 uppercase tracking-wider">{match.category}</p>
                  </div>
                  <ArrowRight className="size-4 text-gray-500 flex-shrink-0" />
                </button>
              ))}
            </div>

            <button onClick={onDismiss} className="mt-3 w-full text-center text-xs text-gray-500 hover:text-gray-300">
              Cancel
            </button>
          </div>
        )}

        {/* CSS Animations */}
        <style jsx>{`
          @keyframes scale-in {
            from { transform: scale(0.5); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
          }
          @keyframes slide-up {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
          .animate-slide-up {
            animation: slide-up 0.3s ease-out;
          }
        `}</style>
      </div>
    </div>
  )
}
