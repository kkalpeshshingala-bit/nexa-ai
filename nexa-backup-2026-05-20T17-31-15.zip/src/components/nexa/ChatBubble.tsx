'use client'

import { memo, useState } from 'react'
import type { ChatAction } from '@/lib/nexa-store'
import { ExternalLink, MessageCircle, Mail, Phone, Music, MapPin, Search, StickyNote, Timer, Download, Palette } from 'lucide-react'

interface ChatBubbleProps {
  message: {
    text: string
    isUser: boolean
    timestamp: number
    actions?: ChatAction[]
    imageUrl?: string
  }
}

function formatTime(timestamp: number): string {
  const date = new Date(timestamp)
  const h = date.getHours().toString().padStart(2, '0')
  const m = date.getMinutes().toString().padStart(2, '0')
  return `${h}:${m}`
}

// Get icon for action type
function getActionIcon(type: string) {
  switch (type) {
    case 'open': return ExternalLink
    case 'search': return Search
    case 'whatsapp': return MessageCircle
    case 'message': return MessageCircle
    case 'call': return Phone
    case 'sms': return MessageCircle
    case 'email': return Mail
    case 'timer': return Timer
    case 'map': return MapPin
    case 'play': return Music
    case 'note': return StickyNote
    case 'generate_image': return Palette
    default: return ExternalLink
  }
}

// AI-generated image component with fullscreen view
function GeneratedImage({ src, alt }: { src: string; alt: string }) {
  const [fullscreen, setFullscreen] = useState(false)
  const [loaded, setLoaded] = useState(false)

  return (
    <>
      <div className="mt-2 rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,23,68,0.3)' }}>
        {!loaded && (
          <div className="w-full aspect-square flex items-center justify-center" style={{ background: 'rgba(255,23,68,0.1)' }}>
            <div className="flex flex-col items-center gap-2">
              <Palette className="size-8 animate-pulse" style={{ color: '#FF1744' }} />
              <span className="text-xs text-gray-500">Loading image...</span>
            </div>
          </div>
        )}
        <img
          src={src}
          alt={alt}
          className={`w-full rounded-xl cursor-pointer hover:opacity-90 transition-opacity ${loaded ? '' : 'hidden'}`}
          onClick={() => setFullscreen(true)}
          onLoad={() => setLoaded(true)}
        />
        {loaded && (
          <div className="flex items-center justify-between px-3 py-2" style={{ background: 'rgba(0,0,0,0.3)' }}>
            <span className="text-[10px] text-gray-500">🎨 AI Generated</span>
            <div className="flex gap-2">
              <button
                onClick={() => setFullscreen(true)}
                className="text-[10px] px-2 py-1 rounded-md hover:bg-white/10 transition-colors"
                style={{ color: '#FF1744', border: '1px solid rgba(255,23,68,0.3)' }}
              >
                Fullscreen
              </button>
              <a
                href={src}
                download={`nexa-image-${Date.now()}.png`}
                className="text-[10px] px-2 py-1 rounded-md hover:bg-white/10 transition-colors flex items-center gap-1"
                style={{ color: '#4CAF50', border: '1px solid rgba(76,175,80,0.3)' }}
              >
                <Download className="size-3" />
                Save
              </a>
            </div>
          </div>
        )}
      </div>

      {/* Fullscreen overlay */}
      {fullscreen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.9)' }}
          onClick={() => setFullscreen(false)}
        >
          <img
            src={src}
            alt={alt}
            className="max-w-full max-h-full object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            onClick={() => setFullscreen(false)}
            className="absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center text-white text-xl"
            style={{ background: 'rgba(255,23,68,0.5)' }}
          >
            ✕
          </button>
          <a
            href={src}
            download={`nexa-image-${Date.now()}.png`}
            className="absolute bottom-4 right-4 flex items-center gap-2 px-4 py-2 rounded-xl text-white text-sm font-medium"
            style={{ background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <Download className="size-4" />
            Save Image
          </a>
        </div>
      )}
    </>
  )
}

const ChatBubble = memo(function ChatBubble({ message }: ChatBubbleProps) {
  const { text, isUser, timestamp, actions, imageUrl } = message
  const hasActions = actions && actions.length > 0
  const hasImage = !!imageUrl

  if (isUser) {
    return (
      <div className="flex justify-end mb-3">
        <div className="max-w-[80%] flex flex-col items-end">
          <div
            className="px-4 py-3 rounded-2xl rounded-tr-sm text-sm leading-relaxed"
            style={{
              backgroundColor: '#1a0000',
              border: '1px solid #FF1744',
              color: '#EEEEEE',
            }}
          >
            {text}
          </div>
          <span className="text-xs mt-1 px-1" style={{ color: '#666666' }}>
            {formatTime(timestamp)}
          </span>
        </div>
      </div>
    )
  }

  return (
    <div className="flex justify-start mb-3">
      <div className="max-w-[80%] flex flex-row items-end gap-2">
        {/* Small red dot avatar */}
        <div
          className="w-6 h-6 rounded-full flex-shrink-0 mb-5 flex items-center justify-center"
          style={{
            background: 'radial-gradient(circle, #FF1744 0%, #880E4F 100%)',
            boxShadow: '0 0 8px rgba(255,23,68,0.4)',
          }}
        >
          <div className="w-2 h-2 rounded-full bg-white/20" />
        </div>
        <div className="flex flex-col">
          <div
            className="px-4 py-3 rounded-2xl rounded-tl-sm text-sm leading-relaxed"
            style={{
              backgroundColor: '#111111',
              color: '#EEEEEE',
            }}
          >
            {text}
          </div>

          {/* AI-GENERATED IMAGE */}
          {hasImage && <GeneratedImage src={imageUrl!} alt={text} />}

          {/* ACTION CARDS — clickable links that ALWAYS work (user gesture!) */}
          {hasActions && (
            <div className="flex flex-col gap-1.5 mt-2">
              {actions.map((action, idx) => {
                const ActionIcon = getActionIcon(action.type)
                const actionUrl = action.url
                const isClickable = !!actionUrl && action.type !== 'timer' && action.type !== 'note' && action.type !== 'generate_image'

                if (isClickable) {
                  return (
                    <button
                      key={idx}
                      onClick={() => { window.location.href = actionUrl! }}
                      className="flex items-center gap-3 px-4 py-3 rounded-xl no-underline transition-all hover:scale-[1.02] active:scale-[0.98] animate-action-glow w-full text-left"
                      style={{
                        background: 'linear-gradient(135deg, rgba(255,23,68,0.25) 0%, rgba(213,0,249,0.25) 100%)',
                        border: '1.5px solid rgba(255,23,68,0.5)',
                        color: 'white',
                        boxShadow: '0 0 15px rgba(255,23,68,0.2), 0 0 30px rgba(213,0,249,0.1)',
                      }}
                    >
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: 'linear-gradient(135deg, rgba(255,23,68,0.35) 0%, rgba(213,0,249,0.35) 100%)' }}>
                        <ActionIcon className="size-5" style={{ color: '#FF1744' }} />
                      </div>
                      <span className="text-sm font-semibold flex-1 truncate">{action.label}</span>
                      <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl flex-shrink-0"
                        style={{
                          background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)',
                          boxShadow: '0 2px 15px rgba(255,23,68,0.5)',
                          animation: 'pulse-glow 2s ease-in-out infinite',
                        }}>
                        <ExternalLink className="size-4 text-white" />
                        <span className="text-sm font-bold text-white">OPEN</span>
                      </div>
                    </button>
                  )
                }

                // Non-clickable actions (timer, note, generate_image) — just show info
                return (
                  <div
                    key={idx}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl"
                    style={{
                      background: 'rgba(255,23,68,0.1)',
                      border: '1px solid rgba(255,23,68,0.2)',
                    }}
                  >
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: 'rgba(255,23,68,0.2)' }}>
                      <ActionIcon className="size-3.5" style={{ color: '#FF1744' }} />
                    </div>
                    <span className="text-xs font-medium text-gray-300">{action.label}</span>
                  </div>
                )
              })}
            </div>
          )}

          <span className="text-xs mt-1 px-1" style={{ color: '#666666' }}>
            {formatTime(timestamp)}
          </span>
        </div>
      </div>
      <style jsx>{`
        @keyframes action-glow {
          0%, 100% { box-shadow: 0 0 15px rgba(255,23,68,0.2), 0 0 30px rgba(213,0,249,0.1); }
          50% { box-shadow: 0 0 20px rgba(255,23,68,0.4), 0 0 40px rgba(213,0,249,0.2); }
        }
        .animate-action-glow {
          animation: action-glow 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  )
})

export default ChatBubble
