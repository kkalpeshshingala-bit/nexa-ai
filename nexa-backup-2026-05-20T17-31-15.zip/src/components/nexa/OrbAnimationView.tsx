'use client'

import { useRef, useEffect, useCallback } from 'react'
import type { OrbState } from '@/lib/nexa-store'

interface OrbAnimationViewProps {
  state: OrbState
  amplitude: number // 0-1 for audio reactivity
}

interface ColorPair {
  inner: string
  outer: string
}

const STATE_COLORS: Record<OrbState, ColorPair> = {
  idle: { inner: '#B71C1C', outer: '#880E4F' },
  listening: { inner: '#FF1744', outer: '#D500F9' },
  speaking: { inner: '#E040FB', outer: '#FF1744' },
  thinking: { inner: '#40C4FF', outer: '#00B0FF' },
  active: { inner: '#FF1744', outer: '#D500F9' },
}

function hexToRgba(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return `rgba(${r},${g},${b},${alpha})`
}

export default function OrbAnimationView({ state, amplitude }: OrbAnimationViewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)
  const timeRef = useRef<number>(0)
  const scaleRef = useRef<number>(1)
  const sizeRef = useRef<{ w: number; h: number }>({ w: 300, h: 300 })
  const amplitudeRef = useRef(amplitude)
  const stateRef = useRef(state)

  // Keep refs in sync via effect
  useEffect(() => {
    amplitudeRef.current = amplitude
    stateRef.current = state
  })

  // ResizeObserver for responsive sizing
  const containerRef = useRef<HTMLDivElement>(null)

  const setupCanvas = useCallback(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return

    const dpr = window.devicePixelRatio || 1
    const rect = container.getBoundingClientRect()
    const w = rect.width
    const h = rect.height

    canvas.width = w * dpr
    canvas.height = h * dpr
    canvas.style.width = `${w}px`
    canvas.style.height = `${h}px`

    const ctx = canvas.getContext('2d')
    if (ctx) {
      ctx.scale(dpr, dpr)
    }

    sizeRef.current = { w, h }
  }, [])

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const observer = new ResizeObserver(() => {
      setupCanvas()
    })
    observer.observe(container)
    setupCanvas()

    return () => observer.disconnect()
  }, [setupCanvas])

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    let lastTime = performance.now()

    const animate = (now: number) => {
      const dt = (now - lastTime) / 1000
      lastTime = now
      timeRef.current += dt

      const ctx = canvas.getContext('2d')
      if (!ctx) {
        animRef.current = requestAnimationFrame(animate)
        return
      }

      const { w, h } = sizeRef.current
      const cx = w / 2
      const cy = h / 2
      const baseRadius = Math.min(w, h) * 0.25
      const currentState = stateRef.current
      const amp = amplitudeRef.current
      const t = timeRef.current

      ctx.clearRect(0, 0, w, h)

      const colors = STATE_COLORS[currentState]

      // Idle pulse: scale 1 → 1.15 → 1 over 1500ms
      if (currentState === 'idle') {
        const pulse = Math.sin((t * Math.PI * 2) / 1.5) * 0.5 + 0.5 // 0..1 over 1500ms
        scaleRef.current = 1 + pulse * 0.15
      } else {
        scaleRef.current = 1 + amp * 0.08
      }

      const radius = baseRadius * scaleRef.current

      // ---- Layer 1: Radial glow (1.6x radius) ----
      const glowRadius = radius * 1.6
      const glowGrad = ctx.createRadialGradient(cx, cy, radius * 0.3, cx, cy, glowRadius)
      glowGrad.addColorStop(0, hexToRgba(colors.inner, 0.25 + amp * 0.15))
      glowGrad.addColorStop(0.5, hexToRgba(colors.outer, 0.1))
      glowGrad.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.beginPath()
      ctx.arc(cx, cy, glowRadius, 0, Math.PI * 2)
      ctx.fillStyle = glowGrad
      ctx.fill()

      // ---- Layer 2: Core orb (sphere illusion) ----
      const orbGrad = ctx.createRadialGradient(
        cx - radius * 0.25,
        cy - radius * 0.25,
        radius * 0.1,
        cx,
        cy,
        radius
      )
      orbGrad.addColorStop(0, hexToRgba(colors.inner, 0.95))
      orbGrad.addColorStop(0.6, hexToRgba(colors.outer, 0.85))
      orbGrad.addColorStop(1, hexToRgba(colors.outer, 0.3))
      ctx.beginPath()
      ctx.arc(cx, cy, radius, 0, Math.PI * 2)
      ctx.fillStyle = orbGrad
      ctx.fill()

      // ---- Layer 3: 3 rotating rings (dashed arcs) ----
      const ringStates: OrbState[] = ['listening', 'speaking', 'active']
      if (ringStates.includes(currentState) || currentState === 'idle') {
        const ringColors = [colors.inner, colors.outer, hexToRgba(colors.inner, 0.6)]
        const ringRadii = [radius * 1.2, radius * 1.35, radius * 1.5]
        const ringSpeeds = [0.5, -0.7, 0.3]

        for (let i = 0; i < 3; i++) {
          const ringRadius = ringRadii[i]
          const rotation = t * ringSpeeds[i]
          ctx.save()
          ctx.translate(cx, cy)
          ctx.rotate(rotation)
          ctx.beginPath()
          ctx.arc(0, 0, ringRadius, 0, Math.PI * 2)
          ctx.strokeStyle = ringColors[i]
          ctx.lineWidth = 1.5
          ctx.setLineDash([8, 12])
          ctx.globalAlpha = currentState === 'idle' ? 0.3 : 0.6 + amp * 0.3
          ctx.stroke()
          ctx.setLineDash([])
          ctx.globalAlpha = 1
          ctx.restore()
        }
      }

      // ---- Layer 4: Wave rings (sine waves, amplitude-reactive) ----
      const waveStates: OrbState[] = ['listening', 'speaking', 'active']
      if (waveStates.includes(currentState)) {
        const waveCount = 3
        for (let w2 = 0; w2 < waveCount; w2++) {
          const waveRadius = radius * (1.15 + w2 * 0.12)
          const waveAmp = (3 + amp * 12) * (1 - w2 * 0.25)
          const waveSpeed = currentState === 'speaking' ? 4 : 2

          ctx.save()
          ctx.translate(cx, cy)
          ctx.beginPath()
          for (let a = 0; a <= Math.PI * 2; a += 0.03) {
            const sine = Math.sin(a * 6 + t * waveSpeed + w2) * waveAmp
            const rx = (waveRadius + sine) * Math.cos(a)
            const ry = (waveRadius + sine) * Math.sin(a)
            if (a === 0) ctx.moveTo(rx, ry)
            else ctx.lineTo(rx, ry)
          }
          ctx.closePath()
          ctx.strokeStyle = hexToRgba(colors.inner, 0.3 - w2 * 0.08)
          ctx.lineWidth = 1.2
          ctx.stroke()
          ctx.restore()
        }
      }

      // ---- Layer 5: Thinking arc (2 arcs spinning, only in thinking state) ----
      if (currentState === 'thinking') {
        const arcRadius = radius * 1.3
        const arcSpeed = 2.5

        for (let i = 0; i < 2; i++) {
          const startAngle = t * arcSpeed + i * Math.PI
          ctx.save()
          ctx.translate(cx, cy)
          ctx.beginPath()
          ctx.arc(0, 0, arcRadius, startAngle, startAngle + Math.PI * 0.7)
          ctx.strokeStyle = hexToRgba(colors.inner, 0.8)
          ctx.lineWidth = 3
          ctx.lineCap = 'round'
          ctx.stroke()
          ctx.restore()
        }

        // Secondary smaller arc
        const arcRadius2 = radius * 1.1
        for (let i = 0; i < 2; i++) {
          const startAngle = -t * arcSpeed * 1.3 + i * Math.PI
          ctx.save()
          ctx.translate(cx, cy)
          ctx.beginPath()
          ctx.arc(0, 0, arcRadius2, startAngle, startAngle + Math.PI * 0.5)
          ctx.strokeStyle = hexToRgba(colors.outer, 0.6)
          ctx.lineWidth = 2
          ctx.lineCap = 'round'
          ctx.stroke()
          ctx.restore()
        }
      }

      // ---- Layer 6: Particles (12 dots orbiting, active/speaking) ----
      const particleStates: OrbState[] = ['speaking', 'active']
      if (particleStates.includes(currentState)) {
        const particleCount = 12
        const orbitRadius = radius * 1.45

        for (let i = 0; i < particleCount; i++) {
          const angle = (Math.PI * 2 * i) / particleCount + t * 0.8
          const wobble = Math.sin(t * 3 + i * 0.5) * 4 * (1 + amp * 2)
          const px = cx + (orbitRadius + wobble) * Math.cos(angle)
          const py = cy + (orbitRadius + wobble) * Math.sin(angle)
          const dotSize = 2 + amp * 2

          ctx.beginPath()
          ctx.arc(px, py, dotSize, 0, Math.PI * 2)
          ctx.fillStyle = hexToRgba(
            i % 2 === 0 ? colors.inner : colors.outer,
            0.6 + amp * 0.4
          )
          ctx.fill()
        }
      }

      // ---- Layer 7: Inner highlight (white radial, top-left) ----
      const hlGrad = ctx.createRadialGradient(
        cx - radius * 0.3,
        cy - radius * 0.3,
        0,
        cx - radius * 0.15,
        cy - radius * 0.15,
        radius * 0.7
      )
      hlGrad.addColorStop(0, 'rgba(255,255,255,0.2)')
      hlGrad.addColorStop(0.5, 'rgba(255,255,255,0.05)')
      hlGrad.addColorStop(1, 'rgba(255,255,255,0)')
      ctx.beginPath()
      ctx.arc(cx, cy, radius, 0, Math.PI * 2)
      ctx.fillStyle = hlGrad
      ctx.fill()

      animRef.current = requestAnimationFrame(animate)
    }

    animRef.current = requestAnimationFrame(animate)

    return () => {
      if (animRef.current) {
        cancelAnimationFrame(animRef.current)
      }
    }
  }, [])

  return (
    <div
      ref={containerRef}
      className="w-full h-full min-h-[200px] min-w-[200px] flex items-center justify-center"
    >
      <canvas
        ref={canvasRef}
        className="block"
        aria-label={`NEXA orb animation - ${state} state`}
        role="img"
      />
    </div>
  )
}
