'use client'

import { useEffect, useRef, useCallback } from 'react'
import { useNexaStore } from '@/lib/nexa-store'

// Document Picture-in-Picture API types
interface DocumentPictureInPictureAPI {
  requestWindow: (options?: { width?: number; height?: number }) => Promise<Window>
}

interface WindowWithPiP extends Window {
  documentPictureInPicture?: DocumentPictureInPictureAPI
}

// Render content inside PiP window (extracted as standalone function)
function renderPiPContentToContainer(container: HTMLDivElement) {
  const state = useNexaStore.getState()
  const isRec = state.isRecording
  const isSpk = state.isSpeaking
  const orb = state.orbState
  const amp = state.amplitude
  const always = state.isAlwaysListening
  const screen = state.isScreenSharing
  const status = state.statusText
  const inTrans = state.inputTranscript
  const outTrans = state.outputTranscript

  // Determine orb color
  let orbColor = '#FF1744'
  let orbGlow = 'rgba(255,23,68,0.3)'
  if (isRec || orb === 'listening') { orbColor = '#FF1744'; orbGlow = 'rgba(255,23,68,0.5)' }
  else if (isSpk || orb === 'speaking') { orbColor = '#D500F9'; orbGlow = 'rgba(213,0,249,0.4)' }
  else if (orb === 'thinking') { orbColor = '#40C4FF'; orbGlow = 'rgba(64,196,255,0.4)' }
  else if (always || orb === 'active') { orbColor = '#4CAF50'; orbGlow = 'rgba(76,175,80,0.4)' }

  container.innerHTML = `
    <div style="width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px;">
      <!-- Top bar with controls -->
      <div style="display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 0 4px;">
        <div style="display: flex; align-items: center; gap: 6px;">
          <div style="width: 8px; height: 8px; border-radius: 50%; background: ${always ? '#4CAF50' : '#FF1744'}; ${always ? 'animation: pulse-subtle 2s ease-in-out infinite;' : ''}"></div>
          <span style="color: ${always ? '#4CAF50' : '#FF1744'}; font-size: 10px; font-weight: 600; letter-spacing: 0.1em;">NEXA</span>
        </div>
        <div style="display: flex; gap: 4px;">
          <button class="pip-btn" id="pip-screen-btn" style="width: 24px; height: 24px; border-radius: 6px; display: flex; align-items: center; justify-content: center; background: ${screen ? 'rgba(76,175,80,0.2)' : 'rgba(255,255,255,0.05)'};" title="Screen share">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${screen ? '#4CAF50' : '#888'}" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
          </button>
          <button class="pip-btn" id="pip-ear-btn" style="width: 24px; height: 24px; border-radius: 6px; display: flex; align-items: center; justify-content: center; background: ${always ? 'rgba(76,175,80,0.2)' : 'rgba(255,255,255,0.05)'};" title="Always listen">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${always ? '#4CAF50' : '#888'}" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
          </button>
          <button class="pip-btn" id="pip-close-btn" style="width: 24px; height: 24px; border-radius: 6px; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.05);" title="Close PiP">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#888" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      </div>

      <!-- Orb -->
      <div style="position: relative; width: 80px; height: 80px;">
        <div style="position: absolute; inset: 0; border-radius: 50%; background: radial-gradient(circle, ${orbColor} 0%, transparent 70%); opacity: 0.3; animation: orb-glow 2s ease-in-out infinite;"></div>
        <div style="position: absolute; inset: 8px; border-radius: 50%; background: radial-gradient(circle at 30% 30%, ${orbColor}, #111); box-shadow: 0 0 20px ${orbGlow};"></div>
        <button class="pip-btn" id="pip-mic-btn" style="position: absolute; inset: 16px; border-radius: 50%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; cursor: pointer;">
          ${isRec ?
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>' :
            '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2c0 .76-.12 1.49-.34 2.18"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>'
          }
        </button>
      </div>

      <!-- Status -->
      <div style="color: #FF6D6D; font-size: 10px; text-align: center;">${status}</div>

      <!-- Waveform bars -->
      <div style="display: flex; gap: 2px; height: 20px; align-items: center;">
        ${[1,2,3,4,5,6,7,8,7,6,5,4,3,2,1].map((h) =>
          `<div style="width: 3px; height: ${Math.max(4, amp * h * 18)}px; border-radius: 2px; background: ${orbColor}; opacity: 0.6; transition: height 0.1s;"></div>`
        ).join('')}
      </div>

      <!-- Transcripts -->
      ${(inTrans || outTrans) ? `
        <div style="max-width: 280px; text-align: center; overflow: hidden;">
          ${inTrans ? `<div style="color: #888; font-size: 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">You: ${inTrans}</div>` : ''}
          ${outTrans ? `<div style="color: #ccc; font-size: 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">NEXA: ${outTrans}</div>` : ''}
        </div>
      ` : ''}

      <!-- Screen sharing indicator -->
      ${screen ? `<div style="display: flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 10px; background: rgba(76,175,80,0.15);"><div style="width: 5px; height: 5px; border-radius: 50%; background: #4CAF50; animation: pulse-subtle 2s infinite;"></div><span style="color: #4CAF50; font-size: 8px;">Screen Sharing</span></div>` : ''}
    </div>
  `

  // Attach event listeners
  const micBtn = container.querySelector('#pip-mic-btn')
  const screenBtn = container.querySelector('#pip-screen-btn')
  const earBtn = container.querySelector('#pip-ear-btn')
  const closeBtn = container.querySelector('#pip-close-btn')

  micBtn?.addEventListener('click', () => {
    window.dispatchEvent(new CustomEvent('nexa-pip-mic-toggle'))
  })

  screenBtn?.addEventListener('click', () => {
    window.dispatchEvent(new CustomEvent('nexa-pip-screen-toggle'))
  })

  earBtn?.addEventListener('click', () => {
    window.dispatchEvent(new CustomEvent('nexa-pip-ear-toggle'))
  })

  closeBtn?.addEventListener('click', () => {
    window.dispatchEvent(new CustomEvent('nexa-pip-close'))
  })
}

export default function PiPWidget() {
  const pipWindowRef = useRef<Window | null>(null)
  const pipContainerRef = useRef<HTMLDivElement | null>(null)
  const isPiPMode = useNexaStore((s) => s.isPiPMode)
  const isRecording = useNexaStore((s) => s.isRecording)
  const isSpeaking = useNexaStore((s) => s.isSpeaking)
  const orbState = useNexaStore((s) => s.orbState)
  const amplitude = useNexaStore((s) => s.amplitude)
  const statusText = useNexaStore((s) => s.statusText)
  const isAlwaysListening = useNexaStore((s) => s.isAlwaysListening)
  const isScreenSharing = useNexaStore((s) => s.isScreenSharing)
  const inputTranscript = useNexaStore((s) => s.inputTranscript)
  const outputTranscript = useNexaStore((s) => s.outputTranscript)
  const messages = useNexaStore((s) => s.messages)

  const sa = {
    setMiniMode: (v: boolean) => useNexaStore.getState().setMiniMode(v),
    setPiPMode: (v: boolean) => useNexaStore.getState().setPiPMode(v),
  }

  // Create PiP window — checks iframe context at call time (client-only)
  const openPiP = useCallback(async () => {
    // Document PiP API requires top-level browsing context — skip in iframes
    if (window !== window.top) {
      console.log('[NEXA] Running in iframe — PiP not available, using floating widget fallback')
      sa.setMiniMode(true)
      return
    }

    const win = window as unknown as WindowWithPiP
    if (!win.documentPictureInPicture) {
      console.log('[NEXA] Document PiP API not supported, using floating widget fallback')
      sa.setMiniMode(true)
      return
    }

    try {
      const pipWindow = await win.documentPictureInPicture.requestWindow({
        width: 320,
        height: 240,
      })

      pipWindowRef.current = pipWindow

      // Style the PiP window
      const pipDoc = pipWindow.document
      pipDoc.head.innerHTML = ''
      pipDoc.body.innerHTML = ''
      pipDoc.body.style.margin = '0'
      pipDoc.body.style.padding = '0'
      pipDoc.body.style.background = '#050505'
      pipDoc.body.style.overflow = 'hidden'
      pipDoc.body.style.fontFamily = 'system-ui, -apple-system, sans-serif'

      // Add our container to PiP window
      const container = pipDoc.createElement('div')
      container.id = 'nexa-pip-root'
      container.style.cssText = `
        width: 100%; height: 100%; display: flex; flex-direction: column;
        align-items: center; justify-content: center; padding: 12px;
        position: relative; overflow: hidden;
      `
      pipDoc.body.appendChild(container)
      pipContainerRef.current = container

      // Add styles to PiP window
      const style = pipDoc.createElement('style')
      style.textContent = `
        @keyframes pulse-subtle {
          0%, 100% { box-shadow: 0 0 15px rgba(76,175,80,0.2); }
          50% { box-shadow: 0 0 25px rgba(76,175,80,0.5); }
        }
        @keyframes orb-glow {
          0%, 100% { transform: scale(1); opacity: 0.8; }
          50% { transform: scale(1.1); opacity: 1; }
        }
        .pip-btn { cursor: pointer; border: none; outline: none; transition: all 0.2s; }
        .pip-btn:hover { transform: scale(1.05); }
        .pip-btn:active { transform: scale(0.95); }
      `
      pipDoc.head.appendChild(style)

      // Render PiP content
      renderPiPContentToContainer(container)

      // Handle PiP window close
      pipWindow.addEventListener('pagehide', () => {
        pipWindowRef.current = null
        pipContainerRef.current = null
        sa.setPiPMode(false)
      })

      sa.setPiPMode(true)
    } catch (err) {
      console.error('[NEXA] PiP open error:', err)
      sa.setMiniMode(true)
    }
  }, [sa])

  // Handle PiP close event
  useEffect(() => {
    const handlePipClose = () => {
      if (pipWindowRef.current) {
        pipWindowRef.current.close()
        pipWindowRef.current = null
        pipContainerRef.current = null
        sa.setPiPMode(false)
      }
    }
    window.addEventListener('nexa-pip-close', handlePipClose)
    return () => window.removeEventListener('nexa-pip-close', handlePipClose)
  }, [sa])

  // Update PiP content when state changes
  useEffect(() => {
    if (!pipContainerRef.current || !isPiPMode) return

    const updateInterval = setInterval(() => {
      if (pipContainerRef.current) {
        renderPiPContentToContainer(pipContainerRef.current)
      }
    }, 500) // Update every 500ms

    return () => {
      clearInterval(updateInterval)
    }
  }, [isPiPMode, isRecording, isSpeaking, orbState, amplitude, statusText, isAlwaysListening, isScreenSharing, inputTranscript, outputTranscript, messages])

  // Listen for PiP events from parent
  useEffect(() => {
    const handleOpenPiP = () => {
      openPiP()
    }

    window.addEventListener('nexa-open-pip', handleOpenPiP)
    return () => {
      window.removeEventListener('nexa-open-pip', handleOpenPiP)
    }
  }, [openPiP])

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (pipWindowRef.current) {
        try { pipWindowRef.current.close() } catch {}
        pipWindowRef.current = null
        pipContainerRef.current = null
      }
    }
  }, [])

  // This component doesn't render anything in the main DOM
  // It manages the PiP window independently
  return null
}
