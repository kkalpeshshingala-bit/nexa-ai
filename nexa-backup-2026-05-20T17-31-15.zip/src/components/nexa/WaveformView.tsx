'use client'

import { useRef, useEffect, useCallback, useImperativeHandle, forwardRef } from 'react'

interface WaveformViewProps {
  amplitude: number
  isActive: boolean
}

export interface WaveformViewHandle {
  setAmplitude: (rms: number) => void
  startAnimation: () => void
  stopAnimation: () => void
}

const BAR_COUNT = 20

const WaveformView = forwardRef<WaveformViewHandle, WaveformViewProps>(
  function WaveformView({ amplitude, isActive }, ref) {
    const barHeightsRef = useRef<number[]>(new Array(BAR_COUNT).fill(0))
    const animFrameRef = useRef<number>(0)
    const isAnimatingRef = useRef(false)
    const amplitudeRef = useRef(amplitude)
    const isActiveRef = useRef(isActive)
    const animateRef = useRef<() => void>(() => {})

    // Keep refs in sync via effect
    useEffect(() => {
      amplitudeRef.current = amplitude
      isActiveRef.current = isActive
    })

    // Define the animate function via ref to avoid circular reference
    useEffect(() => {
      animateRef.current = () => {
        const bars = barHeightsRef.current
        const amp = amplitudeRef.current
        const active = isActiveRef.current

        // Compute targets
        const targets = new Array(BAR_COUNT)
        for (let i = 0; i < BAR_COUNT; i++) {
          if (!active) {
            targets[i] = 0.05
          } else {
            const center = BAR_COUNT / 2
            const dist = Math.abs(i - center) / center
            const base = (1 - dist * 0.5) * amp
            const noise = Math.random() * 0.15
            targets[i] = Math.max(0.05, base + noise * amp)
          }
        }

        // Lerp toward target
        for (let i = 0; i < BAR_COUNT; i++) {
          bars[i] += (targets[i] - bars[i]) * 0.3
        }

        // Update DOM
        const container = document.getElementById('waveform-bars')
        if (container) {
          const barEls = container.children
          for (let i = 0; i < barEls.length; i++) {
            const el = barEls[i] as HTMLElement
            const h = Math.max(2, bars[i] * 100)
            el.style.height = `${h}%`
            const alpha = Math.round(150 + bars[i] * 105)
            el.style.backgroundColor = `rgba(255,23,68,${alpha / 255})`
          }
        }

        if (isAnimatingRef.current) {
          animFrameRef.current = requestAnimationFrame(() => animateRef.current())
        }
      }
    }, [])

    const startAnimation = useCallback(() => {
      if (isAnimatingRef.current) return
      isAnimatingRef.current = true
      animFrameRef.current = requestAnimationFrame(() => animateRef.current())
    }, [])

    const stopAnimation = useCallback(() => {
      isAnimatingRef.current = false
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current)
      }
    }, [])

    const setAmplitude = useCallback((rms: number) => {
      amplitudeRef.current = Math.max(0, Math.min(1, rms))
    }, [])

    useImperativeHandle(ref, () => ({
      setAmplitude,
      startAnimation,
      stopAnimation,
    }))

    // Auto start/stop based on isActive
    useEffect(() => {
      startAnimation()
      return () => {
        stopAnimation()
      }
    }, [isActive, startAnimation, stopAnimation])

    return (
      <div className="flex items-center justify-center gap-[3px] h-16 w-full" id="waveform-bars">
        {Array.from({ length: BAR_COUNT }, (_, i) => (
          <div
            key={i}
            className="w-[3px] min-h-[2px] rounded-full transition-none"
            style={{
              height: '2%',
              backgroundColor: 'rgba(255,23,68,0.6)',
            }}
          />
        ))}
      </div>
    )
  }
)

WaveformView.displayName = 'WaveformView'

export default WaveformView
