'use client'

import { useState, useCallback } from 'react'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Eye, EyeOff, Plus, Trash2, Wifi, WifiOff, CheckCircle2, Download, Upload, Archive } from 'lucide-react'

export interface SettingsData {
  apiKey: string
  userName: string
  personalityMode: string
  geminiModel: string
  geminiVoice: string
  language: string
  primeContacts: Array<{ id: string; name: string; number: string }>
}

interface SettingsPanelProps {
  open: boolean
  onClose: () => void
  onSave: (settings: SettingsData) => void
  settings: SettingsData
  isConnected?: boolean
}

const AI_MODELS = [
  {
    label: 'Native Audio (Human Voice) — DEFAULT',
    value: 'models/gemini-2.5-flash-native-audio-preview-12-2025',
  },
  {
    label: 'Flash Live (Fast)',
    value: 'models/gemini-2.0-flash-live-001',
  },
  {
    label: 'Pro Audio Dialog',
    value: 'models/gemini-2.5-flash-preview-native-audio-dialog',
  },
]

const VOICES = ['Aoede', 'Charon', 'Kore', 'Fenrir', 'Puck', 'Leda', 'Orus', 'Zephyr']

const LANGUAGES = [
  { value: 'auto', label: 'Auto Detect', icon: '🌍', desc: 'Understands any language' },
  { value: 'hi-IN', label: 'Hindi', icon: '🇮🇳', desc: 'हिन्दी' },
  { value: 'en-IN', label: 'English (India)', icon: '🇮🇳', desc: 'English' },
  { value: 'gu-IN', label: 'Gujarati', icon: '🇮🇳', desc: 'ગુજરાતી' },
  { value: 'mr-IN', label: 'Marathi', icon: '🇮🇳', desc: 'मराठी' },
  { value: 'ta-IN', label: 'Tamil', icon: '🇮🇳', desc: 'தமிழ்' },
  { value: 'te-IN', label: 'Telugu', icon: '🇮🇳', desc: 'తెలుగు' },
  { value: 'bn-IN', label: 'Bengali', icon: '🇮🇳', desc: 'বাংলা' },
  { value: 'ur-IN', label: 'Urdu', icon: '🇮🇳', desc: 'اردو' },
  { value: 'pa-IN', label: 'Punjabi', icon: '🇮🇳', desc: 'ਪੰਜਾਬੀ' },
  { value: 'kn-IN', label: 'Kannada', icon: '🇮🇳', desc: 'ಕನ್ನಡ' },
  { value: 'ml-IN', label: 'Malayalam', icon: '🇮🇳', desc: 'മലയാളം' },
  { value: 'or-IN', label: 'Odia', icon: '🇮🇳', desc: 'ଓଡ଼ିଆ' },
  { value: 'as-IN', label: 'Assamese', icon: '🇮🇳', desc: 'অসমীয়া' },
  { value: 'ne-IN', label: 'Nepali', icon: '🇳🇵', desc: 'नेपाली' },
  { value: 'ja-JP', label: 'Japanese', icon: '🇯🇵', desc: '日本語' },
  { value: 'ko-KR', label: 'Korean', icon: '🇰🇷', desc: '한국어' },
  { value: 'zh-CN', label: 'Chinese', icon: '🇨🇳', desc: '中文' },
  { value: 'fr-FR', label: 'French', icon: '🇫🇷', desc: 'Français' },
  { value: 'de-DE', label: 'German', icon: '🇩🇪', desc: 'Deutsch' },
  { value: 'es-ES', label: 'Spanish', icon: '🇪🇸', desc: 'Español' },
  { value: 'pt-BR', label: 'Portuguese', icon: '🇧🇷', desc: 'Português' },
  { value: 'ar-SA', label: 'Arabic', icon: '🇸🇦', desc: 'العربية' },
  { value: 'ru-RU', label: 'Russian', icon: '🇷🇺', desc: 'Русский' },
  { value: 'it-IT', label: 'Italian', icon: '🇮🇹', desc: 'Italiano' },
  { value: 'th-TH', label: 'Thai', icon: '🇹🇭', desc: 'ไทย' },
  { value: 'vi-VN', label: 'Vietnamese', icon: '🇻🇳', desc: 'Tiếng Việt' },
  { value: 'id-ID', label: 'Indonesian', icon: '🇮🇩', desc: 'Bahasa Indonesia' },
]

const PERSONALITY_MODES = [
  {
    value: 'gf',
    label: 'GF Mode',
    icon: '💖',
    description: 'Hinglish, warm, caring',
  },
  {
    value: 'professional',
    label: 'Professional Mode',
    icon: '💼',
    description: 'Formal English',
  },
  {
    value: 'assistant',
    label: 'Assistant Mode',
    icon: '🤖',
    description: 'Balanced',
  },
]

export default function SettingsPanel({
  open,
  onClose,
  onSave,
  settings,
  isConnected = false,
}: SettingsPanelProps) {
  const [localSettings, setLocalSettings] = useState<SettingsData>({ ...settings })
  const [showApiKey, setShowApiKey] = useState(false)
  const [newContactName, setNewContactName] = useState('')
  const [newContactNumber, setNewContactNumber] = useState('')
  const [showAddContact, setShowAddContact] = useState(false)
  const [backupStatus, setBackupStatus] = useState<string>('')
  const [isBackupLoading, setIsBackupLoading] = useState(false)

  // Sync settings when prop changes
  const handleOpenChange = useCallback(
    (isOpen: boolean) => {
      if (isOpen) {
        setLocalSettings({ ...settings })
      }
      if (!isOpen) {
        onClose()
      }
    },
    [settings, onClose]
  )

  const handleSave = () => {
    onSave(localSettings)
    onClose()
  }

  const handleAddContact = () => {
    if (!newContactName.trim() || !newContactNumber.trim()) return
    const newContact = {
      id: `contact_${Date.now()}`,
      name: newContactName.trim(),
      number: newContactNumber.trim(),
    }
    setLocalSettings((prev) => ({
      ...prev,
      primeContacts: [...prev.primeContacts, newContact],
    }))
    setNewContactName('')
    setNewContactNumber('')
    setShowAddContact(false)
  }

  const handleRemoveContact = (id: string) => {
    setLocalSettings((prev) => ({
      ...prev,
      primeContacts: prev.primeContacts.filter((c) => c.id !== id),
    }))
  }

  return (
    <Sheet open={open} onOpenChange={handleOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-md bg-[#0A0A0A] border-l border-[#222] text-[#EEEEEE] p-0"
      >
        <SheetHeader className="p-6 pb-4">
          <SheetTitle className="text-xl font-bold text-[#EEEEEE]">
            ⚙️ NEXA Settings
          </SheetTitle>
          <SheetDescription className="text-[#888] text-sm">
            Configure your AI voice assistant
          </SheetDescription>
        </SheetHeader>

        <Separator className="bg-[#222]" />

        <ScrollArea className="flex-1 h-[calc(100vh-180px)]">
          <div className="p-6 space-y-6">
            {/* Status Indicators */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-xs">
                {isConnected ? (
                  <Wifi className="size-4 text-green-500" />
                ) : (
                  <WifiOff className="size-4 text-red-500" />
                )}
                <span style={{ color: isConnected ? '#4CAF50' : '#FF1744' }}>
                  {isConnected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <CheckCircle2
                  className="size-4"
                  style={{ color: localSettings.apiKey ? '#4CAF50' : '#666' }}
                />
                <span style={{ color: localSettings.apiKey ? '#4CAF50' : '#666' }}>
                  {localSettings.apiKey ? 'API Key Set' : 'No API Key'}
                </span>
              </div>
            </div>

            {/* API Key */}
            <div className="space-y-2">
              <Label className="text-[#CCC] text-sm">API Key</Label>
              <div className="relative">
                <Input
                  type={showApiKey ? 'text' : 'password'}
                  value={localSettings.apiKey}
                  onChange={(e) =>
                    setLocalSettings((prev) => ({ ...prev, apiKey: e.target.value }))
                  }
                  placeholder="Enter your Gemini API key"
                  className="bg-[#111] border-[#333] text-[#EEE] pr-10 placeholder:text-[#555]"
                />
                <button
                  type="button"
                  onClick={() => setShowApiKey(!showApiKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#888] hover:text-[#EEE] transition-colors"
                  aria-label={showApiKey ? 'Hide API key' : 'Show API key'}
                >
                  {showApiKey ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </div>

            {/* Your Name */}
            <div className="space-y-2">
              <Label className="text-[#CCC] text-sm">Your Name</Label>
              <Input
                value={localSettings.userName}
                onChange={(e) =>
                  setLocalSettings((prev) => ({ ...prev, userName: e.target.value }))
                }
                placeholder="Enter your name"
                className="bg-[#111] border-[#333] text-[#EEE] placeholder:text-[#555]"
              />
            </div>

            {/* AI Model Selector */}
            <div className="space-y-2">
              <Label className="text-[#CCC] text-sm">AI Model</Label>
              <Select
                value={localSettings.geminiModel}
                onValueChange={(v) =>
                  setLocalSettings((prev) => ({ ...prev, geminiModel: v }))
                }
              >
                <SelectTrigger className="bg-[#111] border-[#333] text-[#EEE] w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#111] border-[#333]">
                  {AI_MODELS.map((model) => (
                    <SelectItem
                      key={model.value}
                      value={model.value}
                      className="text-[#EEE] focus:bg-[#222] focus:text-[#EEE]"
                    >
                      {model.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Voice Selector */}
            <div className="space-y-2">
              <Label className="text-[#CCC] text-sm">Voice</Label>
              <Select
                value={localSettings.geminiVoice}
                onValueChange={(v) =>
                  setLocalSettings((prev) => ({ ...prev, geminiVoice: v }))
                }
              >
                <SelectTrigger className="bg-[#111] border-[#333] text-[#EEE] w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#111] border-[#333]">
                  {VOICES.map((voice) => (
                    <SelectItem
                      key={voice}
                      value={voice}
                      className="text-[#EEE] focus:bg-[#222] focus:text-[#EEE]"
                    >
                      {voice}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Language Selector */}
            <div className="space-y-3">
              <Label className="text-[#CCC] text-sm">Language 🌍</Label>
              <Select
                value={localSettings.language || 'auto'}
                onValueChange={(v) =>
                  setLocalSettings((prev) => ({ ...prev, language: v }))
                }
              >
                <SelectTrigger className="bg-[#111] border-[#333] text-[#EEE] w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#111] border-[#333] max-h-[300px]">
                  {LANGUAGES.map((lang) => (
                    <SelectItem
                      key={lang.value}
                      value={lang.value}
                      className="text-[#EEE] focus:bg-[#222] focus:text-[#EEE]"
                    >
                      <span className="flex items-center gap-2">
                        <span>{lang.icon}</span>
                        <span>{lang.label}</span>
                        <span className="text-[#666] text-xs">{lang.desc}</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[11px] text-[#666]">
                {localSettings.language === 'auto'
                  ? 'NEXA will auto-detect and understand any language you speak'
                  : `NEXA will listen in ${LANGUAGES.find(l => l.value === localSettings.language)?.label || 'selected language'}. AI responds in your language automatically.`
                }
              </p>
            </div>

            {/* Personality Mode */}
            <div className="space-y-3">
              <Label className="text-[#CCC] text-sm">Personality Mode</Label>
              <RadioGroup
                value={localSettings.personalityMode}
                onValueChange={(v) =>
                  setLocalSettings((prev) => ({ ...prev, personalityMode: v }))
                }
                className="space-y-2"
              >
                {PERSONALITY_MODES.map((mode) => (
                  <label
                    key={mode.value}
                    className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                      localSettings.personalityMode === mode.value
                        ? 'border-[#FF1744] bg-[#1a0000]'
                        : 'border-[#333] bg-[#0D0D0D] hover:border-[#555]'
                    }`}
                  >
                    <RadioGroupItem
                      value={mode.value}
                      className="border-[#555] text-[#FF1744]"
                    />
                    <span className="text-lg">{mode.icon}</span>
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-[#EEE]">{mode.label}</span>
                      <span className="text-xs text-[#888]">{mode.description}</span>
                    </div>
                  </label>
                ))}
              </RadioGroup>
            </div>

            <Separator className="bg-[#222]" />

            {/* Prime Contacts */}
            <div className="space-y-3">
              <Label className="text-[#CCC] text-sm">Prime Contacts</Label>

              {localSettings.primeContacts.length > 0 && (
                <div className="space-y-2">
                  {localSettings.primeContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="flex items-center justify-between p-2.5 rounded-lg bg-[#0D0D0D] border border-[#222]"
                    >
                      <div className="flex flex-col">
                        <span className="text-sm text-[#EEE]">{contact.name}</span>
                        <span className="text-xs text-[#888]">{contact.number}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveContact(contact.id)}
                        className="p-1.5 rounded-md hover:bg-[#1a0000] text-[#888] hover:text-[#FF1744] transition-colors"
                        aria-label={`Remove ${contact.name}`}
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {showAddContact ? (
                <div className="space-y-2 p-3 rounded-lg bg-[#0D0D0D] border border-[#222]">
                  <Input
                    value={newContactName}
                    onChange={(e) => setNewContactName(e.target.value)}
                    placeholder="Contact name"
                    className="bg-[#111] border-[#333] text-[#EEE] placeholder:text-[#555] h-8 text-sm"
                  />
                  <Input
                    value={newContactNumber}
                    onChange={(e) => setNewContactNumber(e.target.value)}
                    placeholder="Phone number"
                    className="bg-[#111] border-[#333] text-[#EEE] placeholder:text-[#555] h-8 text-sm"
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={handleAddContact}
                      disabled={!newContactName.trim() || !newContactNumber.trim()}
                      className="bg-[#FF1744] hover:bg-[#FF1744]/80 text-white text-xs h-7"
                    >
                      Add
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setShowAddContact(false)
                        setNewContactName('')
                        setNewContactNumber('')
                      }}
                      className="text-[#888] hover:text-[#EEE] text-xs h-7"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowAddContact(true)}
                  className="flex items-center gap-2 text-sm text-[#FF1744] hover:text-[#FF1744]/80 transition-colors"
                >
                  <Plus className="size-4" />
                  Add Prime Contact
                </button>
              )}
            </div>

            <Separator className="bg-[#222]" />

            {/* Backup & Restore */}
            <div className="space-y-3">
              <Label className="text-sm font-semibold text-gray-300 flex items-center gap-2">
                <Archive className="size-4 text-[#FF1744]" />
                Backup & Restore
              </Label>
              <p className="text-[11px] text-gray-500">Download all project files as ZIP or upload a backup to restore.</p>

              <div className="flex gap-2">
                {/* Download Backup */}
                <Button
                  size="sm"
                  variant="outline"
                  disabled={isBackupLoading}
                  onClick={async () => {
                    setIsBackupLoading(true)
                    setBackupStatus('Downloading...')
                    try {
                      const res = await fetch('/api/backup')
                      if (res.ok) {
                        const blob = await res.blob()
                        const url = URL.createObjectURL(blob)
                        const a = document.createElement('a')
                        a.href = url
                        a.download = `nexa-backup-${new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19)}.zip`
                        document.body.appendChild(a)
                        a.click()
                        document.body.removeChild(a)
                        URL.revokeObjectURL(url)
                        setBackupStatus('✅ Backup downloaded!')
                      } else {
                        setBackupStatus('❌ Download failed')
                      }
                    } catch {
                      setBackupStatus('❌ Download failed')
                    }
                    setIsBackupLoading(false)
                    setTimeout(() => setBackupStatus(''), 3000)
                  }}
                  className="flex-1 border-[#333] hover:border-[#FF1744]/50 text-gray-300 hover:text-white text-xs h-9"
                >
                  <Download className="size-3.5 mr-1.5" />
                  {isBackupLoading ? 'Loading...' : 'Download ZIP'}
                </Button>

                {/* Upload Backup */}
                <label className="flex-1 cursor-pointer">
                  <input
                    type="file"
                    accept=".zip"
                    className="hidden"
                    onChange={async (e) => {
                      const file = e.target.files?.[0]
                      if (!file) return
                      setIsBackupLoading(true)
                      setBackupStatus('Uploading & restoring...')
                      try {
                        const formData = new FormData()
                        formData.append('backup', file)
                        const res = await fetch('/api/backup', {
                          method: 'POST',
                          body: formData,
                        })
                        const data = await res.json()
                        if (res.ok && data.success) {
                          setBackupStatus(`✅ Restored ${data.filesRestored || 0} files!`)
                        } else {
                          setBackupStatus(`❌ ${data.error || 'Restore failed'}`)
                        }
                      } catch {
                        setBackupStatus('❌ Upload failed')
                      }
                      setIsBackupLoading(false)
                      setTimeout(() => setBackupStatus(''), 5000)
                      e.target.value = '' // Reset input
                    }}
                  />
                  <span className="flex items-center justify-center h-9 rounded-md border border-[#333] hover:border-[#D500F9]/50 text-gray-300 hover:text-white text-xs transition-colors">
                    <Upload className="size-3.5 mr-1.5" />
                    Upload & Restore
                  </span>
                </label>
              </div>

              {backupStatus && (
                <p className="text-[11px] text-center py-1 rounded" style={{
                  color: backupStatus.startsWith('✅') ? '#4CAF50' : backupStatus.startsWith('❌') ? '#FF5252' : '#FFB74D',
                  background: 'rgba(255,255,255,0.05)',
                }}>
                  {backupStatus}
                </p>
              )}
            </div>

            <Separator className="bg-[#222]" />

            {/* Save Button */}
            <Button
              onClick={handleSave}
              className="w-full h-11 text-white font-semibold rounded-lg"
              style={{
                background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)',
                boxShadow: '0 4px 20px rgba(255,23,68,0.3)',
              }}
            >
              Save Settings
            </Button>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  )
}
