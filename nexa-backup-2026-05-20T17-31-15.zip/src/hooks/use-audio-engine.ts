'use client'

import { useCallback, useRef, useEffect } from 'react'

interface AudioEngineCallbacks {
  onAmplitudeChanged: (rms: number) => void
  onSpeakingStarted: () => void
  onSpeakingStopped: () => void
}

export function useAudioEngine(callbacks: AudioEngineCallbacks) {
  const audioContextRef = useRef<AudioContext | null>(null)
  const micStreamRef = useRef<MediaStream | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null)
  const isRecordingRef = useRef(false)
  const playbackQueueRef = useRef<Int16Array[]>([])
  const isPlayingRef = useRef(false)
  const playContextRef = useRef<AudioContext | null>(null)
  const nextPlayTimeRef = useRef(0)
  const amplitudeIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Initialize audio context for playback
  const getPlayContext = useCallback(() => {
    if (!playContextRef.current || playContextRef.current.state === 'closed') {
      playContextRef.current = new AudioContext({ sampleRate: 24000 })
    }
    return playContextRef.current
  }, [])

  // Stop microphone recording
  const stopRecording = useCallback(() => {
    isRecordingRef.current = false

    if (amplitudeIntervalRef.current) {
      clearInterval(amplitudeIntervalRef.current)
      amplitudeIntervalRef.current = null
    }

    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(t => t.stop())
      micStreamRef.current = null
    }

    if (sourceRef.current) {
      sourceRef.current.disconnect()
      sourceRef.current = null
    }

    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close()
      audioContextRef.current = null
    }

    analyserRef.current = null
    callbacks.onAmplitudeChanged(0)
  }, [callbacks])

  // Clear playback queue (for interrupt)
  const clearPlaybackQueue = useCallback(() => {
    playbackQueueRef.current = []
    isPlayingRef.current = false
    nextPlayTimeRef.current = 0

    // Close and recreate play context to stop all sounds
    if (playContextRef.current && playContextRef.current.state !== 'closed') {
      playContextRef.current.close()
      playContextRef.current = null
    }

    callbacks.onSpeakingStopped()
  }, [callbacks])

  // Drain playback queue - process audio chunks
  const drainPlaybackQueue = useCallback(() => {
    const ctx = getPlayContext()
    
    const processQueue = () => {
      if (playbackQueueRef.current.length === 0) {
        isPlayingRef.current = false
        callbacks.onSpeakingStopped()
        return
      }

      const chunk = playbackQueueRef.current.shift()!
      const audioBuffer = ctx.createBuffer(1, chunk.length, 24000)
      audioBuffer.getChannelData(0).set(chunk)

      const source = ctx.createBufferSource()
      source.buffer = audioBuffer
      source.connect(ctx.destination)

      const now = ctx.currentTime
      const startTime = Math.max(now, nextPlayTimeRef.current)
      nextPlayTimeRef.current = startTime + audioBuffer.duration

      source.onended = () => {
        processQueue()
      }

      source.start(startTime)
    }

    if (ctx.state === 'suspended') {
      ctx.resume().then(processQueue)
    } else {
      processQueue()
    }
  }, [callbacks, getPlayContext])

  // Play PCM audio received from Gemini
  const queueAudio = useCallback((base64Pcm: string) => {
    try {
      // Decode base64 to Int16 PCM
      const binaryString = atob(base64Pcm)
      const uint8Array = new Uint8Array(binaryString.length)
      for (let i = 0; i < binaryString.length; i++) {
        uint8Array[i] = binaryString.charCodeAt(i)
      }
      const int16Array = new Int16Array(uint8Array.buffer)

      // Convert Int16 to Float32 for AudioContext
      const float32Array = new Float32Array(int16Array.length)
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 0x8000
      }

      playbackQueueRef.current.push(float32Array)

      if (!isPlayingRef.current) {
        callbacks.onSpeakingStarted()
        isPlayingRef.current = true
        drainPlaybackQueue()
      }
    } catch (err) {
      console.error('[AudioEngine] Failed to queue audio:', err)
    }
  }, [callbacks, drainPlaybackQueue])

  // Start microphone recording
  const startRecording = useCallback(async () => {
    try {
      if (isRecordingRef.current) return

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }
      })

      micStreamRef.current = stream
      const ctx = new AudioContext({ sampleRate: 16000 })
      audioContextRef.current = ctx

      const source = ctx.createMediaStreamSource(stream)
      sourceRef.current = source

      const analyser = ctx.createAnalyser()
      analyser.fftSize = 512
      analyser.smoothingTimeConstant = 0.5
      source.connect(analyser)
      analyserRef.current = analyser

      isRecordingRef.current = true

      // Start amplitude monitoring
      if (amplitudeIntervalRef.current) clearInterval(amplitudeIntervalRef.current)
      amplitudeIntervalRef.current = setInterval(() => {
        if (!analyserRef.current || !isRecordingRef.current) return
        const dataArray = new Float32Array(analyserRef.current.fftSize)
        analyserRef.current.getFloatTimeDomainData(dataArray)

        let sum = 0
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i] * dataArray[i]
        }
        const rms = Math.sqrt(sum / dataArray.length)
        callbacks.onAmplitudeChanged(Math.min(1, rms * 5)) // amplify for visual effect
      }, 50)

    } catch (err) {
      console.error('[AudioEngine] Failed to start recording:', err)
    }
  }, [callbacks])

  // Get PCM audio chunk from mic (for sending to Gemini)
  const getAudioChunk = useCallback((): string | null => {
    if (!analyserRef.current || !isRecordingRef.current) return null

    const analyser = analyserRef.current
    const bufferLength = analyser.fftSize
    const dataArray = new Float32Array(bufferLength)
    analyser.getFloatTimeDomainData(dataArray)

    // Convert float32 to int16 PCM
    const int16Array = new Int16Array(bufferLength)
    for (let i = 0; i < bufferLength; i++) {
      const s = Math.max(-1, Math.min(1, dataArray[i]))
      int16Array[i] = s < 0 ? s * 0x8000 : s * 0x7FFF
    }

    // Convert to base64
    const uint8Array = new Uint8Array(int16Array.buffer)
    let binary = ''
    for (let i = 0; i < uint8Array.length; i++) {
      binary += String.fromCharCode(uint8Array[i])
    }
    return btoa(binary)
  }, [])

  // Release all resources
  const release = useCallback(() => {
    stopRecording()
    clearPlaybackQueue()
  }, [stopRecording, clearPlaybackQueue])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (amplitudeIntervalRef.current) clearInterval(amplitudeIntervalRef.current)
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach(t => t.stop())
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close()
      }
      if (playContextRef.current && playContextRef.current.state !== 'closed') {
        playContextRef.current.close()
      }
    }
  }, [])

  return {
    startRecording,
    stopRecording,
    getAudioChunk,
    queueAudio,
    clearPlaybackQueue,
    release,
    isRecording: isRecordingRef,
  }
}
