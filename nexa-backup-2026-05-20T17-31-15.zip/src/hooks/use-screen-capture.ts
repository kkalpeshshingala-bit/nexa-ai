'use client'

import { useRef, useCallback, useState } from 'react'
import { useNexaStore } from '@/lib/nexa-store'

/**
 * Hook for screen capture + screenshot functionality
 * Uses getDisplayMedia API to capture the screen
 * Can take screenshots and send them to VLM for screen understanding
 * 
 * Handles cases where display-capture is disallowed by permissions policy
 * (e.g., when running inside an iframe without allow="display-capture")
 */
export function useScreenCapture() {
  const streamRef = useRef<MediaStream | null>(null)
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [screenError, setScreenError] = useState<string | null>(null)

  const setScreenSharing = (v: boolean) => useNexaStore.getState().setScreenSharing(v)

  /**
   * Check if screen capture is available and allowed by permissions policy.
   * Returns null if available, or an error message string if not.
   */
  const checkScreenCaptureAvailable = useCallback((): string | null => {
    // Check if the API exists at all
    if (!navigator.mediaDevices?.getDisplayMedia) {
      return 'Screen capture is not supported in this browser. Try using Chrome or Edge on desktop.'
    }

    // Check if we're in a secure context (required for getDisplayMedia)
    if (!window.isSecureContext) {
      return 'Screen capture requires a secure context (HTTPS). Please use HTTPS.'
    }

    // Check if display-capture is allowed by permissions policy
    // document.featurePolicy is deprecated but still useful for this check
    try {
      const featurePolicy = (document as unknown as { featurePolicy?: { allowsFeature: (f: string) => boolean } }).featurePolicy
      if (featurePolicy && !featurePolicy.allowsFeature('display-capture')) {
        return 'Screen capture is blocked by permissions policy. This usually happens when the app runs inside an iframe. Try opening NEXA in its own browser tab.'
      }
    } catch {
      // featurePolicy not available, we'll try the actual call
    }

    return null
  }, [])

  // Stop screen sharing
  const stopScreenCapture = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null
      videoRef.current = null
    }
    canvasRef.current = null
    setScreenSharing(false)
    setScreenError(null)
    console.log('[NEXA] Screen capture stopped')
  }, [])

  // Start screen sharing
  const startScreenCapture = useCallback(async (): Promise<{ success: boolean; error?: string }> => {
    try {
      // Pre-check: is screen capture available?
      const preCheckError = checkScreenCaptureAvailable()
      if (preCheckError) {
        console.warn('[NEXA] Screen capture pre-check failed:', preCheckError)
        setScreenError(preCheckError)
        setScreenSharing(false)
        return { success: false, error: preCheckError }
      }

      // Attempt to call getDisplayMedia — wrapped in extra safety
      // to prevent Next.js error overlay from catching it
      let stream: MediaStream
      try {
        stream = await navigator.mediaDevices.getDisplayMedia({
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            frameRate: { ideal: 1, max: 5 }, // Low framerate for screenshots
          },
          audio: false,
        })
      } catch (mediaError: unknown) {
        // Handle specific error types gracefully
        const err = mediaError as DOMException
        let errorMessage = 'Screen capture failed.'

        if (err.name === 'NotAllowedError') {
          if (err.message?.includes('permissions policy') || err.message?.includes('disallowed')) {
            errorMessage = 'Screen capture blocked by browser. Try opening NEXA directly in a browser tab (not in an iframe).'
          } else {
            errorMessage = 'Screen capture permission denied. Please allow screen sharing when prompted.'
          }
        } else if (err.name === 'NotFoundError') {
          errorMessage = 'No screen found to capture.'
        } else if (err.name === 'NotReadableError') {
          errorMessage = 'Screen cannot be captured. Another app may be using it.'
        } else if (err.name === 'AbortError') {
          errorMessage = 'Screen capture was aborted.'
        }

        console.warn('[NEXA] Screen capture error:', err.name, err.message)
        setScreenError(errorMessage)
        setScreenSharing(false)
        return { success: false, error: errorMessage }
      }

      streamRef.current = stream

      // Create hidden video element to receive stream
      const video = document.createElement('video')
      video.srcObject = stream
      video.muted = true
      video.playsInline = true
      await video.play()
      videoRef.current = video

      // Create canvas for screenshot capture
      const canvas = document.createElement('canvas')
      canvas.width = 1280
      canvas.height = 720
      canvasRef.current = canvas

      // Handle stream end (user stops sharing)
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(t => t.stop())
          streamRef.current = null
        }
        videoRef.current = null
        canvasRef.current = null
        useNexaStore.getState().setScreenSharing(false)
        setScreenError(null)
        console.log('[NEXA] Screen capture stopped (stream ended)')
      })

      setScreenSharing(true)
      setScreenError(null)
      console.log('[NEXA] Screen capture started')
      return { success: true }
    } catch (err) {
      // Catch-all for any unexpected errors
      console.warn('[NEXA] Unexpected screen capture error:', err)
      setScreenError('Screen capture failed unexpectedly.')
      setScreenSharing(false)
      return { success: false, error: 'Screen capture failed unexpectedly.' }
    }
  }, [checkScreenCaptureAvailable, setScreenSharing])

  // Take a screenshot and return as base64 data URL
  const takeScreenshot = useCallback((): string | null => {
    if (!videoRef.current || !canvasRef.current) {
      console.log('[NEXA] No screen capture active, cannot take screenshot')
      return null
    }

    try {
      const video = videoRef.current
      const canvas = canvasRef.current
      const ctx = canvas.getContext('2d')
      if (!ctx) return null

      // Draw current video frame to canvas
      canvas.width = video.videoWidth || 1280
      canvas.height = video.videoHeight || 720
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

      // Convert to base64 JPEG (smaller than PNG)
      const dataUrl = canvas.toDataURL('image/jpeg', 0.7)
      console.log('[NEXA] Screenshot captured:', dataUrl.length, 'bytes')
      return dataUrl
    } catch (err) {
      console.warn('[NEXA] Screenshot error:', err)
      return null
    }
  }, [])

  // Toggle screen capture on/off
  const toggleScreenCapture = useCallback(async (): Promise<{ success: boolean; error?: string }> => {
    const isCurrentlySharing = useNexaStore.getState().isScreenSharing
    if (isCurrentlySharing) {
      stopScreenCapture()
      return { success: false }
    } else {
      return startScreenCapture()
    }
  }, [startScreenCapture, stopScreenCapture])

  return {
    startScreenCapture,
    stopScreenCapture,
    takeScreenshot,
    toggleScreenCapture,
    screenError,
    clearScreenError: () => setScreenError(null),
    isScreenCaptureAvailable: checkScreenCaptureAvailable,
  }
}
