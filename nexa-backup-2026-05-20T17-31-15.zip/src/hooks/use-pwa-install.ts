'use client'

import { useState, useEffect, useCallback } from 'react'

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
}

interface PWAInstallResult {
  canInstall: boolean
  promptInstall: () => Promise<boolean>
}

export function usePWAInstall(): PWAInstallResult {
  const [canInstall, setCanInstall] = useState(false)

  useEffect(() => {
    // Listen for beforeinstallprompt — setCanInstall in event callback (allowed)
    const handler = (e: Event) => {
      e.preventDefault()
      ;(window as unknown as { __nexaDeferredPrompt?: BeforeInstallPromptEvent }).__nexaDeferredPrompt = e as BeforeInstallPromptEvent
      setCanInstall(true)
      console.log('[NEXA PWA] Install prompt available')
    }

    window.addEventListener('beforeinstallprompt', handler)

    // Listen for app installed
    const installedHandler = () => {
      setCanInstall(false)
      ;(window as unknown as { __nexaDeferredPrompt?: BeforeInstallPromptEvent }).__nexaDeferredPrompt = undefined
      console.log('[NEXA PWA] App installed!')
    }

    window.addEventListener('appinstalled', installedHandler)

    return () => {
      window.removeEventListener('beforeinstallprompt', handler)
      window.removeEventListener('appinstalled', installedHandler)
    }
  }, [])

  const promptInstall = useCallback(async (): Promise<boolean> => {
    const prompt = (window as unknown as { __nexaDeferredPrompt?: BeforeInstallPromptEvent }).__nexaDeferredPrompt
    if (!prompt) return false

    try {
      await prompt.prompt()
      const { outcome } = await prompt.userChoice
      console.log('[NEXA PWA] Install outcome:', outcome)
      ;(window as unknown as { __nexaDeferredPrompt?: BeforeInstallPromptEvent }).__nexaDeferredPrompt = undefined
      setCanInstall(false)
      return outcome === 'accepted'
    } catch (err) {
      console.error('[NEXA PWA] Install prompt error:', err)
      return false
    }
  }, [])

  return { canInstall, promptInstall }
}
