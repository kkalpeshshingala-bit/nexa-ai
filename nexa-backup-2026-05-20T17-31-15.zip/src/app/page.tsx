'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { useNexaStore } from '@/lib/nexa-store'
import type { OrbState } from '@/lib/nexa-store'
import type { NexaAction } from '@/lib/nexa-actions'
import { buildSystemPrompt, getRecognitionLang } from '@/lib/system-prompt'
import { detectActionsFromText, findApps, isConversationalMessage } from '@/lib/nexa-actions'
import AppLaunchOverlay from '@/components/nexa/AppLaunchOverlay'
import OrbAnimationView from '@/components/nexa/OrbAnimationView'
import WaveformView from '@/components/nexa/WaveformView'
import ChatBubble from '@/components/nexa/ChatBubble'
import SettingsPanel, { type SettingsData } from '@/components/nexa/SettingsPanel'
import PiPWidget from '@/components/nexa/PiPWidget'
import { usePWAInstall } from '@/hooks/use-pwa-install'
import { useScreenCapture } from '@/hooks/use-screen-capture'
import TaskPanel from '@/components/nexa/TaskPanel'
import type { NexaTask } from '@/lib/nexa-store'
import { Settings, Mic, MicOff, Send, Trash2, ExternalLink, Timer, MapPin, Search, Music, Phone, MessageCircle, StickyNote, Mail, MessageSquare, Minimize2, Maximize2, Ear, Monitor, MonitorOff, PictureInPicture2, Eye, Download, Smartphone, X, Zap, ImagePlus } from 'lucide-react'

interface ActionToast {
  id: string
  action: NexaAction
  timestamp: number
}

// Pending action for app launch overlay
interface PendingAction {
  id: string
  action: NexaAction
  autoOpened: boolean
  createdAt: number
}

// Track URLs that were already opened (to prevent duplicates when AI also generates the same action)
let openedActionUrls: Set<string> = new Set()

// Track the last user message for conversational guard — prevents AI-generated actions
// from opening Google/Chrome when user asks "what is your name" etc.
let lastUserMessage = ''

// Conversational action blocker — returns true if the action should be BLOCKED
// because the user's original message was a conversational question (not a command)
function shouldBlockAction(action: NexaAction): boolean {
  if (!lastUserMessage) return false

  // Layer 1: If the user message is conversational, block ALL actions
  if (isConversationalMessage(lastUserMessage)) {
    console.log('[NEXA] 🛑 Blocked action (conversational message):', action.type, action.label)
    return true
  }

  // Layer 2: If the action is a search/open for Google/Chrome and the query
  // contains conversational patterns, block it
  const query = (action.query || action.label || '').toLowerCase()
  const conversationalWords = ['your name', 'who are you', 'how are you', 'what are you', 'my name',
    'tumhara naam', 'tera naam', 'taru naam', 'tamaru naam', 'naam kya', 'name su',
    'kaise ho', 'kem cho', 'kon ho', 'kaun ho']
  if ((action.type === 'search' || (action.type === 'open' && (query.includes('google') || query.includes('chrome'))))
    && conversationalWords.some(w => query.includes(w) || lastUserMessage.toLowerCase().includes(w))) {
    console.log('[NEXA] 🛑 Blocked action (conversational search/open):', action.type, action.label)
    return true
  }

  return false
}

// Wake words that activate NEXA
const WAKE_WORDS = ['hey nexa', 'nexa', 'ok nexa', 'okay nexa', 'hi nexa', 'hello nexa']

// ─── OFFLINE / LOCAL RESPONSE ENGINE ──────────────────────────────────
// When the AI server is down, NEXA still works with local responses + actions
// Actions (open apps, timers, etc.) always work client-side via detectActionsFromText()

function generateLocalResponse(userText: string, userName: string): string {
  const text = userText.toLowerCase().trim()

  // Greetings
  if (/^(hi|hello|hey|namaste|namaskar|helo|kem cho|kaise ho|how are you)/.test(text)) {
    const greetings = [
      `Hello ${userName}! Main NEXA hoon. Abhi server offline hai, lekin main tumhara kaam kar sakti hoon — bolo app kholna hai ya timer set karna hai!`,
      `Hey ${userName}! Server thoda busy hai, par main hoon na! Bolo kya karna hai — app kholo, timer set karo, ya search karo!`,
      `Namaste ${userName}! Abhi AI chat offline hai, lekin actions chalu hain! Bolo "youtube kholo" ya "5 minute timer lagao"!`,
    ]
    return greetings[Math.floor(Math.random() * greetings.length)]
  }

  // Time queries
  if (/time|samay|baje|baj|clock|waqt/.test(text)) {
    const now = new Date()
    const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
    return `Abhi ${timeStr} baj rahe hain! ⏰`
  }

  // Date queries
  if (/date|tarikh|din|aaj|today/.test(text)) {
    const now = new Date()
    const dateStr = now.toLocaleDateString('en-IN', { dateStyle: 'full' })
    return `Aaj ${dateStr} hai! 📅`
  }

  // Thank you
  if (/thank|shukriya|dhanyavad|thanks/.test(text)) {
    return `You're welcome ${userName}! 😊 Kuch aur chahiye to bolo!`
  }

  // Who are you
  if (/who are you|tu kaun|tum kaun|naam kya|kaun ho/.test(text)) {
    return `Main NEXA hoon, tumhari AI assistant! Abhi server offline hai, par main basic kaam kar sakti hoon — apps kholna, timer set karna, search karna!`
  }

  // If actions were detected, confirm them
  if (/khol|open|start|chalu|launch|play|bajao/.test(text)) {
    return `Haan ${userName}, kar rahi hoon! Agar app nahi khuli to manually open karo. Server wapas aane par sab smooth ho jayega!`
  }

  // Timer
  if (/timer|alarm|stopwatch/.test(text)) {
    return `Timer set kar rahi hoon! ⏱️`
  }

  // Default offline response
  const defaults = [
    `${userName}, abhi AI server offline hai. Par main actions kar sakti hoon! Bolo — "youtube kholo", "timer lagao", ya "google search karo"!`,
    `Server abhi bandh hai ${userName}, lekin NEXA chalu hai! App kholna ho, timer set karna ho, ya search karna ho — bolo!`,
    `${userName}, AI chat abhi unavailable hai, par actions available hain! Try karo: "instagram kholo" ya "10 minute timer"!`,
  ]
  return defaults[Math.floor(Math.random() * defaults.length)]
}

// Track server availability
let serverAvailable = true
let lastServerCheck = 0

export default function Home() {
  const isConnected = useNexaStore((s) => s.isConnected)
  const isRecording = useNexaStore((s) => s.isRecording)
  const isSpeaking = useNexaStore((s) => s.isSpeaking)
  // isMuted is available via store if needed: useNexaStore.getState().isMuted
  const amplitude = useNexaStore((s) => s.amplitude)
  const orbState = useNexaStore((s) => s.orbState)
  const messages = useNexaStore((s) => s.messages)
  const settings = useNexaStore((s) => s.settings)
  const primeContacts = useNexaStore((s) => s.primeContacts)
  const statusText = useNexaStore((s) => s.statusText)
  const inputTranscript = useNexaStore((s) => s.inputTranscript)
  const outputTranscript = useNexaStore((s) => s.outputTranscript)
  const isAlwaysListening = useNexaStore((s) => s.isAlwaysListening)
  const isMiniMode = useNexaStore((s) => s.isMiniMode)
  const isScreenSharing = useNexaStore((s) => s.isScreenSharing)
  const isPiPMode = useNexaStore((s) => s.isPiPMode)
  const tasks = useNexaStore((s) => s.tasks)

  const chatEndRef = useRef<HTMLDivElement>(null)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [textInput, setTextInput] = useState('')
  const [showRedOverlay, setShowRedOverlay] = useState(false)
  const [isServerDown, setIsServerDown] = useState(false) // Track server availability for UI
  const [statusInfo, setStatusInfo] = useState({ time: '' })
  const [pendingPhoto, setPendingPhoto] = useState<{ base64: string; preview: string } | null>(null)
  const photoInputRef = useRef<HTMLInputElement | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const synthRef = useRef<SpeechSynthesis | null>(null)
  const isProcessingRef = useRef(false)
  const lastRequestTimeRef = useRef(0) // Client-side debounce: minimum 3s between AI requests
  const [actionToasts, setActionToasts] = useState<ActionToast[]>([])
  const [pendingAction, setPendingAction] = useState<PendingAction | null>(null)
  // Track actions that were pre-opened (before async fetch) so we can dedup
  // No longer needed - using module-level openedActionUrls instead
  const [timerInfo, setTimerInfo] = useState<{ remaining: number; total: number; label: string } | null>(null)
  const timerIntervalsRef = useRef<Map<string, NodeJS.Timeout>>(new Map())
  const taskCounterRef = useRef(0)
  const alwaysListenRef = useRef<SpeechRecognition | null>(null)
  // Track notification permission status
  const notificationsRef = useRef(false)
  const isWakeListeningRef = useRef(false)
  const isCommandListeningRef = useRef(false)
  const startWakeWordListeningRef = useRef<() => void>(() => {})
  const toggleMicRef = useRef<() => void>(() => {})
  const handleToggleScreenRef = useRef<() => void>(() => {})
  const toggleAlwaysListeningRef = useRef<() => void>(() => {})

  // (launcher window removed — was causing blank page issue)

  // Screen capture hook
  const { takeScreenshot, toggleScreenCapture, stopScreenCapture, screenError, clearScreenError, isScreenCaptureAvailable } = useScreenCapture()
  const [screenCaptureUnavailable, setScreenCaptureUnavailable] = useState<string | null>(null)

  // PWA install hook
  const { canInstall, promptInstall } = usePWAInstall()
  const [showInstallBanner, setShowInstallBanner] = useState(true)
  const [showAppBadge, setShowAppBadge] = useState(false)

  // Stable store action references — useNexaStore.getState() is always current
  // No dependency array issues since getState() reads latest state
  const sa = useRef({
    setConnected: (v: boolean) => useNexaStore.getState().setConnected(v),
    setRecording: (v: boolean) => useNexaStore.getState().setRecording(v),
    setSpeaking: (v: boolean) => useNexaStore.getState().setSpeaking(v),
    setMuted: (v: boolean) => useNexaStore.getState().setMuted(v),
    setAmplitude: (v: number) => useNexaStore.getState().setAmplitude(v),
    setOrbState: (v: OrbState) => useNexaStore.getState().setOrbState(v),
    addMessage: (msg: { text: string; isUser: boolean; timestamp: number }) => useNexaStore.getState().addMessage(msg),
    clearMessages: () => useNexaStore.getState().clearMessages(),
    setInputTranscript: (v: string) => useNexaStore.getState().setInputTranscript(v),
    setOutputTranscript: (v: string) => useNexaStore.getState().setOutputTranscript(v),
    clearTranscripts: () => useNexaStore.getState().clearTranscripts(),
    updateSettings: (s: Partial<typeof settings>) => useNexaStore.getState().updateSettings(s),
    setPrimeContacts: (c: typeof primeContacts) => useNexaStore.getState().setPrimeContacts(c),
    setStatusText: (v: string) => useNexaStore.getState().setStatusText(v),
    setAlwaysListening: (v: boolean) => useNexaStore.getState().setAlwaysListening(v),
    setMiniMode: (v: boolean) => useNexaStore.getState().setMiniMode(v),
    setBackgroundMode: (v: boolean) => useNexaStore.getState().setBackgroundMode(v),
    setScreenSharing: (v: boolean) => useNexaStore.getState().setScreenSharing(v),
    setPiPMode: (v: boolean) => useNexaStore.getState().setPiPMode(v),
  }).current

// Open a URL directly — tries multiple methods for maximum compatibility
  // For tel: and mailto: uses window.location.href directly (always works)
  // For web URLs: tries <a> click → window.open → window.location.href fallback
  const openUrlDirect = useCallback((targetUrl: string): boolean => {
    if (!targetUrl) return false

    // tel: and mailto: — use window.location.href directly (always works, stays on page)
    if (targetUrl.startsWith('tel:') || targetUrl.startsWith('mailto:')) {
      window.location.href = targetUrl
      return true
    }

    // METHOD 1: Programmatic <a> click with target="_blank" — works in standalone browser
    try {
      const link = document.createElement('a')
      link.href = targetUrl
      link.target = '_blank'
      link.rel = 'noopener noreferrer'
      link.style.display = 'none'
      document.body.appendChild(link)
      link.click()
      setTimeout(() => document.body.removeChild(link), 100)
      console.log('[NEXA] ✅ Opened via <a> click:', targetUrl)
      return true
    } catch (e) {
      console.log('[NEXA] <a> click error:', e)
    }

    // METHOD 2: Try window.open as fallback
    try {
      const newWin = window.open(targetUrl, '_blank')
      if (newWin && !newWin.closed) {
        console.log('[NEXA] ✅ Opened via window.open:', targetUrl)
        newWin.focus()
        return true
      }
      console.log('[NEXA] ⚡ Popup blocked for:', targetUrl)
    } catch (e) {
      console.log('[NEXA] window.open error:', e)
    }

    // METHOD 3: Navigate in same tab using window.location.href
    // This ALWAYS works, even in sandboxed iframes — but navigates away from NEXA
    // The AppLaunchOverlay will also provide this option with a nice UI
    console.log('[NEXA] 🔀 Falling back to window.location.href:', targetUrl)
    window.location.href = targetUrl
    return true
  }, [])



  // Open an action URL — with dedup and fallback chain
  const openActionUrl = useCallback((action: NexaAction): boolean => {
    const webUrl = action.url
    const appUrl = action.appUrl
    const targetUrl = webUrl || appUrl

    console.log('[NEXA] openActionUrl:', { type: action.type, webUrl, appUrl, targetUrl })

    if (!targetUrl) {
      console.warn('[NEXA] No URL to open for action:', action)
      return false
    }

    // Dedup: skip if already opened
    if (openedActionUrls.has(targetUrl)) {
      console.log('[NEXA] ⏭️ Already opened, skipping:', targetUrl)
      return true
    }
    openedActionUrls.add(targetUrl)
    // Clean up dedup set after 30 seconds
    setTimeout(() => openedActionUrls.delete(targetUrl), 30000)

    // Try to open the URL
    const success = openUrlDirect(targetUrl)
    if (!success && action.type !== 'open') {
      // Show tap-to-open overlay as last resort (but not for 'open' type which already shows AppLaunchOverlay)
      setPendingAction({
        id: `pending-${Date.now()}`,
        action,
        autoOpened: false,
        createdAt: Date.now(),
      })
    }
    return success
  }, [openUrlDirect])

  // Send browser notification — ALWAYS when in background
  const sendNotification = useCallback((title: string, body: string) => {
    if (!('Notification' in window) || Notification.permission !== 'granted') return
    if (document.hidden) {
      // NOTE: icon/badge must be URLs, NOT emojis — using emoji causes 404 GET requests!
      new Notification(title, { body })
    }
  }, [])

  // Execute a NEXA action — with task tracking for multitasking
  const executeAction = useCallback((action: NexaAction) => {
    // ★ FINAL DEFENSE: Block conversational actions even if they slip through other guards
    if (shouldBlockAction(action)) {
      console.log('[NEXA] 🛑 Blocked action in executeAction (conversational guard):', action.type, action.label)
      return
    }

    console.log('[NEXA] ★ Executing action:', JSON.stringify(action, null, 2))

    const toast: ActionToast = { id: Date.now().toString(), action, timestamp: Date.now() }
    setActionToasts(prev => [...prev, toast])
    // Keep toasts with URLs visible longer so user can click "Open" if auto-open failed
    const hasUrl = action.url || action.appUrl
    setTimeout(() => {
      setActionToasts(prev => prev.filter(t => t.id !== toast.id))
    }, hasUrl ? 8000 : 4000)

    // Create a task for tracking
    const taskId = `task-${Date.now()}-${++taskCounterRef.current}`
    const task: NexaTask = {
      id: taskId,
      type: action.type,
      label: action.label,
      status: 'running',
      createdAt: Date.now(),
    }
    useNexaStore.getState().addTask(task)

    const completeTask = (status: NexaTask['status'] = 'completed') => {
      useNexaStore.getState().updateTask(taskId, { status, completedAt: Date.now() })
      // Auto-remove completed tasks after 10 seconds
      if (status === 'completed' || status === 'failed') {
        setTimeout(() => {
          useNexaStore.getState().removeTask(taskId)
        }, 10000)
      }
    }

    switch (action.type) {
      case 'open':
      case 'search':
      case 'whatsapp':
      case 'map':
      case 'play':
      case 'message':
      case 'sms':
      case 'email': {
        // Open the URL directly — tries new tab, falls back to same-tab navigation
        const opened = openActionUrl(action)

        // Show AppLaunchOverlay for 'open' actions — gives user smooth animation + manual Open button
        if (action.type === 'open') {
          setPendingAction({
            id: `launch-${Date.now()}`,
            action,
            autoOpened: opened, // true if URL opened successfully, false if needs manual click
            createdAt: Date.now(),
          })
        }

        sendNotification('NEXA Action', action.label)
        setTimeout(() => completeTask('completed'), 1000)
        break
      }
      case 'appnotfound': {
        // Show app not found overlay
        setPendingAction({
          id: `notfound-${Date.now()}`,
          action,
          autoOpened: false,
          createdAt: Date.now(),
        })
        completeTask('failed')
        break
      }

      case 'call':
        // tel: URLs need special handling — use window.location.href
        if (action.appUrl || action.url) {
          window.location.href = action.appUrl || action.url!
        }
        sendNotification('NEXA Action', action.label)
        setTimeout(() => completeTask('completed'), 1000)
        break

      case 'timer': {
        const totalSeconds = action.seconds || 0
        if (totalSeconds <= 0) {
          completeTask('failed')
          break
        }

        // Update task progress
        useNexaStore.getState().updateTask(taskId, { progress: 100 })

        // Also keep the legacy single-timer overlay for the most recent timer
        setTimerInfo({ remaining: totalSeconds, total: totalSeconds, label: action.label })

        const timerKey = taskId
        let elapsed = 0

        const interval = setInterval(() => {
          elapsed++
          const remaining = totalSeconds - elapsed
          const progress = Math.round((remaining / totalSeconds) * 100)

          useNexaStore.getState().updateTask(taskId, { progress })

          // Update legacy timer overlay for the latest timer
          setTimerInfo(prev => {
            if (!prev || prev.label !== action.label) return prev
            if (remaining <= 0) return null
            return { ...prev, remaining }
          })

          if (remaining <= 0) {
            clearInterval(interval)
            timerIntervalsRef.current.delete(timerKey)
            completeTask('completed')

            sa.setStatusText('⏱️ Timer complete!')
            if (synthRef.current) {
              const utterance = new SpeechSynthesisUtterance('Timer complete! Time is up!')
              utterance.rate = 1.0
              synthRef.current.speak(utterance)
            }
            if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 200])
            sendNotification('⏱️ Timer Complete!', action.label)

            setTimeout(() => {
              const runningTasks = useNexaStore.getState().tasks.filter(t => t.status === 'running')
              if (runningTasks.length === 0) {
                sa.setStatusText('Tap karke bolo 💬')
                if (useNexaStore.getState().isAlwaysListening) {
                  startWakeWordListeningRef.current()
                }
              }
            }, 3000)
          } else {
            const mins = Math.floor(remaining / 60)
            const secs = remaining % 60
            // Only update status text if this is the only running task
            const runningTasks = useNexaStore.getState().tasks.filter(t => t.status === 'running')
            if (runningTasks.length === 1) {
              sa.setStatusText(`⏱️ ${mins}m ${secs}s remaining`)
            } else {
              sa.setStatusText(`⚡ ${runningTasks.length} tasks running...`)
            }
          }
        }, 1000)

        timerIntervalsRef.current.set(timerKey, interval)
        break
      }

      case 'note':
        sa.addMessage({ text: `📝 Note saved: ${action.data}`, isUser: false, timestamp: Date.now() })
        completeTask('completed')
        break

      case 'generate_image': {
        // Generate image from text description using AI
        const imagePrompt = action.data || action.label
        if (!imagePrompt) {
          completeTask('failed')
          break
        }
        sa.setStatusText('🎨 Image bana rahi hoon...')
        sa.setOrbState('thinking')

        // Call image generation API
        fetch('/api/nexa/generate-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: imagePrompt }),
        })
          .then(res => res.json())
          .then(data => {
            if (data.success && data.imageUrl) {
              sa.addMessage({
                text: `🎨 Image ready: "${imagePrompt}"`,
                isUser: false,
                timestamp: Date.now(),
                imageUrl: data.imageUrl,
              })
              fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: `🎨 Image generated: ${imagePrompt}`, isUser: false }),
              }).catch(() => {})
              sendNotification('NEXA Image', `Image generated: ${imagePrompt}`)
              sa.setStatusText('🎨 Image ban gayi!')
              speakText(`Image ban gayi! ${imagePrompt}`)
            } else {
              sa.addMessage({
                text: `⚠️ Image nahi ban payi. Dubara try karo!`,
                isUser: false,
                timestamp: Date.now(),
              })
              sa.setStatusText('Image generation failed')
            }
            completeTask(data.success ? 'completed' : 'failed')
            sa.setOrbState('idle')
          })
          .catch(err => {
            console.error('[NEXA] Image generation error:', err)
            sa.addMessage({
              text: `⚠️ Image nahi ban payi. Server error. Dubara try karo!`,
              isUser: false,
              timestamp: Date.now(),
            })
            completeTask('failed')
            sa.setOrbState('idle')
            sa.setStatusText('Image generation failed')
          })
        break
      }

      default:
        completeTask('completed')
    }
  }, [openActionUrl, sendNotification])

  // Init speech synthesis
  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      synthRef.current = window.speechSynthesis
      sa.setConnected(true)
      sa.setStatusText('Ready! Tap mic to talk 💬')
    }
  }, [])

  // Request notification permission on load
  useEffect(() => {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        notificationsRef.current = true
      } else if (Notification.permission !== 'denied') {
        // We'll request when user enables BG mode
      }
    }
  }, [])

  // Register service worker for PWA
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').then((reg) => {
        console.log('[NEXA PWA] Service Worker registered:', reg.scope)
      }).catch((err) => {
        console.log('[NEXA PWA] SW registration failed:', err)
      })
    }
  }, [])

  // Show install badge after 5 seconds
  useEffect(() => {
    if (canInstall) {
      const timer = setTimeout(() => setShowAppBadge(true), 5000)
      return () => clearTimeout(timer)
    }
  }, [canInstall])

  // Handle visibility change — for background mode + keep speech alive
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden) {
        sa.setBackgroundMode(true)
        // Keep speech synthesis alive in background by speaking empty utterance periodically
        // Chrome pauses speechSynthesis in background tabs — this workaround keeps it alive
        if (synthRef.current && useNexaStore.getState().isAlwaysListening) {
          const keepAlive = setInterval(() => {
            if (!document.hidden || !useNexaStore.getState().isAlwaysListening) {
              clearInterval(keepAlive)
              return
            }
            // Chrome workaround: resume speech synthesis
            if (synthRef.current && synthRef.current.paused) {
              synthRef.current.resume()
            }
          }, 5000)
        }
      } else {
        sa.setBackgroundMode(false)
      }
    }
    document.addEventListener('visibilitychange', handleVisibility)
    return () => document.removeEventListener('visibilitychange', handleVisibility)
  }, [])

  // Status timer
  useEffect(() => {
    const updateStatus = () => {
      const now = new Date()
      const time = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
      setStatusInfo({ time })
    }
    updateStatus()
    const interval = setInterval(updateStatus, 1000)
    return () => clearInterval(interval)
  }, [])

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Load settings on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const settingsRes = await fetch('/api/settings')
        if (settingsRes.ok) {
          const data = await settingsRes.json()
          sa.updateSettings({
            apiKey: data.hasApiKey ? '__LOADED__' : '',
            userName: data.userName || 'User',
            personalityMode: data.personalityMode || 'assistant',
            geminiModel: data.geminiModel || 'models/gemini-2.5-flash-native-audio-preview-12-2025',
            geminiVoice: data.geminiVoice || 'Aoede',
            language: data.language || 'auto',
          })
          sa.setStatusText('Ready! Tap mic to talk 💬')
        }
        const chatRes = await fetch('/api/chat')
        if (chatRes.ok) {
          const msgs = await chatRes.json()
          if (msgs.length > 0) {
            sa.clearMessages()
            msgs.forEach((msg: { text: string; isUser: boolean; timestamp: string | number }) => {
              sa.addMessage({
                text: msg.text,
                isUser: msg.isUser,
                timestamp: typeof msg.timestamp === 'string' ? new Date(msg.timestamp).getTime() : msg.timestamp,
              })
            })
          }
        }
        const contactsRes = await fetch('/api/prime-contacts')
        if (contactsRes.ok) {
          const contacts = await contactsRes.json()
          sa.setPrimeContacts(contacts.map((c: { id: string; name: string; number: string }) => ({
            id: c.id, name: c.name, number: c.number,
          })))
        }
      } catch (err) {
        console.error('Failed to load data:', err)
      }
    }
    loadData()
  }, [])

  // Speak text using browser TTS — with background workaround
  const speakText = useCallback((text: string) => {
    if (!synthRef.current) return
    synthRef.current.cancel()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 1.0
    utterance.pitch = 1.1
    utterance.volume = 1.0

    const voices = synthRef.current.getVoices()
    const preferred = voices.find(v => v.name.includes('Google') && v.lang.startsWith('en'))
      || voices.find(v => v.lang.startsWith('en') && v.name.includes('Female'))
      || voices.find(v => v.lang.startsWith('en'))
    if (preferred) utterance.voice = preferred

    // Chrome background speech workaround: resume periodically
    const resumeInterval = setInterval(() => {
      if (synthRef.current && synthRef.current.paused) {
        synthRef.current.resume()
      }
    }, 3000)

    utterance.onstart = () => {
      sa.setSpeaking(true)
      sa.setOrbState('speaking')
      sa.setStatusText('Bol rahi hoon...')
      setShowRedOverlay(true)
    }

    utterance.onend = () => {
      clearInterval(resumeInterval)
      sa.setSpeaking(false)
      setShowRedOverlay(false)
      sa.setOrbState('idle')
      if (useNexaStore.getState().isAlwaysListening) {
        setTimeout(() => startWakeWordListeningRef.current(), 300)
      } else {
        sa.setStatusText('Tap karke bolo 💬')
      }
    }

    utterance.onerror = () => {
      clearInterval(resumeInterval)
      sa.setSpeaking(false)
      setShowRedOverlay(false)
      sa.setOrbState('idle')
      if (useNexaStore.getState().isAlwaysListening) {
        setTimeout(() => startWakeWordListeningRef.current(), 300)
      } else {
        sa.setStatusText('Tap karke bolo 💬')
      }
    }

    synthRef.current.speak(utterance)
  }, [])

  // Send message to AI — with optional screenshot for screen vision
  // OFFLINE SUPPORT: If server is down, actions still work + local responses
  const sendToAI = useCallback(async (userText: string, photoBase64?: string | null) => {
    if (isProcessingRef.current) return

    // Client-side debounce: enforce minimum 3s between requests
    const now = Date.now()
    const timeSinceLastRequest = now - lastRequestTimeRef.current
    if (timeSinceLastRequest < 3000) {
      const waitTime = 3000 - timeSinceLastRequest
      sa.setStatusText(`Please wait ${Math.ceil(waitTime / 1000)}s...`)
      await new Promise(r => setTimeout(r, waitTime))
    }
    if (isProcessingRef.current) return // Double-check after waiting

    isProcessingRef.current = true
    lastRequestTimeRef.current = Date.now()

    // ★ CONVERSATIONAL GUARD: Track the user message so we can block
    // AI-generated actions for conversational questions like "what is your name"
    lastUserMessage = userText

    sa.setOrbState('thinking')
    sa.setStatusText('Soch rahi hoon...')

    // Track actions received from AI so we can detect missed ones
    const aiActionsReceived: NexaAction[] = []

    // ===== PRE-DETECT ACTIONS FROM USER TEXT =====
    // These are detected client-side for faster response
    // For text input, actions are already opened in handleSendText (in user gesture context)
    // For voice input, actions will be opened here via openActionUrl (with fallback chain)
    const currentContacts = useNexaStore.getState().primeContacts
    const preDetectedActions = detectActionsFromText(userText, currentContacts.map(c => ({ name: c.name, number: c.number })))

    if (preDetectedActions.length > 0) {
      for (const action of preDetectedActions) {
        // ★ CONVERSATIONAL GUARD: Skip actions for conversational messages
        if (shouldBlockAction(action)) {
          console.log('[NEXA] 🛑 Blocked pre-detected action (conversational):', action.type, action.label)
          continue
        }
        const targetUrl = action.url || action.appUrl
        if (targetUrl) {
          console.log('[NEXA] 🚀 Pre-detected action:', action.label, targetUrl)
          // Mark as opened so AI response doesn't duplicate
          openedActionUrls.add(targetUrl)
          setTimeout(() => openedActionUrls.delete(targetUrl), 30000)

          // ★ Open URL directly — tries new tab first, falls back to same-tab navigation
          // Same-tab navigation ALWAYS works (no popup blocker can stop it)
          const opened = openUrlDirect(targetUrl)

          if (action.type === 'open') {
            setPendingAction({
              id: `launch-${Date.now()}`,
              action,
              autoOpened: opened,
              createdAt: Date.now(),
            })
          }

          // Show toast notification
          const toast: ActionToast = { id: `pre-${Date.now()}`, action, timestamp: Date.now() }
          setActionToasts(prev => [...prev, toast])
          setTimeout(() => {
            setActionToasts(prev => prev.filter(t => t.id !== toast.id))
          }, 4000)
          // Add task for tracking
          const taskId = `task-${Date.now()}-${++taskCounterRef.current}`
          useNexaStore.getState().addTask({
            id: taskId,
            type: action.type,
            label: action.label,
            status: 'completed',
            createdAt: Date.now(),
            completedAt: Date.now(),
          })
          setTimeout(() => {
            useNexaStore.getState().removeTask(taskId)
          }, 5000)
        }
      }
    }

    try {
      const currentSettings = useNexaStore.getState().settings
      const systemPrompt = buildSystemPrompt(currentSettings.userName, currentSettings.personalityMode, currentSettings.language)

      // Take screenshot if screen sharing is active
      // Limit screenshot size to prevent oversized request bodies that cause Failed to fetch
      let screenshot: string | null = null
      if (useNexaStore.getState().isScreenSharing) {
        const rawScreenshot = takeScreenshot()
        if (rawScreenshot) {
          // If screenshot is too large (>500KB base64), skip it to avoid network errors
          const sizeKB = Math.round(rawScreenshot.length * 0.75 / 1024)
          if (sizeKB < 500) {
            screenshot = rawScreenshot
            sa.setStatusText('👀 Screen dekh rahi hoon...')
          } else {
            console.log('[NEXA] Screenshot too large (' + sizeKB + 'KB), skipping to avoid network error')
            screenshot = null
          }
        }
      }

      // Build conversation history for memory — last 20 messages
      const currentMessages = useNexaStore.getState().messages
      const chatHistory = currentMessages.slice(-20).map(m => ({
        text: m.text,
        isUser: m.isUser,
      }))

      // Single fetch — backend handles retry logic internally with 429 backoff
      // Frontend just needs a long timeout (120s) to accommodate backend retries
      const requestBody: Record<string, unknown> = {
        action: 'chat',
        text: userText,
        systemPrompt,
        contacts: currentContacts.map(c => ({ name: c.name, number: c.number })),
        history: chatHistory,
      }

      // Only include screenshot if it's not too large
      if (screenshot) {
        requestBody.screenshot = screenshot
      }

      // Include uploaded photo as screenshot for VLM analysis
      if (photoBase64) {
        requestBody.screenshot = photoBase64
        sa.setStatusText('📸 Photo dekh rahi hoon...')
      }

      // Long timeout (120s) because backend retries internally with up to 60s waits
      // BUT if server was recently unavailable, use short timeout (5s) for quick fallback
      const isServerRecentlyDown = !serverAvailable && (Date.now() - lastServerCheck < 60000) // 60s cooldown
      const timeout = isServerRecentlyDown ? 5000 : 120000
      const abortController = new AbortController()
      const timeoutId = setTimeout(() => abortController.abort(), timeout)

      const response = await fetch('/api/nexa/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
        signal: abortController.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok || !response.body) {
        throw new Error(`HTTP ${response.status}`)
      }

      // Server is available! Mark it so future requests use normal timeout
      serverAvailable = true
      setIsServerDown(false)

      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let fullText = ''
      let sseBuffer = ''
      let currentEvent = ''
      let currentData = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        sseBuffer += decoder.decode(value, { stream: true })
        const lines = sseBuffer.split('\n')
        sseBuffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('event: ')) currentEvent = line.slice(7).trim()
          else if (line.startsWith('data: ')) currentData = line.slice(6).trim()
          else if (line === '' && currentEvent && currentData) {
            try {
              const data = JSON.parse(currentData)
              if (currentEvent === 'text') {
                fullText = data.text
                sa.setOutputTranscript(fullText)
              } else if (currentEvent === 'action') {
                const action = data as NexaAction
                // ★ CONVERSATIONAL GUARD: Block actions for conversational messages
                // e.g., AI generates [ACTION:search|what is your name] or [ACTION:open|google]
                if (shouldBlockAction(action)) {
                  console.log('[NEXA] 🛑 Blocked AI action for conversational message:', action.type, action.label)
                  // Don't add to aiActionsReceived and don't execute
                } else {
                  aiActionsReceived.push(action)
                  console.log('[NEXA] AI action received:', action.type, action.label)
                  executeAction(action)
                }
              } else if (currentEvent === 'complete') {
                const aiText = data.fullText || fullText

                // FALLBACK: If AI didn't generate action tags AND we didn't pre-detect, detect from user text
                // But BLOCK fallback actions for conversational messages
                let finalActions = [...aiActionsReceived]
                if (aiActionsReceived.length === 0 && preDetectedActions.length === 0) {
                  const fallbackActions = detectActionsFromText(userText, currentContacts.map(c => ({ name: c.name, number: c.number })))
                  // ★ CONVERSATIONAL GUARD: Filter out blocked actions
                  const allowedFallback = fallbackActions.filter(a => !shouldBlockAction(a))
                  if (allowedFallback.length > 0) {
                    console.log('[NEXA] ⚡ Fallback actions detected (AI missed them):', allowedFallback.map(a => a.label))
                    for (const fa of allowedFallback) {
                      executeAction(fa)
                    }
                    finalActions = allowedFallback
                  }
                }

                // Merge pre-detected actions with AI actions for chat display
                if (preDetectedActions.length > 0) {
                  finalActions = [...finalActions, ...preDetectedActions]
                }

                if (aiText.trim()) {
                  // Store actions with the chat message so they appear as clickable cards
                  const chatActions = finalActions
                    .filter(a => a.url || a.type === 'timer' || a.type === 'note' || a.type === 'generate_image')
                    .map(a => ({
                      type: a.type,
                      label: a.label,
                      url: a.url,
                    }))

                  sa.addMessage({
                    text: aiText.trim(),
                    isUser: false,
                    timestamp: Date.now(),
                    actions: chatActions.length > 0 ? chatActions : undefined,
                  })
                  fetch('/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ text: aiText.trim(), isUser: false }),
                  }).catch(() => {})
                  sendNotification('NEXA says', aiText.trim().substring(0, 100))
                  speakText(aiText.trim())
                }

                // Clear dedup tracking
                openedActionUrls.clear()
                sa.clearTranscripts()
              } else if (currentEvent === 'status') {
                // Backend retry status — show to user so they know we're working on it
                sa.setStatusText(data.message || 'Processing...')
                sa.setOrbState('thinking')
              } else if (currentEvent === 'error') {
                const errMsg = data.message || 'Something went wrong. Please try again.'
                const isServerBusy = errMsg.toLowerCase().includes('busy') || errMsg.toLowerCase().includes('rate') || errMsg.toLowerCase().includes('too many')
                const isServerDown = errMsg.toLowerCase().includes('failed') || errMsg.toLowerCase().includes('no response')

                if (isServerDown) {
                  // Server is down — mark as offline and generate local response
                  serverAvailable = false
                  lastServerCheck = Date.now()
                  setIsServerDown(true)

                  const currentSettings = useNexaStore.getState().settings
                  const localResponse = generateLocalResponse(userText, currentSettings.userName)
                  const chatActions = preDetectedActions
                    .filter(a => a.url || a.type === 'timer' || a.type === 'note' || a.type === 'generate_image')
                    .map(a => ({ type: a.type, label: a.label, url: a.url }))

                  sa.addMessage({
                    text: localResponse,
                    isUser: false,
                    timestamp: Date.now(),
                    actions: chatActions.length > 0 ? chatActions : undefined,
                  })
                  sa.setStatusText('📡 Offline mode — Actions chalu hain!')
                  sa.setOrbState('idle')
                  speakText(localResponse)
                } else {
                  sa.setStatusText(isServerBusy ? 'Server busy. Try again in a moment.' : 'Error. Try again.')
                  sa.setOrbState('idle')
                  sa.addMessage({
                    text: isServerBusy ? `⚠️ Server busy hai. Thodi der mein try karo!` : `⚠️ ${errMsg}`,
                    isUser: false,
                    timestamp: Date.now(),
                  })
                }
              }
            } catch (e) {
              console.error('[NEXA] SSE parse error:', e, currentEvent, currentData)
            }
            currentEvent = ''
            currentData = ''
          }
        }
      }
    } catch (err) {
      console.warn('[NEXA] AI server error:', err)
      const isNetworkError = err instanceof Error && (err.message.includes('fetch') || err.message.includes('network') || err.message.includes('Failed'))
      const isTimeout = err instanceof Error && err.message.includes('abort')

      // Mark server as unavailable so we can skip future attempts temporarily
      serverAvailable = false
      lastServerCheck = Date.now()
      setIsServerDown(true)

      // ★ OFFLINE MODE — Use local response generator instead of showing error
      // Actions were already pre-detected and executed above, so the user's command still works!
      const currentSettings = useNexaStore.getState().settings
      const localResponse = generateLocalResponse(userText, currentSettings.userName)

      // Build action cards from pre-detected actions
      const chatActions = preDetectedActions
        .filter(a => a.url || a.type === 'timer' || a.type === 'note' || a.type === 'generate_image')
        .map(a => ({
          type: a.type,
          label: a.label,
          url: a.url,
        }))

      sa.addMessage({
        text: localResponse,
        isUser: false,
        timestamp: Date.now(),
        actions: chatActions.length > 0 ? chatActions : undefined,
      })

      // Show offline status
      if (isNetworkError) {
        sa.setStatusText('📡 Offline mode — Actions chalu hain!')
      } else if (isTimeout) {
        sa.setStatusText('⏱️ Server slow — Offline mode active')
      } else {
        sa.setStatusText('📡 Offline mode — Actions chalu hain!')
      }
      sa.setOrbState('idle')

      // Speak the local response too
      speakText(localResponse)
    }

    isProcessingRef.current = false
  }, [speakText, executeAction, sendNotification, takeScreenshot, openActionUrl])

  // ============ WAKE WORD LISTENING (Background Always-Listening Mode) ============
  const startWakeWordListening = useCallback(() => {
    if (isProcessingRef.current || isWakeListeningRef.current || isCommandListeningRef.current) return

    const SpeechRecognition = (window as unknown as { SpeechRecognition?: typeof window.SpeechRecognition; webkitSpeechRecognition?: typeof window.SpeechRecognition }).SpeechRecognition || (window as unknown as { webkitSpeechRecognition?: typeof window.SpeechRecognition }).webkitSpeechRecognition
    if (!SpeechRecognition) return

    const recognition = new SpeechRecognition()
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = 'en-IN'

    let wakeDetected = false

    recognition.onstart = () => {
      isWakeListeningRef.current = true
      sa.setOrbState('active')
      sa.setStatusText('🎤 Always listening — Say "Hey NEXA"')
    }

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript.toLowerCase().trim()

        if (!wakeDetected) {
          const found = WAKE_WORDS.some(w => transcript.includes(w))
          if (found) {
            wakeDetected = true
            console.log('[NEXA] Wake word detected!')
            sa.setOrbState('listening')
            sa.setStatusText('🎤 Yes? Bolo...')
            sa.setAmplitude(0.5)

            if (navigator.vibrate) navigator.vibrate(100)

            recognition.stop()
            isWakeListeningRef.current = false

            setTimeout(() => startCommandListening(), 200)
            return
          }
        }
      }
    }

    recognition.onerror = (event) => {
      console.log('[NEXA] Wake word error:', event.error)
      isWakeListeningRef.current = false
      if (useNexaStore.getState().isAlwaysListening && event.error !== 'not-allowed') {
        setTimeout(() => startWakeWordListening(), 500)
      }
    }

    recognition.onend = () => {
      isWakeListeningRef.current = false
      if (useNexaStore.getState().isAlwaysListening && !isCommandListeningRef.current && !isProcessingRef.current) {
        setTimeout(() => startWakeWordListening(), 300)
      }
    }

    alwaysListenRef.current = recognition
    try {
      recognition.start()
    } catch (err) {
      console.error('[NEXA] Wake word start error:', err)
    }
  }, [])
  startWakeWordListeningRef.current = startWakeWordListening

  // Start command listening after wake word detected (Hindi mode)
  const startCommandListening = useCallback(() => {
    if (isCommandListeningRef.current) return

    const SpeechRecognition = (window as unknown as { SpeechRecognition?: typeof window.SpeechRecognition; webkitSpeechRecognition?: typeof window.SpeechRecognition }).SpeechRecognition || (window as unknown as { webkitSpeechRecognition?: typeof window.SpeechRecognition }).webkitSpeechRecognition
    if (!SpeechRecognition) return

    const recognition = new SpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = true
    recognition.lang = getRecognitionLang(useNexaStore.getState().settings.language)

    let finalTranscript = ''

    recognition.onstart = () => {
      isCommandListeningRef.current = true
      sa.setRecording(true)
      sa.setOrbState('listening')
      sa.setStatusText('🎤 Sun rahi hoon... bolo!')
      sa.setAmplitude(0.4)
    }

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interim = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript
        if (event.results[i].isFinal) {
          finalTranscript += transcript
        } else {
          interim += transcript
        }
      }
      sa.setInputTranscript(finalTranscript + interim)
      sa.setAmplitude(0.3 + Math.random() * 0.4)
    }

    recognition.onend = () => {
      isCommandListeningRef.current = false
      sa.setRecording(false)
      sa.setAmplitude(0)
      sa.setInputTranscript('')

      if (finalTranscript.trim()) {
        let cleanText = finalTranscript.trim()
        WAKE_WORDS.forEach(w => {
          if (cleanText.toLowerCase().startsWith(w)) {
            cleanText = cleanText.slice(w.length).trim()
          }
        })
        if (cleanText) {
          sa.addMessage({ text: cleanText, isUser: true, timestamp: Date.now() })
          fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: cleanText, isUser: true }),
          }).catch(() => {})
          sendToAI(cleanText)
        }
      } else {
        sa.setOrbState('active')
        sa.setStatusText('🎤 Always listening — Say "Hey NEXA"')
        if (useNexaStore.getState().isAlwaysListening) {
          setTimeout(() => startWakeWordListening(), 300)
        } else {
          sa.setOrbState('idle')
          sa.setStatusText('Tap karke bolo 💬')
        }
      }
    }

    recognition.onerror = (event) => {
      // "no-speech" and "aborted" are normal — don't log as error
      const isNormal = event.error === 'no-speech' || event.error === 'aborted' || event.error === 'network'
      if (!isNormal) {
        console.error('[NEXA] Command error:', event.error)
      } else {
        console.log('[NEXA] Command event:', event.error)
      }
      isCommandListeningRef.current = false
      sa.setRecording(false)
      sa.setAmplitude(0)
      if (useNexaStore.getState().isAlwaysListening) {
        sa.setOrbState('active')
        sa.setStatusText('🎤 Always listening — Say "Hey NEXA"')
        setTimeout(() => startWakeWordListening(), 500)
      } else {
        sa.setOrbState('idle')
        sa.setStatusText('Tap karke bolo 💬')
      }
    }

    recognitionRef.current = recognition
    try {
      recognition.start()
    } catch (err) {
      console.error('[NEXA] Command start error:', err)
      isCommandListeningRef.current = false
    }
  }, [sendToAI])

  // Toggle always-listening mode
  const toggleAlwaysListening = useCallback(() => {
    const newState = !useNexaStore.getState().isAlwaysListening
    sa.setAlwaysListening(newState)

    if (newState) {
      if ('Notification' in window && Notification.permission !== 'granted') {
        Notification.requestPermission().then(perm => {
          notificationsRef.current = perm === 'granted'
        })
      }
      startWakeWordListening()
    } else {
      if (alwaysListenRef.current) {
        alwaysListenRef.current.stop()
        alwaysListenRef.current = null
      }
      isWakeListeningRef.current = false
      if (!isProcessingRef.current && !isCommandListeningRef.current) {
        sa.setOrbState('idle')
        sa.setStatusText('Tap karke bolo 💬')
      }
    }
  }, [])

  // Update ref for PiP handler
  toggleAlwaysListeningRef.current = toggleAlwaysListening

  // Handle PiP events — uses refs so handlers always get latest function
  useEffect(() => {
    const handlePipMic = () => toggleMicRef.current()
    const handlePipScreen = () => handleToggleScreenRef.current()
    const handlePipEar = () => toggleAlwaysListeningRef.current()

    window.addEventListener('nexa-pip-mic-toggle', handlePipMic)
    window.addEventListener('nexa-pip-screen-toggle', handlePipScreen)
    window.addEventListener('nexa-pip-ear-toggle', handlePipEar)
    return () => {
      window.removeEventListener('nexa-pip-mic-toggle', handlePipMic)
      window.removeEventListener('nexa-pip-screen-toggle', handlePipScreen)
      window.removeEventListener('nexa-pip-ear-toggle', handlePipEar)
    }
  }, [])

  // Handle screen share toggle
  const handleToggleScreen = useCallback(async () => {
    try {
      const result = await toggleScreenCapture()
      if (result.success) {
        sa.setStatusText('👀 Screen sharing ON — NEXA can see your screen!')
        setScreenCaptureUnavailable(null)
      } else {
        if (result.error) {
          // Show the error message gracefully
          setScreenCaptureUnavailable(result.error)
          sa.setStatusText('⚠️ Screen capture unavailable')
          // Auto-clear the error after 5 seconds
          setTimeout(() => {
            setScreenCaptureUnavailable(null)
            sa.setStatusText('Tap karke bolo 💬')
          }, 5000)
        } else {
          sa.setStatusText('Screen sharing OFF')
        }
      }
    } catch (err) {
      console.warn('[NEXA] Screen toggle error:', err)
      setScreenCaptureUnavailable('Screen capture failed. Try opening NEXA in a new tab.')
      sa.setStatusText('⚠️ Screen capture failed')
      setTimeout(() => {
        setScreenCaptureUnavailable(null)
        sa.setStatusText('Tap karke bolo 💬')
      }, 5000)
    }
  }, [toggleScreenCapture])

  // Update ref for PiP handler
  handleToggleScreenRef.current = handleToggleScreen

  // Start single speech recognition (tap mode)
  const startListening = useCallback(() => {
    if (isProcessingRef.current) return
    if (isAlwaysListening) {
      toggleAlwaysListening()
      return
    }

    // Note: No need to pre-open window anymore — we use window.location.href as fallback
    // which always works regardless of popup blockers (same-tab navigation)

    const SpeechRecognition = (window as unknown as { SpeechRecognition?: typeof window.SpeechRecognition; webkitSpeechRecognition?: typeof window.SpeechRecognition }).SpeechRecognition || (window as unknown as { webkitSpeechRecognition?: typeof window.SpeechRecognition }).webkitSpeechRecognition
    if (!SpeechRecognition) {
      sa.setStatusText('Speech not supported. Use text input.')
      return
    }

    const recognition = new SpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = true
    recognition.lang = getRecognitionLang(useNexaStore.getState().settings.language)

    let finalTranscript = ''

    recognition.onstart = () => {
      sa.setRecording(true)
      sa.setOrbState('listening')
      sa.setStatusText('Sun rahi hoon...')
      sa.setAmplitude(0.3)
    }

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interim = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript
        if (event.results[i].isFinal) finalTranscript += transcript
        else interim += transcript
      }
      sa.setInputTranscript(finalTranscript + interim)
      sa.setAmplitude(0.3 + Math.random() * 0.4)
    }

    recognition.onend = () => {
      sa.setRecording(false)
      sa.setAmplitude(0)
      sa.setInputTranscript('')

      if (finalTranscript.trim()) {
        sa.addMessage({ text: finalTranscript.trim(), isUser: true, timestamp: Date.now() })
        fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: finalTranscript.trim(), isUser: true }),
        }).catch(() => {})
        sendToAI(finalTranscript.trim())
      } else {
        // No speech detected
        sa.setOrbState('idle')
        sa.setStatusText('Tap karke bolo 💬')
      }
    }

    recognition.onerror = (event) => {
      // "no-speech" and "aborted" are normal — user just didn't speak or cancelled. Don't log as error.
      const isNormal = event.error === 'no-speech' || event.error === 'aborted' || event.error === 'network'
      if (!isNormal) {
        console.error('[NEXA] Speech error:', event.error)
      } else {
        console.log('[NEXA] Speech event:', event.error)
      }
      sa.setRecording(false)
      sa.setAmplitude(0)
      if (event.error === 'not-allowed') {
        sa.setStatusText('⚠️ Mic permission denied. Allow mic access.')
      } else if (event.error === 'no-speech') {
        // Normal — just didn't hear anything
        sa.setOrbState('idle')
        sa.setStatusText('Kuch sunai nahi diya. Fir se bolo 💬')
      } else {
        sa.setStatusText('Try again. Tap mic to talk 💬')
        sa.setOrbState('idle')
      }
    }

    recognitionRef.current = recognition
    recognition.start()
  }, [sendToAI, isAlwaysListening, toggleAlwaysListening])

  // Toggle mic
  const toggleMic = useCallback(() => {
    if (isSpeaking && synthRef.current) {
      synthRef.current.cancel()
      sa.setSpeaking(false)
      setShowRedOverlay(false)
      sa.setOrbState('idle')
      sa.setStatusText('Tap karke bolo 💬')
      return
    }

    if (isRecording && recognitionRef.current) {
      recognitionRef.current.stop()
      return
    }

    // Start listening
    startListening()
  }, [isSpeaking, isRecording, startListening])

  // Update ref for PiP handler
  toggleMicRef.current = toggleMic

  // Send text message — KEY: detect actions and open DIRECTLY during click handler!
  // This means window.open() is called synchronously in user gesture context = GUARANTEED to work!
  const handleSendText = useCallback(() => {
    if (!textInput.trim() || isProcessingRef.current) return

    const msg = textInput.trim()

    // ★ DETECT ACTIONS AND OPEN DIRECTLY — this is the KEY fix!
    // We are inside the click handler, so window.open() ALWAYS works (user gesture context)
    // But BLOCK actions for conversational messages like "what is your name"
    lastUserMessage = msg
    const currentContacts = useNexaStore.getState().primeContacts
    const preActions = detectActionsFromText(msg, currentContacts.map(c => ({ name: c.name, number: c.number })))
    for (const action of preActions) {
      // ★ CONVERSATIONAL GUARD: Skip actions that should be blocked
      if (shouldBlockAction(action)) {
        console.log('[NEXA] 🛑 Blocked text input action (conversational):', action.type, action.label)
        continue
      }
      const targetUrl = action.url || action.appUrl
      if (targetUrl) {
        // Mark as opened so AI response doesn't duplicate
        openedActionUrls.add(targetUrl)
        setTimeout(() => openedActionUrls.delete(targetUrl), 30000)
        // Open DIRECTLY — uses <a> click (most reliable) then window.open fallback
        const opened = openUrlDirect(targetUrl)
        console.log('[NEXA] 🚀 Opened app from text input (user gesture):', action.label, opened ? '✅ Success' : '❌ Blocked')
        // Show AppLaunchOverlay for 'open' actions — gives user a smooth launch animation + manual Open button
        if (action.type === 'open') {
          setPendingAction({
            id: `launch-${Date.now()}`,
            action,
            autoOpened: opened, // true = app opened successfully, false = show "Open" button
            createdAt: Date.now(),
          })
        }
        // Show toast notification
        const toast: ActionToast = { id: `pre-${Date.now()}`, action, timestamp: Date.now() }
        setActionToasts(prev => [...prev, toast])
        setTimeout(() => {
          setActionToasts(prev => prev.filter(t => t.id !== toast.id))
        }, 4000)
      }
    }

    // Include photo if pending
    const photoToSend = pendingPhoto ? pendingPhoto.base64 : null

    // If photo exists, show it in the chat bubble
    if (pendingPhoto) {
      sa.addMessage({ text: msg + ' 📷', isUser: true, timestamp: Date.now() })
    } else {
      sa.addMessage({ text: msg, isUser: true, timestamp: Date.now() })
    }
    fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: msg, isUser: true }),
    }).catch(() => {})

    setTextInput('')
    setPendingPhoto(null)
    sendToAI(msg, photoToSend)
  }, [textInput, sendToAI, sa, openUrlDirect, pendingPhoto])

  // Handle settings save
  const handleSettingsSave = useCallback(async (newSettings: SettingsData) => {
    try {
      const apiKeyToSend = newSettings.apiKey.includes('****') ? undefined : newSettings.apiKey
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: apiKeyToSend,
          userName: newSettings.userName,
          personalityMode: newSettings.personalityMode,
          geminiModel: newSettings.geminiModel,
          geminiVoice: newSettings.geminiVoice,
          language: newSettings.language,
        }),
      })
      const existingContacts = await fetch('/api/prime-contacts').then(r => r.json())
      for (const c of existingContacts) {
        await fetch('/api/prime-contacts', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: c.id }) })
      }
      for (const contact of newSettings.primeContacts) {
        await fetch('/api/prime-contacts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: contact.name, number: contact.number }) })
      }
      sa.updateSettings({
        apiKey: apiKeyToSend || '__LOADED__',
        userName: newSettings.userName,
        personalityMode: newSettings.personalityMode,
        geminiModel: newSettings.geminiModel,
        geminiVoice: newSettings.geminiVoice,
        language: newSettings.language,
      })
      sa.setPrimeContacts(newSettings.primeContacts)
      sa.setStatusText('Settings saved! ✅')
    } catch (err) {
      console.error('Failed to save settings:', err)
    }
  }, [])

  // Clear chat
  const handleClearChat = useCallback(async () => {
    sa.clearMessages()
    await fetch('/api/chat', { method: 'DELETE' }).catch(() => {})
  }, [])

  // Load voices on mount
  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.getVoices()
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices()
      }
    }
  }, [])

  // Auto-dismiss pending action overlay after 15 seconds
  useEffect(() => {
    if (pendingAction) {
      const timer = setTimeout(() => {
        setPendingAction(null)
      }, 15000)
      return () => clearTimeout(timer)
    }
  }, [pendingAction])

  // Cleanup on unmount — stop all resources
  useEffect(() => {
    return () => {
      // Stop speech recognition
      if (recognitionRef.current) {
        try { recognitionRef.current.stop() } catch {}
        recognitionRef.current = null
      }
      if (alwaysListenRef.current) {
        try { alwaysListenRef.current.stop() } catch {}
        alwaysListenRef.current = null
      }

      // Stop speech synthesis
      if (synthRef.current) {
        synthRef.current.cancel()
      }

      // Clear all timers
      timerIntervalsRef.current.forEach((interval) => clearInterval(interval))
      timerIntervalsRef.current.clear()

      // Stop screen capture
      stopScreenCapture()

      console.log('[NEXA] Cleanup complete')
    }
  }, [stopScreenCapture])

  // Get action icon
  const getActionIcon = (type: NexaAction['type']) => {
    switch (type) {
      case 'open': return ExternalLink
      case 'search': return Search
      case 'whatsapp': return MessageCircle
      case 'message': return MessageCircle
      case 'call': return Phone
      case 'sms': return MessageSquare
      case 'email': return Mail
      case 'timer': return Timer
      case 'map': return MapPin
      case 'play': return Music
      case 'note': return StickyNote
      default: return ExternalLink
    }
  }

  const MicIcon = isRecording ? Mic : MicOff

  // ============ MINI FLOATING MODE ============
  if (isMiniMode) {
    return (
      <>
        <PiPWidget />
        <div className="fixed bottom-6 right-6 z-[100] flex flex-col items-center gap-2">
          {/* Screen share indicator */}
          {isScreenSharing && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: 'rgba(76,175,80,0.15)', border: '1px solid rgba(76,175,80,0.3)' }}>
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <Eye className="size-3 text-green-400" />
              <span className="text-[9px] text-green-400">Screen ON</span>
            </div>
          )}

          {/* Mini NEXA orb */}
          <div className="relative group">
            <button
              onClick={() => {
                if (isSpeaking && synthRef.current) {
                  synthRef.current.cancel()
                  sa.setSpeaking(false)
                  sa.setOrbState('idle')
                } else if (!isRecording && !isProcessingRef.current) {
                  if (isAlwaysListening) {
                    startCommandListening()
                  } else {
                    startListening()
                  }
                }
              }}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 ${isRecording ? 'mic-pulse' : ''} ${isAlwaysListening ? 'animate-pulse-subtle' : ''}`}
              style={{
                background: isRecording
                  ? 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)'
                  : isAlwaysListening
                  ? 'linear-gradient(135deg, #4CAF50 0%, #00BCD4 100%)'
                  : 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)',
                boxShadow: isRecording
                  ? '0 0 20px rgba(255,23,68,0.5)'
                  : isAlwaysListening
                  ? '0 0 20px rgba(76,175,80,0.4)'
                  : '0 0 15px rgba(255,23,68,0.2)',
              }}
              aria-label="NEXA mini assistant"
            >
              {isRecording ? <Mic className="size-6 text-white" /> : <MicOff className="size-6 text-white" />}
            </button>

            {/* Expand button */}
            <button
              onClick={() => sa.setMiniMode(false)}
              className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ background: '#333' }}
            >
              <Maximize2 className="size-3 text-white" />
            </button>
          </div>

          {/* Mini status */}
          <div className="px-3 py-1 rounded-full text-[9px] text-center whitespace-nowrap"
            style={{ background: 'rgba(255,23,68,0.15)', color: '#FF6D6D' }}>
            {isAlwaysListening ? (isScreenSharing ? '🎧👀 BG+Screen' : '🎧 BG Mode') : isRecording ? '🎤 Listening' : isSpeaking ? '🔊 Speaking' : 'Tap to talk'}
          </div>

          {/* Mini action toasts — with PROMINENT open button */}
          {actionToasts.length > 0 && (
            <div className="flex flex-col gap-1 items-center">
              {actionToasts.slice(-2).map((toast) => (
                <div key={toast.id} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[10px] text-white"
                  style={{ background: 'rgba(255,23,68,0.25)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,23,68,0.3)' }}>
                  <span className="truncate max-w-[80px]">{toast.action.label}</span>
                  {(toast.action.url || toast.action.appUrl) && toast.action.type !== 'timer' && toast.action.type !== 'note' && (
                    <a href={toast.action.url || toast.action.appUrl} target="_blank" rel="noopener noreferrer"
                      className="px-2 py-1 rounded text-[10px] font-bold no-underline flex items-center gap-1"
                      style={{ background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)', color: 'white' }}>
                      <ExternalLink className="size-2.5" />
                      Open
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Mini pending action — BIG open button for popup-blocked actions */}
          {pendingAction && (
            <div className="flex flex-col items-center gap-1.5 px-3 py-2 rounded-xl"
              style={{ background: 'rgba(255,23,68,0.2)', border: '1px solid rgba(255,23,68,0.4)', backdropFilter: 'blur(10px)' }}>
              <span className="text-[10px] text-white font-medium truncate max-w-[120px]">{pendingAction.action.label}</span>
              <a
                href={pendingAction.action.url || pendingAction.action.appUrl || '#'}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-lg text-[11px] font-bold no-underline flex items-center gap-1.5"
                style={{ background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)', color: 'white', boxShadow: '0 2px 10px rgba(255,23,68,0.4)' }}
                onClick={() => setPendingAction(null)}
              >
                <ExternalLink className="size-3" />
                TAP TO OPEN
              </a>
              <button onClick={() => setPendingAction(null)} className="text-[8px] text-gray-500">Dismiss</button>
            </div>
          )}

          <style jsx>{`
            @keyframes pulse-subtle {
              0%, 100% { box-shadow: 0 0 15px rgba(76,175,80,0.2); }
              50% { box-shadow: 0 0 25px rgba(76,175,80,0.5); }
            }
            .animate-pulse-subtle {
              animation: pulse-subtle 2s ease-in-out infinite;
            }
          `}</style>
        </div>
      </>
    )
  }

  // ============ FULL MODE ============
  return (
    <div className="fixed inset-0 flex flex-col" style={{ background: '#050505' }}>
      {/* PiP Widget (invisible, manages PiP window) */}
      <PiPWidget />

      <div className="fixed inset-0 pointer-events-none transition-opacity duration-300" style={{ backgroundColor: '#FF1744', opacity: showRedOverlay ? 0.08 : 0 }} />
      <div className="fixed inset-0 pointer-events-none" style={{
        background: `
          radial-gradient(ellipse at 10% 10%, rgba(255,23,68,0.06) 0%, transparent 50%),
          radial-gradient(ellipse at 90% 90%, rgba(213,0,249,0.05) 0%, transparent 50%),
          radial-gradient(ellipse at 50% 50%, rgba(255,23,68,0.02) 0%, transparent 70%)
        `
      }} />

      {/* Screen sharing indicator overlay */}
      {isScreenSharing && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: 'rgba(76,175,80,0.15)', border: '1px solid rgba(76,175,80,0.3)', backdropFilter: 'blur(10px)' }}>
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <Eye className="size-3 text-green-400" />
          <span className="text-[10px] text-green-400 font-medium">NEXA is watching your screen</span>
        </div>
      )}

      {/* Screen capture unavailable error banner */}
      {screenCaptureUnavailable && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2 rounded-xl max-w-[90vw]" style={{ background: 'rgba(255,152,0,0.15)', border: '1px solid rgba(255,152,0,0.3)', backdropFilter: 'blur(10px)' }}>
          <MonitorOff className="size-4 text-orange-400 flex-shrink-0" />
          <span className="text-[11px] text-orange-300">{screenCaptureUnavailable}</span>
          <button onClick={() => { setScreenCaptureUnavailable(null); clearScreenError() }} className="ml-2 text-orange-400 hover:text-orange-300 text-xs flex-shrink-0">✕</button>
        </div>
      )}

      {/* PWA Install Banner */}
      {canInstall && showInstallBanner && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl max-w-[92vw] animate-slide-up" style={{ background: 'linear-gradient(135deg, rgba(255,23,68,0.2) 0%, rgba(213,0,249,0.2) 100%)', border: '1px solid rgba(255,23,68,0.4)', backdropFilter: 'blur(20px)' }}>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)' }}>
            <Smartphone className="size-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[12px] font-semibold text-white">Install NEXA App</p>
            <p className="text-[10px] text-gray-400">Add to home screen for quick access</p>
          </div>
          <button
            onClick={async () => {
              const accepted = await promptInstall()
              if (accepted) setShowInstallBanner(false)
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium text-white flex-shrink-0"
            style={{ background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)' }}
          >
            <Download className="size-3" />
            Install
          </button>
          <button onClick={() => setShowInstallBanner(false)} className="text-gray-500 hover:text-gray-300 flex-shrink-0">
            <X className="size-4" />
          </button>
        </div>
      )}

      {/* Action Toast Notifications — more prominent Open button */}
      <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 items-center pointer-events-none">
        {actionToasts.map((toast) => {
          const ActionIcon = getActionIcon(toast.action.type)
          const actionUrl = toast.action.url || toast.action.appUrl
          const isUrlAction = actionUrl && toast.action.type !== 'timer' && toast.action.type !== 'note'
          return (
            <div key={toast.id}
              className="pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl animate-slide-down"
              style={{
                background: 'linear-gradient(135deg, rgba(255,23,68,0.2) 0%, rgba(213,0,249,0.2) 100%)',
                border: '1px solid rgba(255,23,68,0.4)',
                backdropFilter: 'blur(20px)',
                maxWidth: '90vw',
              }}
            >
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(255,23,68,0.2)' }}>
                <ActionIcon className="size-4" style={{ color: '#FF1744' }} />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-semibold" style={{ color: '#FF6D6D' }}>NEXA Action</span>
                <span className="text-sm text-white truncate">{toast.action.label}</span>
              </div>
              {isUrlAction && (
                <a
                  href={actionUrl!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-2 px-4 py-2.5 rounded-lg text-sm font-bold flex-shrink-0 transition-all hover:scale-105 active:scale-95 inline-flex items-center gap-1.5 no-underline"
                  style={{ background: 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)', color: 'white', boxShadow: '0 2px 10px rgba(255,23,68,0.3)' }}
                >
                  <ExternalLink className="size-3.5" />
                  Open
                </a>
              )}
            </div>
          )
        })}
      </div>

      {/* Task Panel — shows all active/running/completed tasks */}
      <div className="fixed top-16 left-1/2 -translate-x-1/2 z-40 w-[90vw] max-w-md pointer-events-auto">
        <TaskPanel />
      </div>

      {/* Top Bar */}
      <div className="relative z-10 flex items-center justify-between px-4 sm:px-6 pt-6 sm:pt-8 pb-2">
        <div className="flex flex-col gap-0.5">
          <div className="flex items-center gap-1.5" style={{ fontFamily: 'var(--font-geist-mono)' }}>
            <div className={`w-2 h-2 rounded-full ${isServerDown ? 'bg-orange-400 animate-pulse' : isAlwaysListening ? 'bg-cyan-400' : isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
            <span className="text-xs" style={{ color: isServerDown ? '#FF9800' : isAlwaysListening ? '#00BCD4' : isConnected ? '#4CAF50' : '#FF1744' }}>
              {isServerDown ? 'OFFLINE' : isAlwaysListening ? (isScreenSharing ? 'BG+EYES' : 'BG MODE') : isConnected ? 'ONLINE' : 'OFFLINE'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-600" style={{ fontFamily: 'var(--font-geist-mono)' }}>v8.1</span>
            {isServerDown && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full animate-pulse" style={{ background: 'rgba(255,152,0,0.15)', color: '#FF9800', fontFamily: 'var(--font-geist-mono)' }}>
                ⚡ Offline
              </span>
            )}
            <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: 'rgba(255,23,68,0.1)', color: '#FF6D6D', fontFamily: 'var(--font-geist-mono)' }}>
              {settings.language === 'auto' ? '🌍 Auto' : settings.language}
            </span>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <h1 className="text-2xl sm:text-3xl font-black tracking-widest" style={{ color: '#FF1744', textShadow: '0 0 20px rgba(255,23,68,0.3)', letterSpacing: '0.3em' }}>
            NEXA
          </h1>
          <span className="text-[10px] sm:text-xs tracking-[0.2em]" style={{ color: '#555', fontFamily: 'var(--font-geist-mono)' }}>
            AI COMPANION
          </span>
        </div>

        <div className="flex items-center gap-1">
          <span className="text-xs mr-1" style={{ color: '#FF6D6D', fontFamily: 'var(--font-geist-mono)' }}>{statusInfo.time}</span>
          {/* Screen Share Toggle */}
          <button onClick={handleToggleScreen} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" aria-label="Screen share">
            {isScreenSharing ? <Eye className="size-3.5 text-green-400" /> : <Monitor className="size-3.5 text-gray-500 hover:text-gray-300 transition-colors" />}
          </button>
          {/* Float Toggle — uses PiP or mini widget fallback */}
          <button onClick={() => window.dispatchEvent(new CustomEvent('nexa-open-pip'))} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" aria-label="Float mode" title="Float mode — mini widget in preview, PiP in standalone">
            <PictureInPicture2 className="size-3.5 text-gray-500 hover:text-gray-300 transition-colors" />
          </button>
          <button onClick={() => sa.setMiniMode(true)} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" aria-label="Mini mode">
            <Minimize2 className="size-3.5 text-gray-500 hover:text-gray-300 transition-colors" />
          </button>
          {/* PWA Install button — only shows if installable */}
          {canInstall && (
            <button onClick={promptInstall} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors relative" aria-label="Install app" title="Install NEXA as app">
              <Download className="size-3.5 text-green-400" />
              {showAppBadge && <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-green-400 animate-pulse" />}
            </button>
          )}
          <button onClick={() => setSettingsOpen(true)} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" aria-label="Settings">
            <Settings className="size-3.5 text-gray-500 hover:text-gray-300 transition-colors" />
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center min-h-0 px-4">
        <div className="w-[220px] h-[220px] sm:w-[280px] sm:h-[280px] flex-shrink-0">
          <OrbAnimationView state={orbState} amplitude={amplitude} />
        </div>

        <div className="w-[200px] sm:w-[250px] mt-2">
          <WaveformView amplitude={amplitude} isActive={isRecording || isSpeaking} />
        </div>

        <p className="text-sm mt-3 text-center transition-all duration-300" style={{
          color: orbState === 'idle' ? '#666'
            : orbState === 'thinking' ? '#40C4FF'
            : orbState === 'active' ? '#00BCD4'
            : '#FF1744'
        }}>
          {statusText}
        </p>

        {(inputTranscript || outputTranscript) && (
          <div className="mt-2 max-w-md text-center">
            {inputTranscript && <p className="text-xs text-gray-400 truncate">You: {inputTranscript}</p>}
            {outputTranscript && <p className="text-xs text-gray-300 truncate">NEXA: {outputTranscript}</p>}
          </div>
        )}
      </div>

      {/* Active Tasks Count Badge */}
      {tasks.filter(t => t.status === 'running').length > 0 && (
        <div className="flex items-center gap-1.5 mb-1">
          <Zap className="size-3 animate-pulse" style={{ color: '#40C4FF' }} />
          <span className="text-[10px] font-medium" style={{ color: '#40C4FF' }}>
            {tasks.filter(t => t.status === 'running').length} task{tasks.filter(t => t.status === 'running').length > 1 ? 's' : ''} running
          </span>
        </div>
      )}

      {/* Chat area */}
      <div className="relative z-10 flex flex-col" style={{ maxHeight: '35vh' }}>
        <div className="flex-1 overflow-y-auto chat-scroll px-4 sm:px-6 min-h-0" style={{ maxHeight: '280px' }}>
          {messages.length > 0 && (
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] text-gray-600 uppercase tracking-wider">Chat</span>
              <button onClick={handleClearChat} className="p-1 rounded hover:bg-white/5 transition-colors" aria-label="Clear chat">
                <Trash2 className="size-3 text-gray-600 hover:text-red-400 transition-colors" />
              </button>
            </div>
          )}
          {messages.slice(-20).map((msg, i) => (
            <ChatBubble key={i} message={msg} />
          ))}
          <div ref={chatEndRef} />
        </div>
      </div>

      {/* Bottom controls */}
      <div className="relative z-10 px-4 sm:px-6 pb-6 sm:pb-8 pt-2">
        {/* Background mode quick toggles */}
        <div className="flex items-center justify-center gap-2 mb-3">
          <button onClick={toggleAlwaysListening}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-medium transition-all ${isAlwaysListening ? 'scale-100' : 'scale-95 opacity-70 hover:opacity-100'}`}
            style={{
              background: isAlwaysListening ? 'rgba(0,188,212,0.15)' : 'rgba(255,255,255,0.05)',
              border: isAlwaysListening ? '1px solid rgba(0,188,212,0.3)' : '1px solid rgba(255,255,255,0.1)',
              color: isAlwaysListening ? '#00BCD4' : '#888',
            }}>
            <Ear className="size-3" />
            {isAlwaysListening ? 'Always Listening' : 'BG Mode'}
          </button>

          <button onClick={handleToggleScreen}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-medium transition-all ${isScreenSharing ? 'scale-100' : 'scale-95 opacity-70 hover:opacity-100'}`}
            style={{
              background: isScreenSharing ? 'rgba(76,175,80,0.15)' : 'rgba(255,255,255,0.05)',
              border: isScreenSharing ? '1px solid rgba(76,175,80,0.3)' : '1px solid rgba(255,255,255,0.1)',
              color: isScreenSharing ? '#4CAF50' : '#888',
            }}>
            {isScreenSharing ? <Eye className="size-3" /> : <Monitor className="size-3" />}
            {isScreenSharing ? 'Screen ON' : 'Screen Vision'}
          </button>

          <button onClick={() => window.dispatchEvent(new CustomEvent('nexa-open-pip'))}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-medium transition-all scale-95 opacity-70 hover:opacity-100"
            style={{
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.1)',
              color: '#888',
            }}>
            <PictureInPicture2 className="size-3" />
            Float Mode
          </button>
        </div>

        {/* Photo preview */}
        {pendingPhoto && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl mb-1" style={{ background: 'rgba(255,23,68,0.1)', border: '1px solid rgba(255,23,68,0.3)' }}>
            <img src={pendingPhoto.preview} alt="Selected photo" className="w-12 h-12 rounded-lg object-cover" />
            <span className="text-xs text-gray-400 flex-1">Photo ready — type your question and send!</span>
            <button onClick={() => setPendingPhoto(null)} className="p-1 rounded-lg hover:bg-white/10 transition-colors" aria-label="Remove photo">
              <X className="size-4 text-gray-400" />
            </button>
          </div>
        )}

        {/* Hidden file input for photo upload */}
        <input
          ref={photoInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (!file) return
            // Validate file size (max 5MB)
            if (file.size > 5 * 1024 * 1024) {
              sa.setStatusText('Photo too large! Max 5MB.')
              return
            }
            const reader = new FileReader()
            reader.onload = () => {
              const result = reader.result as string
              // result is data:image/xxx;base64,...
              setPendingPhoto({ base64: result, preview: result })
              sa.setStatusText('📷 Photo loaded! Type your question...')
            }
            reader.readAsDataURL(file)
            // Reset input so same file can be re-selected
            e.target.value = ''
          }}
        />

        {/* Input + Mic row */}
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <button
              onClick={() => photoInputRef.current?.click()}
              className="p-1 rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Upload photo"
              title="Upload photo"
            >
              <ImagePlus className="size-4" style={{ color: pendingPhoto ? '#FF1744' : '#888' }} />
            </button>
            <input
              type="text"
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendText() } }}
              placeholder={pendingPhoto ? 'Ask about this photo...' : 'Type a message...'}
              className="flex-1 bg-transparent text-sm text-white outline-none placeholder:text-gray-600"
            />
            <button onClick={handleSendText} disabled={!textInput.trim()} className="p-1 rounded-lg hover:bg-white/10 transition-colors disabled:opacity-30" aria-label="Send">
              <Send className="size-4" style={{ color: textInput.trim() ? '#FF1744' : '#555' }} />
            </button>
          </div>

          <button
            onClick={toggleMic}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200"
            style={{
              background: isRecording
                ? 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)'
                : isAlwaysListening
                ? 'linear-gradient(135deg, #4CAF50 0%, #00BCD4 100%)'
                : 'linear-gradient(135deg, #FF1744 0%, #D500F9 100%)',
              boxShadow: isRecording
                ? '0 0 20px rgba(255,23,68,0.5)'
                : isAlwaysListening
                ? '0 0 15px rgba(76,175,80,0.3)'
                : '0 0 10px rgba(255,23,68,0.2)',
            }}
            aria-label={isRecording ? 'Stop recording' : 'Start recording'}
          >
            <MicIcon className="size-5 text-white" />
          </button>
        </div>
      </div>

      {/* ============ APP LAUNCH OVERLAY ============ */}
      {/* Futuristic app opening animation, multiple match selector, and app-not-found UI */}
      {pendingAction && (
        <AppLaunchOverlay
          action={pendingAction.action}
          onDismiss={() => setPendingAction(null)}
          onOpenUrl={(url) => openUrlDirect(url)}
          autoOpened={pendingAction.autoOpened}
        />
      )}

      {/* Settings Panel */}
      <SettingsPanel
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        onSave={handleSettingsSave}
        settings={{
          apiKey: settings.apiKey || '',
          userName: settings.userName || 'User',
          personalityMode: settings.personalityMode || 'assistant',
          geminiModel: settings.geminiModel || 'models/gemini-2.5-flash-native-audio-preview-12-2025',
          geminiVoice: settings.geminiVoice || 'Aoede',
          language: settings.language || 'auto',
          primeContacts,
        }}
        isConnected={isConnected}
      />
    </div>
  )
}
