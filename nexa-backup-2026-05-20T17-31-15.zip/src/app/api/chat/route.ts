import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const messages = await db.chatMessage.findMany({
      orderBy: { timestamp: 'asc' },
      take: 100,
    })

    return NextResponse.json(messages)
  } catch (error) {
    console.error('[Chat GET] Error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch chat messages' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { text, isUser } = body

    if (typeof text !== 'string' || text.trim().length === 0) {
      return NextResponse.json(
        { error: 'Message text is required' },
        { status: 400 }
      )
    }

    if (typeof isUser !== 'boolean') {
      return NextResponse.json(
        { error: 'isUser must be a boolean' },
        { status: 400 }
      )
    }

    const message = await db.chatMessage.create({
      data: {
        text: text.trim(),
        isUser,
      },
    })

    return NextResponse.json(message, { status: 201 })
  } catch (error) {
    console.error('[Chat POST] Error:', error)
    return NextResponse.json(
      { error: 'Failed to create chat message' },
      { status: 500 }
    )
  }
}

export async function DELETE() {
  try {
    await db.chatMessage.deleteMany()

    return NextResponse.json({ success: true, message: 'All chat messages cleared' })
  } catch (error) {
    console.error('[Chat DELETE] Error:', error)
    return NextResponse.json(
      { error: 'Failed to clear chat messages' },
      { status: 500 }
    )
  }
}
