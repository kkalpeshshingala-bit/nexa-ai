import { NextRequest, NextResponse } from 'next/server'
import { ZipArchive } from 'archiver'
import { readdir, stat, readFile, writeFile, mkdir, unlink } from 'fs/promises'
import { join, relative, dirname } from 'path'
import { execSync } from 'child_process'

export const dynamic = 'force-dynamic'

// GET: Download project backup as ZIP
export async function GET() {
  try {
    const projectRoot = process.cwd()

    // Directories and files to INCLUDE in the backup
    const includeDirs = ['src', 'public', 'prisma', 'db', 'mini-services']
    const includeFiles = [
      'package.json', 'tsconfig.json', 'next.config.ts', 'tailwind.config.ts',
      'postcss.config.mjs', 'components.json',
    ]

    // Patterns to EXCLUDE
    const excludePatterns = [
      'node_modules', '.next', '.git', '__pycache__',
      '.DS_Store', 'thumbs.db',
    ]

    // Collect all files to zip
    const filesToZip: { path: string; relPath: string }[] = []

    async function walkDir(dir: string, baseDir: string) {
      try {
        const entries = await readdir(dir, { withFileTypes: true })
        for (const entry of entries) {
          const fullPath = join(dir, entry.name)

          // Skip excluded patterns
          if (excludePatterns.some(p => entry.name.includes(p))) continue
          if (entry.name.startsWith('.')) continue

          if (entry.isDirectory()) {
            await walkDir(fullPath, baseDir)
          } else if (entry.isFile()) {
            const relPath = relative(baseDir, fullPath)
            filesToZip.push({ path: fullPath, relPath })
          }
        }
      } catch {
        // Directory might not exist, skip
      }
    }

    // Walk included directories
    for (const dir of includeDirs) {
      const dirPath = join(projectRoot, dir)
      await walkDir(dirPath, projectRoot)
    }

    // Add individual files
    for (const file of includeFiles) {
      const filePath = join(projectRoot, file)
      try {
        const s = await stat(filePath)
        if (s.isFile()) {
          filesToZip.push({ path: filePath, relPath: file })
        }
      } catch {
        // File might not exist, skip
      }
    }

    // Create ZIP archive
    const archive = new ZipArchive({ zlib: { level: 6 } })

    // Add files to archive
    for (const file of filesToZip) {
      try {
        const content = await readFile(file.path)
        archive.append(content, { name: file.relPath })
      } catch {
        // Skip files that can't be read
      }
    }

    archive.finalize()

    // Convert archive stream to buffer
    const chunks: Buffer[] = []
    for await (const chunk of archive as unknown as AsyncIterable<Buffer>) {
      chunks.push(chunk)
    }
    const zipBuffer = Buffer.concat(chunks)

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19)

    return new NextResponse(zipBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="nexa-backup-${timestamp}.zip"`,
        'Content-Length': zipBuffer.length.toString(),
      },
    })
  } catch (error) {
    console.error('[NEXA Backup] Error creating ZIP:', error)
    return NextResponse.json({ error: 'Failed to create backup' }, { status: 500 })
  }
}

// POST: Upload and restore backup from ZIP
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const backupFile = formData.get('backup') as File | null

    if (!backupFile) {
      return NextResponse.json({ error: 'No backup file provided' }, { status: 400 })
    }

    // Read the uploaded ZIP file
    const arrayBuffer = await backupFile.arrayBuffer()
    const zipBuffer = Buffer.from(arrayBuffer)

    const projectRoot = process.cwd()
    const tmpZipPath = join(projectRoot, '.tmp-backup.zip')

    // Write the uploaded ZIP to a temp file
    await writeFile(tmpZipPath, zipBuffer)

    // Extract using system unzip command (most reliable)
    try {
      execSync(`cd "${projectRoot}" && unzip -o "${tmpZipPath}" -x "node_modules/*" ".next/*" ".git/*" "__pycache__/*"`, {
        stdio: 'pipe',
        timeout: 30000,
      })
    } catch (execError: unknown) {
      const errMsg = execError instanceof Error ? execError.message : String(execError)
      // unzip returns non-zero for warnings but may still succeed
      if (!errMsg.includes('extraction') && !errMsg.includes('cannot')) {
        // Non-critical error, files may still be extracted
        console.warn('[NEXA Backup] Unzip warning:', errMsg.substring(0, 200))
      } else {
        console.error('[NEXA Backup] Unzip error:', errMsg.substring(0, 500))
        try { await unlink(tmpZipPath) } catch {}
        return NextResponse.json({ error: 'Failed to extract backup ZIP' }, { status: 500 })
      }
    }

    // Count restored files
    let filesRestored = 0
    try {
      const output = execSync(`cd "${projectRoot}" && unzip -l "${tmpZipPath}" -x "node_modules/*" ".next/*" ".git/*" | tail -1`, {
        encoding: 'utf-8',
        stdio: ['pipe', 'pipe', 'pipe'],
      })
      const match = output.match(/(\d+)\s+files?/i)
      if (match) filesRestored = parseInt(match[1], 10)
    } catch {}

    // Clean up temp file
    try { await unlink(tmpZipPath) } catch {}

    console.log(`[NEXA Backup] ✅ Restored ${filesRestored} files from backup`)

    return NextResponse.json({
      success: true,
      filesRestored: filesRestored || 'all',
      message: `Backup restored successfully! ${filesRestored ? filesRestored + ' files' : 'All files'} written.`,
    })
  } catch (error) {
    console.error('[NEXA Backup] Error restoring backup:', error)
    return NextResponse.json({ error: 'Failed to restore backup' }, { status: 500 })
  }
}
