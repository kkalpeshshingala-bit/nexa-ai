import { NextRequest } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// VLM (Vision Language Model) endpoint for NEXA's screen vision feature
// Accepts a base64 screenshot and a text prompt, uses z-ai-web-dev-sdk VLM to analyze the image

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { image, prompt, systemPrompt } = body

  if (!image || !prompt) {
    return new Response(JSON.stringify({ error: 'image and prompt are required' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    })
  }

  try {
    const zai = await ZAI.create()

    const response = await zai.chat.completions.createVision({
      messages: [
        ...(systemPrompt ? [{ role: 'system' as const, content: systemPrompt }] : []),
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'image_url', image_url: { url: image } }
          ]
        }
      ],
      thinking: { type: 'disabled' }
    })

    const result = response.choices?.[0]?.message?.content || ''

    return new Response(JSON.stringify({ analysis: result }), {
      headers: { 'Content-Type': 'application/json' }
    })
  } catch (error) {
    console.error('[NEXA VISION] Error:', error)
    return new Response(JSON.stringify({ error: 'Vision analysis failed' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    })
  }
}
