import { NextRequest } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { parseActions, getActionPromptBlock, isConversationalMessage } from '@/lib/nexa-actions'
import { getTransliterationHint } from '@/lib/transliteration'

// SSE streaming endpoint for ANY voice chat v3
// ROBUST HANDLING:
// - ZAI instance auto-refreshes every 3 minutes (token expiry protection)
// - 401 errors trigger immediate ZAI instance reset + re-read config
// - Global request queue (serialize calls to prevent concurrent rate-limit hits)
// - Retry with exponential backoff: 3s, 8s, 20s, 45s
// - Status SSE events during retries so the user knows what's happening

export const dynamic = 'force-dynamic'

// ─── Cached ZAI Instance with AUTO-REFRESH ────────────────────────────
let zaiInstance: InstanceType<typeof ZAI> | null = null
let zaiInitPromise: Promise<InstanceType<typeof ZAI>> | null = null
let zaiInstanceTime = 0
const ZAI_INSTANCE_TTL = 3 * 60 * 1000  // Refresh every 3 minutes

function resetZAI() {
  zaiInstance = null
  zaiInitPromise = null
  zaiInstanceTime = 0
}

async function getZAI(forceFresh = false): Promise<InstanceType<typeof ZAI>> {
  if (forceFresh) resetZAI()

  if (zaiInstance && !forceFresh) {
    const age = Date.now() - zaiInstanceTime
    if (age < ZAI_INSTANCE_TTL) return zaiInstance
    console.log('[ANY API] ZAI instance expired (age: ' + Math.round(age / 1000) + 's), refreshing...')
    resetZAI()
  }

  if (zaiInitPromise) return zaiInitPromise

  zaiInitPromise = ZAI.create().then(instance => {
    zaiInstance = instance
    zaiInstanceTime = Date.now()
    console.log('[ANY API] ✅ ZAI instance created/refreshed')
    return instance
  }).catch(err => {
    zaiInitPromise = null
    zaiInstanceTime = 0
    throw err
  })

  return zaiInitPromise
}

// ─── Global Request Queue ──────────────────────────────────────────────
type QueueTask = () => void
const requestQueue: QueueTask[] = []
let isProcessingQueue = false

function enqueueRequest<T>(fn: () => Promise<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    const task: QueueTask = () => {
      fn().then(resolve).catch(reject).finally(() => {
        isProcessingQueue = false
        processNextInQueue()
      })
    }
    requestQueue.push(task)
    if (!isProcessingQueue) {
      processNextInQueue()
    }
  })
}

function processNextInQueue() {
  if (isProcessingQueue || requestQueue.length === 0) return
  isProcessingQueue = true
  const next = requestQueue.shift()
  if (next) next()
}

// ─── Minimum interval between requests ─────────────────────────────────
let lastRequestTime = 0
const MIN_REQUEST_INTERVAL = 2000

async function waitForRateLimitWindow(): Promise<void> {
  const now = Date.now()
  const elapsed = now - lastRequestTime
  if (elapsed < MIN_REQUEST_INTERVAL) {
    await new Promise(r => setTimeout(r, MIN_REQUEST_INTERVAL - elapsed))
  }
  lastRequestTime = Date.now()
}

// ─── Error classification ─────────────────────────────────────────────
const MAX_RETRIES = 4
const RETRY_DELAYS = [3000, 8000, 20000, 45000]

function isAuthError(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false
  const err = error as Record<string, unknown>
  const msg = String(err.message || err.msg || '').toLowerCase()
  if (msg.includes('401') || msg.includes('unauthorized') || msg.includes('missing x-token') || msg.includes('token') && msg.includes('expired')) return true
  if (typeof err.status === 'number' && err.status === 401) return true
  return false
}

function isRateLimitError(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false
  const err = error as Record<string, unknown>
  if (err.status === 429 || err.statusCode === 429) return true
  const msg = String(err.message || err.msg || '').toLowerCase()
  if (msg.includes('429') || msg.includes('rate limit') || msg.includes('too many requests') || msg.includes('quota')) return true
  return false
}

function isRetryableError(error: unknown): boolean {
  if (isAuthError(error)) return true
  if (isRateLimitError(error)) return true
  if (!error || typeof error !== 'object') return false
  const err = error as Record<string, unknown>
  const msg = String(err.message || '').toLowerCase()
  if (msg.includes('fetch') || msg.includes('network') || msg.includes('econnreset') || msg.includes('timeout') || msg.includes('failed to fetch')) return true
  if (typeof err.status === 'number' && err.status >= 500) return true
  return false
}

// ─── Main Handler ──────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { action, text, systemPrompt, contacts, screenshot, history } = body as {
    action: string
    text: string
    systemPrompt?: string
    contacts?: { name: string; number: string }[]
    screenshot?: string
    history?: { text: string; isUser: boolean }[]
  }

  if (action === 'chat' && text) {
    const encoder = new TextEncoder()

    const stream = new ReadableStream({
      async start(controller) {
        const sendSSE = (event: string, data: unknown) => {
          try {
            controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
          } catch {}
        }

        try {
          // Build the full system prompt with action instructions + contacts
          const contactList = contacts as { name: string; number: string }[] | undefined
          const actionBlock = getActionPromptBlock(contactList)
          const basePrompt = systemPrompt || `You are ANY, a friendly and helpful AI voice assistant.

LANGUAGE — MOST IMPORTANT RULE:
- Detect what language the user is speaking AUTOMATICALLY
- ALWAYS respond in the EXACT SAME language the user speaks in
- If user speaks Gujarati → respond in Gujarati (ગુજરાતી)
- If user speaks Hindi → respond in Hindi (हिन्दी)
- If user speaks Hinglish (Hindi+English mix) → respond in same Hinglish
- If user speaks Gujarati+English mix → respond in same mix
- If user speaks English → respond in English
- NEVER default to English when user speaks another language
- Use the correct script for each language

═══ CORE BEHAVIOR — UNDERSTAND BEFORE ANSWERING ═══
1. FIRST understand what the user is ACTUALLY asking — read their message carefully
2. THINK about the core meaning/intent, not just the surface words
3. ANSWER accurately and helpfully — give a COMPLETE answer
4. SPEECH INPUT: The user talks via voice — speech recognition text may have:
   - Spelling mistakes or transliteration (e.g., "nexa" instead of "નેક્સા", "6" instead of "છે")
   - Mixed scripts (Gujarati words in English letters)
   - Numbers as shorthand (6=છે, ne=ને, na=ના, ni=ની, bnav=બનાવ, shu=શું)
   ALWAYS interpret the user's INTENT, not just literal text.
5. You are speaking ALOUD — keep responses natural and conversational. No markdown.
6. Give COMPLETE answers — don't artificially cut short. If question needs 5 sentences, use 5.

═══ GUJARATI TRANSLITERATION GUIDE ═══
The user speaks Gujarati but speech recognition outputs it in English letters + numbers!
CRITICAL: These are NOT English words — they are Gujarati words in transliterated form.
Common mappings you MUST understand:
- "taru name su 6" = "taru naam shu che" = તારું નામ શું છે = "What is your name?"
- "tamaru naam su 6" = તમારું નામ શું છે = "What is your name?" (formal)
- "kem cho" / "kem 6o" = કેમ છો = "How are you?"
- "kon cho" / "kon 6o" = કોણ છો = "Who are you?"
- "su kar saku 6" = શું કરી શકું છે = "What can you do?"
- "6" or "6e" = છે (is/are), "6u" = છું (I am), "6o" = છો (you are)
- "su" / "shu" = શું (what), "kem" = કેમ (how), "kon" = કોણ (who)
- "name" / "naam" / "nam" = નામ (name)
- "taru" = તારું (your), "tamaru" = તમારું (your formal)
- "maru" = મારું (my), "hu" / "hun" = હું (I)
- "bnav" / "bnaw" = બનાવ (make), "khol" = ખોલ (open)
WHEN the user's text looks like transliterated Gujarati (has these words + "6"), respond in GUJARATI SCRIPT!

═══ HINDI TRANSLITERATION GUIDE ═══
- "tera naam kya hai" / "tumhara naam kya 6" = तेरा/तुम्हारा नाम क्या है = "What is your name?"
- "kaise ho" / "kaise 6o" = कैसे हो = "How are you?"
- "tum kaun ho" / "tu kaun 6" = तुम कौन हो = "Who are you?"

═══ YOUR NAME ═══
Your name is "ANY" (Gujarati: એની, Hindi: एनी). "NEXA" is your OLD name.
- When user says "nexa"/"નેક્સા", correct them IN THEIR LANGUAGE
- NEVER open Twitter/X when user says "nexa" — they're calling your old name!
- When asked "what is your name?", ALWAYS say "ANY" (એનী / एनी)

═══ ACTION RULES — CRITICAL! READ THIS TWICE! ═══
NEVER generate [ACTION:search|...] or [ACTION:open|google] or [ACTION:open|chrome] for conversational questions!
The following are CONVERSATIONAL questions — just ANSWER them, do NOT generate ANY action tag:
- "What is your name?" / "What's your name?" / "Who are you?" / "How are you?" → Just answer! NO action!
- "What is X?" / "X kya hai?" / "X શું છે?" → Answer from knowledge! NO search!
- "Tamaru naam shu che?" / "Taru name su 6?" → Just answer! NO action!
- "Kem cho?" / "Kon cho?" / "Kaise ho?" → Just answer! NO action!
- "Are you real?" / "Can you help me?" → Just answer! NO action!

🚫 FORBIDDEN ACTION EXAMPLES — NEVER DO THIS:
- ❌ "What is your name?" → [ACTION:search|what is your name]  ← WRONG! Just say "My name is ANY!"
- ❌ "What is your name?" → [ACTION:open|google]  ← WRONG! This is NOT a search request!
- ❌ "Who are you?" → [ACTION:search|who are you]  ← WRONG! Just answer the question!
- ❌ "Taru name su 6?" → [ACTION:search|taru name su]  ← WRONG! Just answer in Gujarati!

ONLY use [ACTION:search|...] when user EXPLICITLY says "search"/"google"/"શોધો"!
ONLY use [ACTION:open|google] when user EXPLICITLY says "open google"!

═══ WORD MEANING ═══
"App" = APPLICATION (WhatsApp, Instagram), NOT "aap" (human). Give REAL app names, not human names.`

          const fullPrompt = basePrompt + '\n\n' + actionBlock

          // ===== RUNTIME HINTS (Name correction + Transliteration) =====
          const userTextLower = text.toLowerCase()
          const mentionsOldName = userTextLower.includes('nexa') || text.includes('નેક્સા') || text.includes('नेक्सा')

          // Detect if the user is speaking Gujarati/Hindi
          const isGujaratiUser = /કેમ છો|નમસ્તે|શું|કોણ|નામ|છે|છો|છું|મારું|તમારું|એની|હેલો|kem cho|tamaru|taru|shu che|shu 6|name su|naam su/.test(text)
          const isHindiUser = /कैसे|कौन|नाम|क्या|हैलो|मेरा|तुम्हारा|kaise|kaun|naam|kya|mera|tumhara/.test(text)

          // NAME CORRECTION HINT: When user mentions "nexa"
          let correctionHint = ''
          if (mentionsOldName) {
            if (isGujaratiUser) {
              correctionHint = '\n[System reminder: The user called you "nexa" in GUJARATI — you MUST respond in GUJARATI and correct them: say "મારું નામ એની (ANY) છે, નેક્સા નહીં!" — Do NOT respond in English. Do NOT ignore this.]'
            } else if (isHindiUser) {
              correctionHint = '\n[System reminder: The user called you "nexa" in HINDI — you MUST respond in HINDI and correct them: say "मेरा नाम एनी (ANY) है, नेक्सा नहीं!" — Do NOT respond in English. Do NOT ignore this.]'
            } else {
              correctionHint = '\n[System reminder: The user called you "nexa" — you MUST correct them and say your name is ANY now, not NEXA. Do NOT ignore this.]'
            }
          }

          // NAME QUESTION HINT: When user asks about name but doesn't say "nexa"
          const isNameQuestion = /your name|tumhara naam|tera naam|apna naam|taru\s+(name|naam|nam)|tamaru\s+(name|naam|nam)|તારું નામ|તમારું નામ|naam kya|name kya|naam su|name su/.test(userTextLower)
          if (!mentionsOldName && isNameQuestion) {
            if (isGujaratiUser) {
              correctionHint = '\n[System reminder: The user is asking your name in GUJARATI. Your name is "ANY" (એની), NOT "NEXA" (નેક્સા). Respond in GUJARATI: say "મારું નામ એની (ANY) છે!" — Do NOT say NEXA. Do NOT ignore this.]'
            } else if (isHindiUser) {
              correctionHint = '\n[System reminder: The user is asking your name in HINDI. Your name is "ANY" (एनी), NOT "NEXA" (नेक्सा). Respond in HINDI: say "मेरा नाम एनी (ANY) है!" — Do NOT say NEXA. Do NOT ignore this.]'
            } else {
              correctionHint = '\n[System reminder: The user is asking your name. Your name is "ANY", NOT "NEXA". Say "My name is ANY!" — Do NOT say NEXA. Do NOT ignore this.]'
            }
          }

          // TRANSLITERATION HINT: Detect transliterated Gujarati/Hindi
          const translitHint = getTransliterationHint(text)

          // CONVERSATIONAL HINT: When user asks a conversational question, explicitly tell AI NOT to generate actions
          let conversationalHint = ''
          if (isConversationalMessage(text)) {
            conversationalHint = '\n[System CRITICAL: This is a CONVERSATIONAL question — do NOT generate ANY action tags. Do NOT search. Do NOT open Google or Chrome. Just ANSWER the question directly in text only. NO [ACTION:...] tags allowed!]'
            console.log('[ANY API] Conversational hint applied — blocking all actions for:', text)
          }

          // Combine all hints with the original text
          let effectiveUserText = text
          if (correctionHint) effectiveUserText += correctionHint
          if (translitHint) effectiveUserText += translitHint
          if (conversationalHint) effectiveUserText += conversationalHint

          if (translitHint) {
            console.log('[ANY API] Transliteration hint applied:', translitHint.substring(0, 200))
          }
          if (correctionHint) {
            console.log('[ANY API] Name correction hint applied')
          }

          // Build conversation history messages for memory
          const historyMessages: { role: 'user' | 'assistant'; content: string }[] = []
          if (history && Array.isArray(history) && history.length > 0) {
            const recentHistory = history.slice(-20)
            for (const msg of recentHistory) {
              historyMessages.push({
                role: msg.isUser ? 'user' : 'assistant',
                content: msg.text,
              })
            }
          }

          // ─── Call LLM with retry + queue ───────────────────────
          let rawText = ''
          let needFreshZAI = false

          const callLLM = async (): Promise<string> => {
            const zai = await getZAI(needFreshZAI)
            needFreshZAI = false

            if (screenshot) {
              const imageUrl = screenshot.startsWith('data:')
                ? screenshot
                : `data:image/jpeg;base64,${screenshot}`

              const response = await zai.chat.completions.createVision({
                messages: [
                  { role: 'system', content: fullPrompt },
                  ...historyMessages,
                  {
                    role: 'user',
                    content: [
                      { type: 'text', text: effectiveUserText },
                      { type: 'image_url', image_url: { url: imageUrl } }
                    ]
                  }
                ],
                thinking: { type: 'disabled' }
              })

              return response.choices?.[0]?.message?.content || ''
            } else {
              // Don't specify model — let SDK use the best available model
              const response = await zai.chat.completions.create({
                messages: [
                  { role: 'system', content: fullPrompt },
                  ...historyMessages,
                  { role: 'user', content: effectiveUserText }
                ],
              })

              return response.choices?.[0]?.message?.content || ''
            }
          }

          // Execute with retry logic
          let attempt = 0
          let lastError: unknown = null

          while (attempt <= MAX_RETRIES) {
            try {
              await waitForRateLimitWindow()
              rawText = await enqueueRequest(callLLM)
              if (rawText) break

              if (attempt === 0) {
                attempt++
                sendSSE('status', { message: 'Retrying...' })
                await new Promise(r => setTimeout(r, 3000))
                continue
              }
              break
            } catch (error) {
              lastError = error
              attempt++
              console.error(`[ANY API] Attempt ${attempt} failed:`, error)

              const isAuth = isAuthError(error)
              const isRateLimit = isRateLimitError(error)

              if (isAuth) {
                console.log('[ANY API] 🔑 Auth error — forcing fresh ZAI instance')
                resetZAI()
                needFreshZAI = true
              }

              if (isRetryableError(error) && attempt <= MAX_RETRIES) {
                const delay = RETRY_DELAYS[Math.min(attempt - 1, RETRY_DELAYS.length - 1)]
                let statusMsg = isAuth
                  ? `Token refresh kar rahi hoon... (attempt ${attempt}/${MAX_RETRIES})`
                  : isRateLimit
                    ? `Server busy, ${Math.round(delay / 1000)}s mein retry... (attempt ${attempt}/${MAX_RETRIES})`
                    : `Connection issue, retrying... (attempt ${attempt}/${MAX_RETRIES})`
                sendSSE('status', { message: statusMsg })
                console.log(`[ANY API] Waiting ${delay}ms before retry ${attempt}...`)
                await new Promise(r => setTimeout(r, delay))
                if (isRateLimit) {
                  resetZAI()
                  needFreshZAI = true
                }
              } else {
                break
              }
            }
          }

          if (!rawText) {
            const isAuth = isAuthError(lastError)
            let errorMsg = 'AI response failed. Please try again.'
            if (isAuth) errorMsg = 'server_offline'
            else if (isRateLimitError(lastError)) errorMsg = 'Server is busy right now. Please wait a moment and try again.'
            else if (lastError) errorMsg = 'AI response failed. Please try again.'
            else errorMsg = 'No response from AI.'
            sendSSE('error', { message: errorMsg, isAuthError: isAuth })
          } else {
            // Parse action tags from the response, pass contacts + userMessage for conversational guard
            const { cleanText, actions } = parseActions(rawText, contactList, text)

            // Smart deduplication: if both 'open|youtube' and 'play|...' exist, remove 'open|youtube'
            const hasPlayAction = actions.some(a => a.type === 'play')
            const dedupedActions = hasPlayAction
              ? actions.filter(a => !(a.type === 'open' && a.label.toLowerCase().includes('youtube')))
              : actions

            // Send text in chunks for streaming effect
            const words = cleanText.split(' ')
            let sentText = ''
            for (const word of words) {
              if (!word.trim()) continue
              sentText += (sentText ? ' ' : '') + word
              sendSSE('text', { text: sentText })
              await new Promise(r => setTimeout(r, 30))
            }

            // Send actions as separate events
            if (dedupedActions.length > 0) {
              for (const act of dedupedActions) {
                sendSSE('action', act)
                await new Promise(r => setTimeout(r, 50))
              }
            }

            sendSSE('complete', { fullText: cleanText, actions: dedupedActions })
          }
        } catch (error) {
          console.error('[ANY API] Unexpected error:', error)
          sendSSE('error', { message: 'server_offline', isAuthError: true })
        }

        try { controller.close() } catch {}
      }
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      }
    })
  }

  return new Response(JSON.stringify({ error: 'Use action=chat with text parameter.' }), {
    status: 400,
    headers: { 'Content-Type': 'application/json' }
  })
}
