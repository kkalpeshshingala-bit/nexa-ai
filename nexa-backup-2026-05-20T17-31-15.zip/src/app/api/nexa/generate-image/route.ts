import { NextRequest } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Image generation endpoint for NEXA
// Uses z-ai-web-dev-sdk image generation API
// Returns base64 image data that the frontend displays in chat

export const dynamic = 'force-dynamic'

// ─── Cached ZAI Instance ───────────────────────────────────────────────
let zaiInstance: InstanceType<typeof ZAI> | null = null
let zaiInitPromise: Promise<InstanceType<typeof ZAI>> | null = null

async function getZAI(): Promise<InstanceType<typeof ZAI>> {
  if (zaiInstance) return zaiInstance
  if (zaiInitPromise) return zaiInitPromise

  zaiInitPromise = ZAI.create().then(instance => {
    zaiInstance = instance
    return instance
  }).catch(err => {
    zaiInitPromise = null
    throw err
  })

  return zaiInitPromise
}

const SUPPORTED_SIZES = [
  '1024x1024',  // Square
  '768x1344',   // Portrait
  '864x1152',   // Portrait
  '1344x768',   // Landscape
  '1152x864',   // Landscape
  '1440x720',   // Wide landscape
  '720x1440',   // Tall portrait
]

const MAX_RETRIES = 2
const RETRY_DELAYS = [5000, 10000]

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { prompt, size } = body as { prompt: string; size?: string }

  if (!prompt || !prompt.trim()) {
    return new Response(JSON.stringify({ error: 'Prompt is required' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    })
  }

  // Validate size
  const imageSize = size && SUPPORTED_SIZES.includes(size) ? size : '1024x1024'

  let lastError: unknown = null

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const zai = await getZAI()

      const response = await zai.images.generations.create({
        prompt: prompt.trim(),
        size: imageSize,
      })

      const imageBase64 = response.data?.[0]?.base64

      if (!imageBase64) {
        throw new Error('No image data in response')
      }

      // Return the base64 image as data URL
      const imageUrl = `data:image/png;base64,${imageBase64}`

      return new Response(JSON.stringify({
        success: true,
        imageUrl,
        prompt: prompt.trim(),
        size: imageSize,
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      })
    } catch (error) {
      lastError = error
      console.error(`[NEXA IMAGE] Attempt ${attempt + 1} failed:`, error)

      if (attempt < MAX_RETRIES) {
        const delay = RETRY_DELAYS[attempt]
        console.log(`[NEXA IMAGE] Retrying in ${delay}ms...`)
        await new Promise(r => setTimeout(r, delay))
        // Reset ZAI instance on error
        zaiInstance = null
        zaiInitPromise = null
      }
    }
  }

  return new Response(JSON.stringify({
    success: false,
    error: 'Image generation failed. Please try again.',
    details: lastError instanceof Error ? lastError.message : 'Unknown error',
  }), {
    status: 500,
    headers: { 'Content-Type': 'application/json' }
  })
}
