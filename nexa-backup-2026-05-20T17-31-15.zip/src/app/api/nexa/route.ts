import { NextRequest } from 'next/server'

// SSE endpoint that proxies to Gemini WebSocket via the mini-service
// Frontend connects here instead of directly to Socket.io
export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  const { action, apiKey, model, voice, systemPrompt, audio, text } = await request.json()

  // For now, return an error suggesting the user check the mini-service
  // This is a placeholder - the real implementation uses the Gemini REST API
  return new Response(JSON.stringify({ 
    error: 'Direct API mode not yet implemented. Please ensure the Socket.io bridge service is running on port 3003.',
    hint: 'The bridge service must be running for voice chat to work.'
  }), {
    status: 503,
    headers: { 'Content-Type': 'application/json' }
  })
}
