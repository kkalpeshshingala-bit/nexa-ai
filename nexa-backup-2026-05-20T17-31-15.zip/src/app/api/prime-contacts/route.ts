import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const contacts = await db.primeContact.findMany({
      orderBy: { order: 'asc' },
    })

    return NextResponse.json(contacts)
  } catch (error) {
    console.error('[PrimeContacts GET] Error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch prime contacts' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, number } = body

    if (typeof name !== 'string' || name.trim().length === 0) {
      return NextResponse.json(
        { error: 'Contact name is required' },
        { status: 400 }
      )
    }

    if (typeof number !== 'string' || number.trim().length === 0) {
      return NextResponse.json(
        { error: 'Contact number is required' },
        { status: 400 }
      )
    }

    // Get the max order to append new contact at the end
    const maxOrderResult = await db.primeContact.aggregate({
      _max: { order: true },
    })
    const nextOrder = (maxOrderResult._max.order ?? -1) + 1

    const contact = await db.primeContact.create({
      data: {
        name: name.trim(),
        number: number.trim(),
        order: nextOrder,
      },
    })

    return NextResponse.json(contact, { status: 201 })
  } catch (error) {
    console.error('[PrimeContacts POST] Error:', error)
    return NextResponse.json(
      { error: 'Failed to create prime contact' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: Request) {
  try {
    const body = await request.json()
    const { id } = body

    if (typeof id !== 'string' || id.trim().length === 0) {
      return NextResponse.json(
        { error: 'Contact id is required' },
        { status: 400 }
      )
    }

    const existing = await db.primeContact.findUnique({
      where: { id },
    })

    if (!existing) {
      return NextResponse.json(
        { error: 'Contact not found' },
        { status: 404 }
      )
    }

    await db.primeContact.delete({
      where: { id },
    })

    return NextResponse.json({ success: true, message: 'Contact deleted' })
  } catch (error) {
    console.error('[PrimeContacts DELETE] Error:', error)
    return NextResponse.json(
      { error: 'Failed to delete prime contact' },
      { status: 500 }
    )
  }
}
