import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// Internal route - returns the actual unmasked API key
// Used by the frontend to pass the real key to the Socket.io bridge
export async function GET() {
  try {
    const settings = await db.settings.findFirst()

    if (!settings) {
      return NextResponse.json({ apiKey: '' })
    }

    return NextResponse.json({ apiKey: settings.apiKey })
  } catch (error) {
    console.error('[Settings Key GET] Error:', error)
    return NextResponse.json({ apiKey: '' }, { status: 500 })
  }
}
