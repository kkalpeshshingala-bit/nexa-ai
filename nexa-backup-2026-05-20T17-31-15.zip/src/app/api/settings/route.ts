import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

const DEFAULT_SETTINGS = {
  apiKey: '',
  userName: 'User',
  personalityMode: 'assistant',
  geminiModel: 'models/gemini-2.5-flash-native-audio-preview-12-2025',
  geminiVoice: 'Aoede',
  language: 'auto',
}

function maskApiKey(key: string): string {
  if (!key || key.length === 0) return ''
  if (key.length <= 8) return '****'
  return key.slice(0, 3) + '****' + key.slice(-4)
}

function buildSettingsResponse(settings: {
  id: string
  apiKey: string
  userName: string
  personalityMode: string
  geminiModel: string
  geminiVoice: string
  language?: string | null
  createdAt: Date
  updatedAt: Date
}) {
  return {
    id: settings.id,
    apiKey: maskApiKey(settings.apiKey),
    hasApiKey: settings.apiKey.length > 0,
    userName: settings.userName,
    personalityMode: settings.personalityMode,
    geminiModel: settings.geminiModel,
    geminiVoice: settings.geminiVoice,
    language: settings.language || 'auto',
    createdAt: settings.createdAt,
    updatedAt: settings.updatedAt,
  }
}

export async function GET() {
  try {
    const settings = await db.settings.findFirst()

    if (!settings) {
      return NextResponse.json(DEFAULT_SETTINGS)
    }

    return NextResponse.json(buildSettingsResponse(settings))
  } catch (error) {
    console.error('[Settings GET] Error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch settings' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { apiKey, userName, personalityMode, geminiModel, geminiVoice, language } = body

    const existing = await db.settings.findFirst()

    let settings

    if (existing) {
      const updateData: Record<string, unknown> = {}
      if (apiKey !== undefined) updateData.apiKey = apiKey
      if (userName !== undefined) updateData.userName = userName
      if (personalityMode !== undefined) updateData.personalityMode = personalityMode
      if (geminiModel !== undefined) updateData.geminiModel = geminiModel
      if (geminiVoice !== undefined) updateData.geminiVoice = geminiVoice
      if (language !== undefined) updateData.language = language

      settings = await db.settings.update({
        where: { id: existing.id },
        data: updateData,
      })
    } else {
      settings = await db.settings.create({
        data: {
          apiKey: apiKey ?? DEFAULT_SETTINGS.apiKey,
          userName: userName ?? DEFAULT_SETTINGS.userName,
          personalityMode: personalityMode ?? DEFAULT_SETTINGS.personalityMode,
          geminiModel: geminiModel ?? DEFAULT_SETTINGS.geminiModel,
          geminiVoice: geminiVoice ?? DEFAULT_SETTINGS.geminiVoice,
          language: language ?? DEFAULT_SETTINGS.language,
        },
      })
    }

    return NextResponse.json(buildSettingsResponse(settings))
  } catch (error) {
    console.error('[Settings POST] Error:', error)
    return NextResponse.json(
      { error: 'Failed to save settings' },
      { status: 500 }
    )
  }
}
