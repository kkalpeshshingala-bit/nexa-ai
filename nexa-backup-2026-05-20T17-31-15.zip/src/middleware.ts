import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

/**
 * Next.js Middleware
 * 
 * Adds feature permission headers to all responses.
 * Specifically enables display-capture for screen sharing functionality.
 */
export function middleware(request: NextRequest) {
  const response = NextResponse.next()

  // Allow screen capture (getDisplayMedia) — required for NEXA's screen vision feature
  // This must be set here because the page may be embedded in an iframe
  response.headers.set('Permissions-Policy', 'display-capture=(self)')

  // NOTE: Do NOT set X-Frame-Options here — the app runs inside a preview iframe
  // on space-z.ai domain, and SAMEORIGIN would block it.

  return response
}

export const config = {
  // Apply to all routes
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
}
