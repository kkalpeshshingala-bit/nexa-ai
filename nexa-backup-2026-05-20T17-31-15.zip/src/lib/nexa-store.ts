import { create } from 'zustand'

export type OrbState = 'idle' | 'listening' | 'speaking' | 'thinking' | 'active'

export interface NexaSettings {
  apiKey: string
  userName: string
  personalityMode: string
  geminiModel: string
  geminiVoice: string
  language: string  // auto, hi-IN, en-IN, gu-IN, mr-IN, ta-IN, etc.
}

export interface PrimeContact {
  id: string
  name: string
  number: string
}

// Lightweight action info stored with chat messages for rendering action cards
export interface ChatAction {
  type: string       // 'open', 'message', 'email', etc.
  label: string      // Human-readable label
  url?: string       // Web URL to open
}

export interface ChatMessage {
  text: string
  isUser: boolean
  timestamp: number
  actions?: ChatAction[]  // Optional: action cards to render in chat bubble
  imageUrl?: string       // Optional: AI-generated image to display in chat
}

export type TaskStatus = 'pending' | 'running' | 'completed' | 'failed'

export interface NexaTask {
  id: string
  type: string
  label: string
  status: TaskStatus
  progress?: number       // 0-100 for timer progress
  createdAt: number
  completedAt?: number
}

interface NexaState {
  // Connection state
  isConnected: boolean
  isSetupComplete: boolean

  // Audio state
  isRecording: boolean
  isSpeaking: boolean
  isMuted: boolean
  amplitude: number

  // Orb state
  orbState: OrbState

  // Chat
  messages: ChatMessage[]
  inputTranscript: string
  outputTranscript: string

  // Settings
  settings: NexaSettings

  // Prime contacts
  primeContacts: PrimeContact[]

  // Status
  statusText: string

  // Background mode
  isAlwaysListening: boolean
  isMiniMode: boolean
  isBackgroundMode: boolean
  isScreenSharing: boolean
  isPiPMode: boolean

  // Tasks (multitasking)
  tasks: NexaTask[]

  // Actions
  setConnected: (v: boolean) => void
  setSetupComplete: (v: boolean) => void
  setRecording: (v: boolean) => void
  setSpeaking: (v: boolean) => void
  setMuted: (v: boolean) => void
  setAmplitude: (v: number) => void
  setOrbState: (v: OrbState) => void
  addMessage: (msg: ChatMessage) => void
  clearMessages: () => void
  setInputTranscript: (v: string) => void
  setOutputTranscript: (v: string) => void
  appendInputTranscript: (v: string) => void
  appendOutputTranscript: (v: string) => void
  clearTranscripts: () => void
  updateSettings: (s: Partial<NexaSettings>) => void
  setPrimeContacts: (contacts: PrimeContact[]) => void
  addPrimeContact: (contact: PrimeContact) => void
  removePrimeContact: (id: string) => void
  setStatusText: (v: string) => void
  setAlwaysListening: (v: boolean) => void
  setMiniMode: (v: boolean) => void
  setBackgroundMode: (v: boolean) => void
  setScreenSharing: (v: boolean) => void
  setPiPMode: (v: boolean) => void
  // Task actions
  addTask: (task: NexaTask) => void
  updateTask: (id: string, updates: Partial<NexaTask>) => void
  removeTask: (id: string) => void
  clearCompletedTasks: () => void
}

export const useNexaStore = create<NexaState>((set) => ({
  // Connection state
  isConnected: false,
  isSetupComplete: false,

  // Audio state
  isRecording: false,
  isSpeaking: false,
  isMuted: false,
  amplitude: 0,

  // Orb state
  orbState: 'idle',

  // Chat
  messages: [],
  inputTranscript: '',
  outputTranscript: '',

  // Settings
  settings: {
    apiKey: '',
    userName: '',
    personalityMode: 'assistant',
    geminiModel: 'models/gemini-2.5-flash-native-audio-preview-12-2025',
    geminiVoice: 'Aoede',
    language: 'auto',
  },

  // Prime contacts
  primeContacts: [],

  // Status
  statusText: 'Ready',

  // Background mode
  isAlwaysListening: false,
  isMiniMode: false,
  isBackgroundMode: false,
  isScreenSharing: false,
  isPiPMode: false,

  // Tasks
  tasks: [],

  // Actions
  setConnected: (v) => set({ isConnected: v }),
  setSetupComplete: (v) => set({ isSetupComplete: v }),
  setRecording: (v) => set({ isRecording: v }),
  setSpeaking: (v) => set({ isSpeaking: v }),
  setMuted: (v) => set({ isMuted: v }),
  setAmplitude: (v) => set({ amplitude: v }),
  setOrbState: (v) => set({ orbState: v }),
  addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg] })),
  clearMessages: () => set({ messages: [] }),
  setInputTranscript: (v) => set({ inputTranscript: v }),
  setOutputTranscript: (v) => set({ outputTranscript: v }),
  appendInputTranscript: (v) =>
    set((state) => ({ inputTranscript: state.inputTranscript + v })),
  appendOutputTranscript: (v) =>
    set((state) => ({ outputTranscript: state.outputTranscript + v })),
  clearTranscripts: () => set({ inputTranscript: '', outputTranscript: '' }),
  updateSettings: (s) =>
    set((state) => ({ settings: { ...state.settings, ...s } })),
  setPrimeContacts: (contacts) => set({ primeContacts: contacts }),
  addPrimeContact: (contact) =>
    set((state) => ({ primeContacts: [...state.primeContacts, contact] })),
  removePrimeContact: (id) =>
    set((state) => ({
      primeContacts: state.primeContacts.filter((c) => c.id !== id),
    })),
  setStatusText: (v) => set({ statusText: v }),
  setAlwaysListening: (v) => set({ isAlwaysListening: v }),
  setMiniMode: (v) => set({ isMiniMode: v }),
  setBackgroundMode: (v) => set({ isBackgroundMode: v }),
  setScreenSharing: (v) => set({ isScreenSharing: v }),
  setPiPMode: (v) => set({ isPiPMode: v }),
  // Task actions
  addTask: (task) => set((state) => ({ tasks: [...state.tasks, task] })),
  updateTask: (id, updates) => set((state) => ({
    tasks: state.tasks.map((t) => t.id === id ? { ...t, ...updates } : t),
  })),
  removeTask: (id) => set((state) => ({
    tasks: state.tasks.filter((t) => t.id !== id),
  })),
  clearCompletedTasks: () => set((state) => ({
    tasks: state.tasks.filter((t) => t.status !== 'completed' && t.status !== 'failed'),
  })),
}))
