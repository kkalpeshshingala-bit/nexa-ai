// ═══ TRANSLITERATION INTERPRETATION ENGINE ═══
// When users speak Gujarati/Hindi via Chrome's Speech Recognition (hi-IN locale),
// the output is a mix of English letters and numbers instead of proper script.
// For example: "taru name su 6" → means "તારું નામ શું છે" (What is your name?)
//
// This module detects common transliteration patterns and generates interpretation
// hints that are appended to the user's message so the AI model can understand.

// ─── WORD-LEVEL TRANSLITERATION MAP ────────────────────────────────
const GUJARATI_WORDS: Record<string, { script: string; meaning: string }> = {
  // Numbers used as Gujarati words by speech recognition
  '6':      { script: 'છે',  meaning: 'is/are (present tense)' },
  '6u':     { script: 'છું', meaning: 'I am' },
  '6o':     { script: 'છો',  meaning: 'you are' },
  '6e':     { script: 'છે',  meaning: 'is/are' },

  // Common Gujarati words in English transliteration
  'taru':   { script: 'તારું', meaning: 'your (informal)' },
  'tamaru': { script: 'તમારું', meaning: 'your (formal)' },
  'name':   { script: 'નામ',  meaning: 'name' },
  'naam':   { script: 'નામ',  meaning: 'name' },
  'nam':    { script: 'નામ',  meaning: 'name' },
  'su':     { script: 'શું',  meaning: 'what' },
  'shu':    { script: 'શું',  meaning: 'what' },
  'che':    { script: 'છે',  meaning: 'is' },
  'cho':    { script: 'છો',  meaning: 'you are' },
  'chho':   { script: 'છો',  meaning: 'you are' },
  'kem':    { script: 'કેમ',  meaning: 'how' },
  'kon':    { script: 'કોણ',  meaning: 'who' },
  'ne':     { script: 'ને',  meaning: 'to/hey (particle)' },
  'na':     { script: 'ના',  meaning: 'no/of' },
  'ni':     { script: 'ની',  meaning: 'of (feminine)' },
  'no':     { script: 'નો',  meaning: 'of (masculine)' },
  'bnav':   { script: 'બનાવ', meaning: 'make/create' },
  'bnaw':   { script: 'બનાવ', meaning: 'make/create' },
  'banao':  { script: 'બનાવો', meaning: 'make/create' },
  'bnavo':  { script: 'બનાવો', meaning: 'make/create' },
  'khol':   { script: 'ખોલ',  meaning: 'open' },
  'kholo':  { script: 'ખોલો',  meaning: 'open' },
  'bandh':  { script: 'બંધ',  meaning: 'close' },
  'kar':    { script: 'કર',  meaning: 'do' },
  'karo':   { script: 'કરો',  meaning: 'do' },
  'madad':  { script: 'મદદ',  meaning: 'help' },
  'joie':   { script: 'જોઈએ', meaning: 'need/want' },
  'chun':   { script: 'છું',  meaning: 'I am' },
  'maru':   { script: 'મારું', meaning: 'my' },
  'mru':    { script: 'મારું', meaning: 'my' },
  'aaje':   { script: 'આજે',  meaning: 'today' },
  'samay':  { script: 'સમય',  meaning: 'time' },
  'vag':    { script: 'વાગ',  meaning: "o'clock" },
  'baje':   { script: 'બજે',  meaning: "o'clock" },
  'image':  { script: 'ઈમેજ', meaning: 'image' },
  'photo':  { script: 'ફોટો',  meaning: 'photo' },
  'nature': { script: 'નેચર',  meaning: 'nature' },
  'dhundho': { script: 'શોધો', meaning: 'search' },
  'dhund':  { script: 'શોધ',  meaning: 'search' },
  'bol':    { script: 'બોલ',  meaning: 'speak/say' },
  'bolo':   { script: 'બોલો',  meaning: 'speak/say' },
  'kya':    { script: 'ક્યા',  meaning: 'what' },
  'halo':   { script: 'હેલો',  meaning: 'hello' },
  'hello':  { script: 'હેલો',  meaning: 'hello' },
  'namaste': { script: 'નમસ્તે', meaning: 'hello/greetings' },
  'vay':    { script: 'ઉંમર',  meaning: 'age' },
  'umr':    { script: 'ઉંમર',  meaning: 'age' },
  'saru':   { script: 'સારું',  meaning: 'good' },
  'badhu':  { script: 'બધું',  meaning: 'everything' },
  'samj':   { script: 'સમજ',  meaning: 'understand' },
  'samjavo': { script: 'સમજાવો', meaning: 'explain' },
  'batao':  { script: 'બતાવો', meaning: 'tell/show' },
  'batavo': { script: 'બતાવો', meaning: 'tell/show' },
  'hu':     { script: 'હું',  meaning: 'I' },
  'hun':    { script: 'હું',  meaning: 'I' },
  'tu':     { script: 'તું',  meaning: 'you (informal)' },
  'tame':   { script: 'તમે',  meaning: 'you (formal)' },
  'mane':   { script: 'મને',  meaning: 'to me' },
  'pan':    { script: 'પણ',  meaning: 'but/also' },
}

// ─── PHRASE-LEVEL PATTERN MATCHING ─────────────────────────────────
interface TransliterationPhrase {
  pattern: RegExp
  language: string
  script: string
  meaning: string
  responseLang: string
}

const GUJARATI_PHRASES: TransliterationPhrase[] = [
  // "What is your name?"
  { pattern: /taru\s+(name|naam|nam)\s+(su|shu)\s*(6|che|chhe|6e)?/i,
    language: 'Gujarati', script: 'તારું નામ શું છે?', meaning: 'What is your name?', responseLang: 'Gujarati (ગુજરાતી)' },
  { pattern: /tamaru\s+(name|naam|nam)\s+(su|shu)\s*(6|che|chhe|6e)?/i,
    language: 'Gujarati', script: 'તમારું નામ શું છે?', meaning: 'What is your name? (formal)', responseLang: 'Gujarati (ગુજરાતી)' },
  // "How are you?"
  { pattern: /kem\s+(cho|chho|6o)\s*/i,
    language: 'Gujarati', script: 'કેમ છો?', meaning: 'How are you?', responseLang: 'Gujarati (ગુજરાતી)' },
  // "Who are you?"
  { pattern: /kon\s+(cho|chho|6o|6|che)/i,
    language: 'Gujarati', script: 'કોણ છો?', meaning: 'Who are you?', responseLang: 'Gujarati (ગુજરાતી)' },
  // "What can you do?"
  { pattern: /(shu|su)\s+kar\s+(saki|saku|sako)/i,
    language: 'Gujarati', script: 'શું કરી શકો?', meaning: 'What can you do?', responseLang: 'Gujarati (ગુજરાતી)' },
  // "What time is it?"
  { pattern: /ketla\s+(vag|baje|baj)\s*(6|che|chhe)/i,
    language: 'Gujarati', script: 'કેટલા વાગ્યા છે?', meaning: 'What time is it?', responseLang: 'Gujarati (ગુજરાતી)' },
  // "Make/draw an image"
  { pattern: /(image|photo)\s+(bnav|bnaw|banao|bnavo)/i,
    language: 'Gujarati', script: 'ઈમેજ બનાવો', meaning: 'Make an image/photo', responseLang: 'Gujarati (ગુજરાતી)' },
  // "Open [app]"
  { pattern: /\w+\s+(khol|kholo)/i,
    language: 'Gujarati', script: '___ ખોલો', meaning: 'Open ___', responseLang: 'Gujarati (ગુજરાતી)' },
  // "Explain to me"
  { pattern: /mane\s+samj(avo|ao|o)?/i,
    language: 'Gujarati', script: 'મને સમજાવો', meaning: 'Explain to me', responseLang: 'Gujarati (ગુજરાતી)' },
]

const HINDI_PHRASES: TransliterationPhrase[] = [
  // "What is your name?"
  { pattern: /tera\s+(naam|name|nam)\s+(kya|kiya)\s*(hai|he|6)/i,
    language: 'Hindi', script: 'तेरा नाम क्या है?', meaning: 'What is your name? (informal)', responseLang: 'Hindi (हिन्दी)' },
  { pattern: /tumhara\s+(naam|name|nam)\s+(kya|kiya)\s*(hai|he|6)/i,
    language: 'Hindi', script: 'तुम्हारा नाम क्या है?', meaning: 'What is your name?', responseLang: 'Hindi (हिन्दी)' },
  // "How are you?"
  { pattern: /kaise\s+(ho|6o|6)/i,
    language: 'Hindi', script: 'कैसे हो?', meaning: 'How are you?', responseLang: 'Hindi (हिन्दी)' },
  // "Who are you?"
  { pattern: /tum\s+kaun\s*(ho|6o|6)/i,
    language: 'Hindi', script: 'तुम कौन हो?', meaning: 'Who are you?', responseLang: 'Hindi (हिन्दी)' },
]

// ─── Detect if text contains transliterated Indian language ─────────
export function hasTransliteratedIndianText(text: string): boolean {
  const lower = text.toLowerCase()
  if (/\b6\b/.test(text)) return true
  const gujaratiWords = ['taru', 'tamaru', 'shu', 'kem', 'bnav', 'bnaw', 'khol', 'cho', 'chho', 'joie', 'batavo', 'samjavo']
  if (gujaratiWords.some(w => lower.includes(w))) return true
  const hindiWords = ['kya', 'hai', 'kaun', 'kaise', 'naam', 'batao', 'samjhao']
  if (hindiWords.some(w => lower.includes(w))) return true
  return false
}

// ─── MAIN: Generate interpretation hint ────────────────────────────
export function getTransliterationHint(userText: string): string {
  const text = userText.trim()
  if (!text) return ''

  const hints: string[] = []

  // 1. Check phrase-level patterns (most specific)
  const allPhrases = [...GUJARATI_PHRASES, ...HINDI_PHRASES]
  for (const phrase of allPhrases) {
    if (phrase.pattern.test(text)) {
      hints.push(`User is speaking ${phrase.language}. Their message "${text}" means "${phrase.script}" (${phrase.meaning}). You MUST respond in ${phrase.responseLang} using the proper script.`)
      break
    }
  }

  // 2. Word-level transliteration analysis
  if (hints.length === 0 && hasTransliteratedIndianText(text)) {
    const words = text.split(/\s+/)
    const transliteratedWords: string[] = []
    const scriptWords: string[] = []

    for (const word of words) {
      const cleanWord = word.toLowerCase().replace(/[?,.!;:]/g, '')
      if (GUJARATI_WORDS[cleanWord]) {
        transliteratedWords.push(cleanWord)
        scriptWords.push(GUJARATI_WORDS[cleanWord].script)
      }
    }

    if (transliteratedWords.length >= 2) {
      const wordMap = transliteratedWords.map(w => `"${w}" = ${GUJARATI_WORDS[w].script} (${GUJARATI_WORDS[w].meaning})`).join(', ')
      hints.push(`User is speaking Gujarati in transliterated form. Word meanings: ${wordMap}. Interpret their full message in context and respond in Gujarati (ગુજરાતી) using Gujarati script.`)
    } else if (transliteratedWords.length === 1 && transliteratedWords[0] === '6') {
      hints.push('User said "6" which means "છે" (is/are) in Gujarati. The message is likely in Gujarati. Respond in Gujarati (ગુજરાતી) script.')
    }
  }

  // 3. Detect pure script
  if (hints.length === 0) {
    const hasGujaratiScript = /[\u0A80-\u0AFF]/.test(text)
    const hasHindiScript = /[\u0900-\u097F]/.test(text)
    if (hasGujaratiScript) {
      hints.push('User is speaking in Gujarati. Respond in Gujarati (ગુજરાતી) script.')
    } else if (hasHindiScript) {
      hints.push('User is speaking in Hindi. Respond in Hindi (हिन्दी) script.')
    }
  }

  if (hints.length === 0) return ''
  return `\n[System: ${hints.join(' ')}]`
}

// ─── Helper: detect language ───────────────────────────────────────────
export function detectGujaratiText(text: string): boolean {
  if (/[\u0A80-\u0AFF]/.test(text)) return true
  const lower = text.toLowerCase()
  const markers = ['taru', 'tamaru', 'kem cho', 'su 6', 'shu che', 'shu 6', 'naam su', 'name su', 'bnav', 'bnaw']
  return markers.some(m => lower.includes(m))
}

export function detectHindiText(text: string): boolean {
  if (/[\u0900-\u097F]/.test(text)) return true
  const lower = text.toLowerCase()
  const markers = ['kya hai', 'kaun ho', 'kaise ho', 'naam kya', 'batao', 'samjhao']
  return markers.some(m => lower.includes(m))
}
