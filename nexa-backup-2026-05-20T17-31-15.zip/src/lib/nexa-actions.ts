// NEXA Action System v4 — Open ANY app, message anyone, call, SMS, email, and more!
// Enhanced: Fuzzy app matching, 100+ apps, Android packages, categories, app-not-found handling

export interface NexaAction {
  type: 'open' | 'search' | 'whatsapp' | 'call' | 'sms' | 'email' | 'timer' | 'map' | 'play' | 'note' | 'message' | 'appnotfound' | 'generate_image'
  label: string       // Human-readable label
  url?: string        // Web URL (primary — works in all browsers)
  appUrl?: string     // App deep link (fallback for mobile)
  query?: string      // Search query
  data?: string       // Additional data
  seconds?: number    // For timer
  contactName?: string // Which contact this is for
  number?: string     // Phone number resolved
  email?: string      // Email address
  icon?: string       // Emoji icon for the action
  category?: string   // App category
  packageName?: string // Android package name for deep detection
  matches?: AppMatchInfo[] // Multiple app matches for selection UI
}

// App match info for multiple-match selection UI
export interface AppMatchInfo {
  key: string
  name: string
  icon: string
  webUrl: string
  appUrl: string
  category: string
  packageName: string
}

// App registry: website URL + deep link + Android package + category
export interface AppInfo {
  name: string
  webUrl: string
  appUrl: string
  icon: string
  category: string
  packageName: string
  aliases?: string[]  // Alternative names / typos / short names
}

export const APP_REGISTRY: Record<string, AppInfo> = {
  // ===== SOCIAL & MESSAGING =====
  'whatsapp':       { name: 'WhatsApp',        webUrl: 'https://web.whatsapp.com',        appUrl: 'whatsapp://',              icon: '💬', category: 'Social', packageName: 'com.whatsapp', aliases: ['wa', 'watsapp', 'whatsap', 'whats app'] },
  'instagram':      { name: 'Instagram',       webUrl: 'https://www.instagram.com',       appUrl: 'instagram://',             icon: '📸', category: 'Social', packageName: 'com.instagram.android', aliases: ['insta', 'ig', 'instgram'] },
  'facebook':       { name: 'Facebook',        webUrl: 'https://www.facebook.com',        appUrl: 'fb://',                    icon: '👤', category: 'Social', packageName: 'com.facebook.katana', aliases: ['fb', 'face book', 'fb app'] },
  'twitter':        { name: 'Twitter',         webUrl: 'https://www.twitter.com',         appUrl: 'twitter://',               icon: '🐦', category: 'Social', packageName: 'com.twitter.android' },
  'x':              { name: 'X (Twitter)',      webUrl: 'https://www.x.com',               appUrl: 'twitter://',               icon: '🐦', category: 'Social', packageName: 'com.twitter.android', aliases: ['x app', 'twitter x'] },
  'telegram':       { name: 'Telegram',        webUrl: 'https://web.telegram.org',        appUrl: 'tg://',                    icon: '✈️', category: 'Social', packageName: 'org.telegram.messenger', aliases: ['tg', 'tele', 'teligram'] },
  'snapchat':       { name: 'Snapchat',        webUrl: 'https://www.snapchat.com',        appUrl: 'snapchat://',              icon: '👻', category: 'Social', packageName: 'com.snapchat.android', aliases: ['snap', 'sc'] },
  'linkedin':       { name: 'LinkedIn',        webUrl: 'https://www.linkedin.com',        appUrl: 'linkedin://',              icon: '💼', category: 'Social', packageName: 'com.linkedin.android' },
  'discord':        { name: 'Discord',         webUrl: 'https://discord.com',             appUrl: 'discord://',               icon: '🎮', category: 'Social', packageName: 'com.discord' },
  'pinterest':      { name: 'Pinterest',       webUrl: 'https://www.pinterest.com',       appUrl: 'pinterest://',             icon: '📌', category: 'Social', packageName: 'com.pinterest' },
  'reddit':         { name: 'Reddit',          webUrl: 'https://www.reddit.com',          appUrl: 'reddit://',                icon: '🔴', category: 'Social', packageName: 'com.reddit.frontpage' },
  'threads':        { name: 'Threads',         webUrl: 'https://www.threads.net',         appUrl: 'threads://',               icon: '🧵', category: 'Social', packageName: 'com.instagram.barcelona' },
  'tumblr':         { name: 'Tumblr',          webUrl: 'https://www.tumblr.com',          appUrl: 'tumblr://',                icon: '📝', category: 'Social', packageName: 'com.tumblr' },
  'signal':         { name: 'Signal',          webUrl: 'https://signal.org',              appUrl: 'sgnl://',                  icon: '🔒', category: 'Social', packageName: 'org.thoughtcrime.securesms' },

  // ===== VIDEO & STREAMING =====
  'youtube':        { name: 'YouTube',         webUrl: 'https://www.youtube.com',         appUrl: 'youtube://',               icon: '🎬', category: 'Video', packageName: 'com.google.android.youtube', aliases: ['yt', 'you tube', 'utube'] },
  'netflix':        { name: 'Netflix',         webUrl: 'https://www.netflix.com',         appUrl: 'nflx://',                  icon: '🎥', category: 'Video', packageName: 'com.netflix.mediaclient' },
  'spotify':        { name: 'Spotify',         webUrl: 'https://open.spotify.com',        appUrl: 'spotify://',               icon: '🎵', category: 'Music', packageName: 'com.spotify.music' },
  'twitch':         { name: 'Twitch',          webUrl: 'https://www.twitch.tv',           appUrl: 'twitch://',                icon: '🎮', category: 'Video', packageName: 'tv.twitch.android.app' },
  'hotstar':        { name: 'Disney+ Hotstar', webUrl: 'https://www.hotstar.com',         appUrl: 'hotstar://',               icon: '⭐', category: 'Video', packageName: 'in.startv.hotstar', aliases: ['disney', 'disney hotstar', 'hot star'] },
  'prime video':    { name: 'Prime Video',     webUrl: 'https://www.primevideo.com',      appUrl: 'primevideo://',            icon: '📺', category: 'Video', packageName: 'com.amazon.avod.thirdp artyclient', aliases: ['amazon prime', 'amazon video'] },
  'jiocinema':      { name: 'JioCinema',       webUrl: 'https://www.jiocinema.com',       appUrl: 'jiocinema://',             icon: '🎬', category: 'Video', packageName: 'com.jio.media.jiobeats', aliases: ['jio cinema', 'jio'] },
  'vlc':            { name: 'VLC Player',      webUrl: 'https://www.videolan.org',        appUrl: 'vlc://',                   icon: '🔶', category: 'Video', packageName: 'org.videolan.vlc', aliases: ['vlc player', 'video player'] },
  'mx player':      { name: 'MX Player',       webUrl: 'https://mxplayer.in',             appUrl: 'mxplayer://',              icon: '▶️', category: 'Video', packageName: 'com.mxtech.videoplayer.ad', aliases: ['mx', 'mxplayer'] },
  'apple music':    { name: 'Apple Music',     webUrl: 'https://music.apple.com',         appUrl: 'applemusic://',            icon: '🎶', category: 'Music', packageName: 'com.apple.android.music' },
  'wynk':           { name: 'Wynk Music',      webUrl: 'https://wynk.in',                 appUrl: 'wynk://',                  icon: '🎵', category: 'Music', packageName: 'com.bsbportal.music' },
  'gaana':          { name: 'Gaana',           webUrl: 'https://gaana.com',               appUrl: 'gaana://',                 icon: '🎶', category: 'Music', packageName: 'com.gaana' },
  'jiosaavn':       { name: 'JioSaavn',        webUrl: 'https://www.jiosaavn.com',        appUrl: 'jiosaavn://',              icon: '🎵', category: 'Music', packageName: 'com.saavn.android', aliases: ['saavn', 'jio saavn'] },

  // ===== SHOPPING =====
  'amazon':         { name: 'Amazon',          webUrl: 'https://www.amazon.in',           appUrl: 'amzn://',                  icon: '📦', category: 'Shopping', packageName: 'in.amazon.mShop.android.shopping' },
  'flipkart':       { name: 'Flipkart',        webUrl: 'https://www.flipkart.com',        appUrl: 'flipkart://',              icon: '🛒', category: 'Shopping', packageName: 'com.flipkart.android' },
  'myntra':         { name: 'Myntra',          webUrl: 'https://www.myntra.com',          appUrl: 'myntra://',                icon: '👗', category: 'Shopping', packageName: 'com.myntra.android' },
  'meesho':         { name: 'Meesho',          webUrl: 'https://www.meesho.com',          appUrl: 'meesho://',                icon: '🛍️', category: 'Shopping', packageName: 'com.meesho.app' },
  'ajio':           { name: 'Ajio',            webUrl: 'https://www.ajio.com',            appUrl: 'ajio://',                  icon: '👕', category: 'Shopping', packageName: 'com.ril.ajio' },
  'nykaa':          { name: 'Nykaa',           webUrl: 'https://www.nykaa.com',           appUrl: 'nykaa://',                 icon: '💄', category: 'Shopping', packageName: 'com.nykaa.android' },
  'snapdeal':       { name: 'Snapdeal',        webUrl: 'https://www.snapdeal.com',        appUrl: 'snapdeal://',              icon: '🛒', category: 'Shopping', packageName: 'com.snapdeal.main' },

  // ===== FOOD DELIVERY =====
  'swiggy':         { name: 'Swiggy',          webUrl: 'https://www.swiggy.com',          appUrl: 'swiggy://',                icon: '🍔', category: 'Food', packageName: 'in.swiggy.android' },
  'zomato':         { name: 'Zomato',          webUrl: 'https://www.zomato.com',          appUrl: 'zomato://',                icon: '🍕', category: 'Food', packageName: 'com.application.zomato' },
  'dominos':        { name: "Domino's",        webUrl: 'https://www.dominos.co.in',       appUrl: 'dominos://',               icon: '🍕', category: 'Food', packageName: 'com.dominos', aliases: ['domino', 'dominos pizza', 'pizza'] },
  'mcdonalds':      { name: "McDonald's",      webUrl: 'https://www.mcdonaldsindia.com',  appUrl: 'mcdonalds://',             icon: '🍔', category: 'Food', packageName: 'com.mcdonalds.app', aliases: ['mcd', 'macdonalds', 'mc donalds'] },

  // ===== TRAVEL & MAPS =====
  'maps':           { name: 'Google Maps',     webUrl: 'https://maps.google.com',         appUrl: 'comgooglemaps://',         icon: '🗺️', category: 'Travel', packageName: 'com.google.android.apps.maps', aliases: ['google maps', 'gmaps', 'map'] },
  'ola':            { name: 'Ola',             webUrl: 'https://www.olacabs.com',         appUrl: 'ola://',                   icon: '🚗', category: 'Travel', packageName: 'com.olacabs.customer' },
  'uber':           { name: 'Uber',            webUrl: 'https://www.uber.com',            appUrl: 'uber://',                  icon: '🚕', category: 'Travel', packageName: 'com.ubercab' },
  'makemytrip':     { name: 'MakeMyTrip',      webUrl: 'https://www.makemytrip.com',      appUrl: 'makemytrip://',            icon: '✈️', category: 'Travel', packageName: 'com.makemytrip', aliases: ['mmt', 'make my trip'] },
  'goibibo':        { name: 'Goibibo',         webUrl: 'https://www.goibibo.com',         appUrl: 'goibibo://',               icon: '🏨', category: 'Travel', packageName: 'com.goibibo' },
  'irctc':          { name: 'IRCTC',           webUrl: 'https://www.irctc.co.in',         appUrl: 'irctc://',                 icon: '🚂', category: 'Travel', packageName: 'cris.org.in.prs.ima' },
  'rapido':         { name: 'Rapido',          webUrl: 'https://rapido.bike',             appUrl: 'rapido://',                icon: '🛵', category: 'Travel', packageName: 'com.rapido.passengers' },
  'waze':           { name: 'Waze',            webUrl: 'https://www.waze.com',            appUrl: 'waze://',                  icon: '🚦', category: 'Travel', packageName: 'com.waze' },

  // ===== PRODUCTIVITY =====
  'google':         { name: 'Google',          webUrl: 'https://www.google.com',          appUrl: 'google://',                icon: '🔍', category: 'Productivity', packageName: 'com.google.android.googlequicksearchbox' },
  'gmail':          { name: 'Gmail',           webUrl: 'https://mail.google.com',         appUrl: 'googlegmail://',           icon: '📧', category: 'Productivity', packageName: 'com.google.android.gm' },
  'drive':          { name: 'Google Drive',    webUrl: 'https://drive.google.com',        appUrl: 'comgoogleapps://drive',    icon: '📁', category: 'Productivity', packageName: 'com.google.android.apps.docs', aliases: ['google drive', 'gdrive'] },
  'docs':           { name: 'Google Docs',     webUrl: 'https://docs.google.com',         appUrl: 'comgoogleapps://docs',     icon: '📄', category: 'Productivity', packageName: 'com.google.android.apps.docs.editors.docs' },
  'sheets':         { name: 'Google Sheets',   webUrl: 'https://sheets.google.com',       appUrl: 'comgoogleapps://sheets',   icon: '📊', category: 'Productivity', packageName: 'com.google.android.apps.docs.editors.sheets' },
  'slides':         { name: 'Google Slides',   webUrl: 'https://slides.google.com',       appUrl: 'comgoogleapps://slides',   icon: '📊', category: 'Productivity', packageName: 'com.google.android.apps.docs.editors.slides' },
  'calendar':       { name: 'Google Calendar', webUrl: 'https://calendar.google.com',     appUrl: 'comgooglecalendar://',     icon: '📅', category: 'Productivity', packageName: 'com.google.android.calendar', aliases: ['google calendar'] },
  'github':         { name: 'GitHub',          webUrl: 'https://www.github.com',          appUrl: 'github://',                icon: '💻', category: 'Productivity', packageName: 'com.github.android' },
  'chatgpt':        { name: 'ChatGPT',         webUrl: 'https://chat.openai.com',         appUrl: 'chatgpt://',               icon: '🤖', category: 'Productivity', packageName: 'com.openai.chatgpt', aliases: ['openai', 'chat gpt', 'gpt'] },
  'notion':         { name: 'Notion',          webUrl: 'https://www.notion.so',           appUrl: 'notion://',                icon: '📝', category: 'Productivity', packageName: 'notion.id' },
  'slack':          { name: 'Slack',           webUrl: 'https://slack.com',               appUrl: 'slack://',                 icon: '💬', category: 'Productivity', packageName: 'com.Slack' },
  'evernote':       { name: 'Evernote',        webUrl: 'https://evernote.com',            appUrl: 'evernote://',              icon: '📝', category: 'Productivity', packageName: 'com.evernote' },
  'todoist':        { name: 'Todoist',         webUrl: 'https://todoist.com',             appUrl: 'todoist://',               icon: '✅', category: 'Productivity', packageName: 'com.todoist.android' },
  'trello':         { name: 'Trello',          webUrl: 'https://trello.com',              appUrl: 'trello://',                icon: '📋', category: 'Productivity', packageName: 'com.trello' },

  // ===== BROWSERS =====
  'chrome':         { name: 'Chrome',          webUrl: 'https://www.google.com',          appUrl: 'googlechrome://',          icon: '🌐', category: 'Browser', packageName: 'com.android.chrome', aliases: ['google chrome', 'browser'] },
  'firefox':        { name: 'Firefox',         webUrl: 'https://www.mozilla.org',         appUrl: 'firefox://',               icon: '🦊', category: 'Browser', packageName: 'org.mozilla.firefox' },
  'brave':          { name: 'Brave',           webUrl: 'https://brave.com',               appUrl: 'brave://',                 icon: '🦁', category: 'Browser', packageName: 'com.brave.browser' },
  'edge':           { name: 'Microsoft Edge',  webUrl: 'https://www.microsoft.com/edge',  appUrl: 'microsoft-edge://',        icon: '🔵', category: 'Browser', packageName: 'com.microsoft.emmx', aliases: ['ms edge'] },
  'safari':         { name: 'Safari',          webUrl: 'https://www.apple.com/safari',    appUrl: 'safari://',                icon: '🧭', category: 'Browser', packageName: 'com.apple.mobilesafari' },
  'opera':          { name: 'Opera',           webUrl: 'https://www.opera.com',           appUrl: 'opera://',                 icon: '🔴', category: 'Browser', packageName: 'com.opera.browser' },

  // ===== PAYMENT =====
  'gpay':           { name: 'Google Pay',      webUrl: 'https://pay.google.com',          appUrl: 'gpay://',                  icon: '💰', category: 'Payment', packageName: 'com.google.android.apps.nbu.paisa.user', aliases: ['google pay', 'tez'] },
  'phonepe':        { name: 'PhonePe',         webUrl: 'https://www.phonepe.com',         appUrl: 'phonepe://',               icon: '💳', category: 'Payment', packageName: 'com.phonepe.app' },
  'paytm':          { name: 'Paytm',           webUrl: 'https://paytm.com',               appUrl: 'paytm://',                 icon: '💸', category: 'Payment', packageName: 'net.one97.paytm' },
  'bhim':           { name: 'BHIM UPI',        webUrl: 'https://www.bhimupi.org.in',      appUrl: 'bhim://',                  icon: '🏦', category: 'Payment', packageName: 'in.org.npci.upiapp' },
  'mobikwik':       { name: 'MobiKwik',       webUrl: 'https://www.mobikwik.com',        appUrl: 'mobikwik://',              icon: '💳', category: 'Payment', packageName: 'com.mobikwik_new' },
  'amazon pay':     { name: 'Amazon Pay',      webUrl: 'https://pay.amazon.in',           appUrl: 'amzn://',                  icon: '💰', category: 'Payment', packageName: 'in.amazon.mShop.android.shopping' },
  'freecharge':     { name: 'Freecharge',      webUrl: 'https://www.freecharge.in',       appUrl: 'freecharge://',            icon: '⚡', category: 'Payment', packageName: 'com.freecharge.android' },

  // ===== NEWS & READING =====
  'quora':          { name: 'Quora',           webUrl: 'https://www.quora.com',           appUrl: 'quora://',                 icon: '❓', category: 'News', packageName: 'com.quora.android' },
  'medium':         { name: 'Medium',          webUrl: 'https://medium.com',              appUrl: 'medium://',                icon: '📖', category: 'News', packageName: 'me.saket.medium' },
  'inshorts':       { name: 'Inshorts',        webUrl: 'https://inshorts.com',            appUrl: 'inshorts://',              icon: '📰', category: 'News', packageName: 'com.nis.app', aliases: ['news', 'inshort'] },
  'google news':    { name: 'Google News',     webUrl: 'https://news.google.com',         appUrl: 'googlenews://',            icon: '📰', category: 'News', packageName: 'com.google.android.apps.magazines' },
  'tripadvisor':    { name: 'TripAdvisor',     webUrl: 'https://www.tripadvisor.com',     appUrl: 'tripadvisor://',           icon: '✈️', category: 'Travel', packageName: 'com.tripadvisor.tripadvisor' },

  // ===== GAMES =====
  'pubg':           { name: 'BGMI (PUBG)',     webUrl: 'https://www.battlegroundsmobileindia.com', appUrl: 'pubgm://',  icon: '🎮', category: 'Games', packageName: 'com.pubg.imobile', aliases: ['bgmi', 'battlegrounds', 'pubg mobile'] },
  'freefire':       { name: 'Free Fire',       webUrl: 'https://ff.garena.com',           appUrl: 'freefire://',              icon: '🔥', category: 'Games', packageName: 'com.dts.freefireth', aliases: ['ff', 'garena', 'free fire'] },
  'cod':            { name: 'Call of Duty',    webUrl: 'https://www.callofduty.com',      appUrl: 'codm://',                  icon: '🎯', category: 'Games', packageName: 'com.activision.callofduty.shooter', aliases: ['call of duty', 'cod mobile'] },
  'clash of clans': { name: 'Clash of Clans',  webUrl: 'https://supercell.com/en/games/clashofclans', appUrl: 'clashofclans://', icon: '⚔️', category: 'Games', packageName: 'com.supercell.magic', aliases: ['coc', 'clash'] },
  'clash royale':   { name: 'Clash Royale',    webUrl: 'https://supercell.com/en/games/clashroyale', appUrl: 'clashroyale://', icon: '👑', category: 'Games', packageName: 'com.supercell.magic2' },
  'candy crush':    { name: 'Candy Crush',     webUrl: 'https://www.king.com/game/candycrush', appUrl: 'candycrushsaga://', icon: '🍬', category: 'Games', packageName: 'com.king.candycrushsaga', aliases: ['candy', 'candy crush saga'] },
  'subway surfers': { name: 'Subway Surfers',  webUrl: 'https://www.kiloo.com/games/subway-surfers', appUrl: 'subwaysurfers://', icon: '🏃', category: 'Games', packageName: 'com.kiloo.subwaysurf', aliases: ['subway', 'subway surfer'] },
  'temple run':     { name: 'Temple Run',      webUrl: 'https://www.imangistudios.com',   appUrl: 'templerun://',              icon: '🏛️', category: 'Games', packageName: 'com.imangi.templerun2', aliases: ['temple'] },
  'ludo':           { name: 'Ludo King',       webUrl: 'https://ludoking.com',            appUrl: 'ludoking://',              icon: '🎲', category: 'Games', packageName: 'com.ludo.king', aliases: ['ludo king', 'ludoking'] },
  'among us':       { name: 'Among Us',        webUrl: 'https://www.innersloth.com',      appUrl: 'amongus://',               icon: '🚀', category: 'Games', packageName: 'com.innersloth.spacemafia' },
  'minecraft':      { name: 'Minecraft',       webUrl: 'https://www.minecraft.net',       appUrl: 'minecraft://',             icon: '⛏️', category: 'Games', packageName: 'com.mojang.minecraftpe' },
  'roblox':         { name: 'Roblox',          webUrl: 'https://www.roblox.com',          appUrl: 'roblox://',                icon: '🧱', category: 'Games', packageName: 'com.roblox.client' },
  'angry birds':    { name: 'Angry Birds',     webUrl: 'https://www.angrybirds.com',      appUrl: 'angrybirds://',            icon: '🐦', category: 'Games', packageName: 'com.rovio.baba' },

  // ===== UTILITIES =====
  'calculator':     { name: 'Calculator',      webUrl: 'https://www.google.com/search?q=calculator', appUrl: 'calculator://', icon: '🧮', category: 'Utility', packageName: 'com.google.android.calculator' },
  'camera':         { name: 'Camera',          webUrl: '',                                appUrl: 'camera://',                icon: '📷', category: 'Utility', packageName: 'com.android.camera' },
  'clock':          { name: 'Clock',           webUrl: 'https://time.is',                 appUrl: 'clock://',                 icon: '⏰', category: 'Utility', packageName: 'com.android.deskclock', aliases: ['alarm', 'stopwatch'] },
  'settings':       { name: 'Settings',        webUrl: '',                                appUrl: 'app-settings://',          icon: '⚙️', category: 'Utility', packageName: 'com.android.settings', aliases: ['phone settings', 'setting'] },
  'weather':        { name: 'Weather',         webUrl: 'https://weather.com',             appUrl: 'weather://',               icon: '🌤️', category: 'Utility', packageName: 'com.google.android.apps.weather' },
  'files':          { name: 'Files',           webUrl: '',                                appUrl: 'files://',                 icon: '📁', category: 'Utility', packageName: 'com.google.android.apps.nbu.files', aliases: ['file manager', 'file explorer', 'my files'] },
  'notes':          { name: 'Google Keep',     webUrl: 'https://keep.google.com',         appUrl: 'googlenotes://',           icon: '📝', category: 'Utility', packageName: 'com.google.android.keep', aliases: ['keep', 'keep notes', 'note'] },
  'translate':      { name: 'Google Translate',webUrl: 'https://translate.google.com',    appUrl: 'googletranslate://',       icon: '🌐', category: 'Utility', packageName: 'com.google.android.apps.translate', aliases: ['translator'] },
  'flashlight':     { name: 'Flashlight',      webUrl: '',                                appUrl: 'flashlight://',            icon: '🔦', category: 'Utility', packageName: 'com.android.flashlight', aliases: ['torch', 'light'] },
  'recorder':       { name: 'Voice Recorder',  webUrl: '',                                appUrl: 'recorder://',              icon: '🎙️', category: 'Utility', packageName: 'com.google.android.apps.recorder', aliases: ['voice recorder', 'audio recorder', 'recording'] },
  'barcode scanner':{ name: 'Barcode Scanner', webUrl: '',                                appUrl: 'zxing://',                 icon: '📱', category: 'Utility', packageName: 'com.google.zxing.client.android', aliases: ['qr scanner', 'scanner', 'qr code'] },

  // ===== HEALTH & FITNESS =====
  'fitbit':         { name: 'Fitbit',          webUrl: 'https://www.fitbit.com',          appUrl: 'fitbit://',                icon: '🏃', category: 'Health', packageName: 'com.fitbit.FitbitMobile' },
  'strava':         { name: 'Strava',          webUrl: 'https://www.strava.com',          appUrl: 'strava://',                icon: '🚴', category: 'Health', packageName: 'com.strava' },
  'health':         { name: 'Google Fit',      webUrl: 'https://fit.google.com',          appUrl: 'googlefit://',             icon: '❤️', category: 'Health', packageName: 'com.google.android.apps.fitness', aliases: ['google fit', 'fitness'] },
  'covid':          { name: 'Aarogya Setu',    webUrl: 'https://www.aarogyasetu.gov.in',  appUrl: 'aarogyasetu://',           icon: '🛡️', category: 'Health', packageName: 'nic.goi.aarogyasetu', aliases: ['aarogya', 'aarogya setu'] },

  // ===== EDUCATION =====
  'byju':           { name: "BYJU'S",          webUrl: 'https://byjus.com',              appUrl: 'byjus://',                 icon: '📚', category: 'Education', packageName: 'com.byjus.thelearningapp', aliases: ['byjus', 'byju app'] },
  'unacademy':      { name: 'Unacademy',       webUrl: 'https://unacademy.com',           appUrl: 'unacademy://',             icon: '🎓', category: 'Education', packageName: 'com.unacademyapp' },
  'duolingo':       { name: 'Duolingo',        webUrl: 'https://www.duolingo.com',        appUrl: 'duolingo://',              icon: '🦉', category: 'Education', packageName: 'com.duolingo' },
  'coursera':       { name: 'Coursera',        webUrl: 'https://www.coursera.org',        appUrl: 'coursera://',              icon: '🎓', category: 'Education', packageName: 'org.coursera.android' },
  'udemy':          { name: 'Udemy',           webUrl: 'https://www.udemy.com',           appUrl: 'udemy://',                 icon: '📚', category: 'Education', packageName: 'com.udemy.android' },
  'khan academy':   { name: 'Khan Academy',    webUrl: 'https://www.khanacademy.org',     appUrl: 'khanacademy://',           icon: '📐', category: 'Education', packageName: 'org.khanacademy.android' },

  // ===== DATING =====
  'tinder':         { name: 'Tinder',          webUrl: 'https://tinder.com',              appUrl: 'tinder://',                icon: '💕', category: 'Social', packageName: 'com.tinder' },
  'bumble':         { name: 'Bumble',          webUrl: 'https://bumble.com',              appUrl: 'bumble://',                icon: '🐝', category: 'Social', packageName: 'com.bumble.app' },

  // ===== VPN & SECURITY =====
  'nordvpn':        { name: 'NordVPN',         webUrl: 'https://nordvpn.com',             appUrl: 'nordvpn://',               icon: '🛡️', category: 'Security', packageName: 'com.nordvpn.android' },
  'expressvpn':     { name: 'ExpressVPN',      webUrl: 'https://www.expressvpn.com',      appUrl: 'expressvpn://',            icon: '🔒', category: 'Security', packageName: 'com.expressvpn.vpn' },

  // ===== OFFICE =====
  'word':           { name: 'Microsoft Word',  webUrl: 'https://www.office.com',          appUrl: 'ms-word://',               icon: '📝', category: 'Productivity', packageName: 'com.microsoft.office.word', aliases: ['ms word', 'microsoft word'] },
  'excel':          { name: 'Microsoft Excel', webUrl: 'https://www.office.com',          appUrl: 'ms-excel://',              icon: '📊', category: 'Productivity', packageName: 'com.microsoft.office.excel', aliases: ['ms excel', 'microsoft excel'] },
  'powerpoint':     { name: 'Microsoft PowerPoint', webUrl: 'https://www.office.com',  appUrl: 'ms-powerpoint://',         icon: '📊', category: 'Productivity', packageName: 'com.microsoft.office.powerpoint', aliases: ['ppt', 'ms powerpoint', 'microsoft powerpoint'] },
  'outlook':        { name: 'Microsoft Outlook', webUrl: 'https://outlook.live.com',      appUrl: 'ms-outlook://',            icon: '📧', category: 'Productivity', packageName: 'com.microsoft.office.outlook' },
  'teams':          { name: 'Microsoft Teams', webUrl: 'https://teams.microsoft.com',     appUrl: 'msteams://',               icon: '👥', category: 'Productivity', packageName: 'com.microsoft.teams' },
  'zoom':           { name: 'Zoom',            webUrl: 'https://zoom.us',                 appUrl: 'zoomus://',                icon: '📹', category: 'Productivity', packageName: 'us.zoom.videomeetings' },
  'google meet':    { name: 'Google Meet',     webUrl: 'https://meet.google.com',         appUrl: 'googlemeet://',            icon: '📹', category: 'Productivity', packageName: 'com.google.android.apps.meetings', aliases: ['meet', 'gmeet'] },

  // ===== PHOTO & VIDEO EDITING =====
  'snapseed':       { name: 'Snapseed',        webUrl: 'https://snapseed.online',         appUrl: 'snapseed://',              icon: '🎨', category: 'Creative', packageName: 'com.niksoftware.snapseed' },
  'canva':          { name: 'Canva',           webUrl: 'https://www.canva.com',           appUrl: 'canva://',                 icon: '🎨', category: 'Creative', packageName: 'com.canva.editor' },
  'picsart':        { name: 'Picsart',         webUrl: 'https://picsart.com',             appUrl: 'picsart://',               icon: '🖼️', category: 'Creative', packageName: 'com.picsart.studio' },
  'lightroom':      { name: 'Lightroom',       webUrl: 'https://lightroom.adobe.com',     appUrl: 'lightroom://',             icon: '📷', category: 'Creative', packageName: 'com.adobe.lrmobile' },
  'inshot':         { name: 'InShot',          webUrl: 'https://inshot.com',              appUrl: 'inshot://',                icon: '🎬', category: 'Creative', packageName: 'com.camerasideas.instashot' },
  'capcut':         { name: 'CapCut',          webUrl: 'https://www.capcut.com',          appUrl: 'capcut://',                icon: '✂️', category: 'Creative', packageName: 'com.lemon.lvoverseas' },

  // ===== SOCIAL GOOD =====
  'umang':          { name: 'UMANG',           webUrl: 'https://web.umang.gov.in',        appUrl: 'umang://',                 icon: '🇮🇳', category: 'Government', packageName: 'com.gov.umang' },
  'digi locker':    { name: 'DigiLocker',      webUrl: 'https://www.digilocker.gov.in',   appUrl: 'digilocker://',            icon: '🗂️', category: 'Government', packageName: 'com.digilocker.android', aliases: ['digital locker', 'digilocker'] },
  'mparivahan':     { name: 'mParivahan',      webUrl: 'https://parivahan.gov.in',        appUrl: 'mparivahan://',            icon: '🚗', category: 'Government', packageName: 'com.nic.mparivahan' },
  'bhim upi':       { name: 'BHIM UPI',        webUrl: 'https://www.bhimupi.org.in',      appUrl: 'bhim://',                  icon: '🏦', category: 'Payment', packageName: 'in.org.npci.upiapp' },
}

// ===== FUZZY APP MATCHING =====
// Levenshtein distance for typo tolerance
function levenshtein(a: string, b: string): number {
  const matrix: number[][] = []
  for (let i = 0; i <= b.length; i++) matrix[i] = [i]
  for (let j = 0; j <= a.length; j++) matrix[0][j] = j
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1]
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        )
      }
    }
  }
  return matrix[b.length][a.length]
}

// Assistant name blacklist — these should NEVER be matched as app names
const ASSISTANT_NAME_BLACKLIST = new Set([
  'any', 'nexa', 'એની', 'નેક્સા', 'एनी', 'नेक्सा',
  'hey any', 'ok any', 'hey nexa', 'ok nexa',
])

// Conversational intent phrases — these are questions directed at the assistant,
// NOT requests to open apps or search. If the user's message matches these,
// ALL actions should be stripped from the AI response.
const CONVERSATIONAL_PHRASES = [
  // English
  'your name', 'who are you', 'how are you', 'what are you', 'where are you',
  'what can you do', 'what do you do', 'tell me about yourself',
  'good morning', 'good evening', 'good night', 'good afternoon',
  'thank you', 'thanks', 'sorry', 'ok', 'okay', 'bye', 'goodbye',
  'what time', 'what day', 'what date', 'what is the time', 'what is the date',
  'do you know', 'can you help', 'are you there', 'are you real',
  'i love you', 'you are great', 'you are awesome', 'nice to meet',
  'tell me', 'explain to me', 'do you think', 'what do you think',
  'why do', 'how do you', 'can you speak', 'do you understand',
  'what does', 'what does it mean', 'can you tell me',
  // Hindi
  'tumhara naam', 'tera naam', 'apna naam', 'tumhara nam', 'tum kaun', 'tu kaun',
  'kaise ho', 'kaisa hai', 'kaisi ho', 'kya kar rahe', 'kya kar rahi',
  'tumhari umar', 'teri umar', 'kahan ho', 'kahan hai',
  'naam kya', 'naam kya hai', 'kaun ho tum', 'kaun hai tum',
  'shukriya', 'dhanyavad', 'alvida', 'namaste',
  'kya matlab', 'matlab kya', 'samjhao', 'batao kya',
  'tum kya kar sakti', 'tum kya kar sakte', 'kya tum',
  // Gujarati — with transliterated number "6" = "છે" (very common from speech recognition)
  'tamaru naam', 'tamaru nam', 'taru naam', 'taru nam', 'taru name',
  'taru naam shu', 'taru nam shu', 'taru name su', 'nam shu', 'naam shu',
  'name su', 'naam su', 'nam su che', 'naam su che', 'name su che',
  'name su 6', 'naam su 6', 'nam su 6',
  'tamaru naam shu', 'tamaru nam shu', 'tamaru name su',
  'tamaru naam su', 'tamaru nam su',
  'taru naam su 6', 'taru name su 6', 'taru nam su 6',
  'tamaru naam su 6', 'tamaru name su 6', 'tamaru nam su 6',
  'kem cho', 'kem chho', 'kem cho ho', 'kem 6o',
  'kya che', 'shu che', 'shu 6',
  'kon chho', 'kon cho', 'kon ho', 'kon 6o', 'kon 6',
  'kya kar cho', 'kya kar chho', 'su kar cho',
  'tamaru vay', 'taru vay', 'taru umr',
  'shu kar saki', 'shu kar saku', 'su kar saku', 'su kar saki',
  'tame shu kar', 'tu su kar',
  'samjavo', 'samjhao', 'batao', 'shu matlab', 'su matlab',
  'kem 6o', 'kem cho 6',
  'તારું નામ', 'નામ શું', 'કેમ છો', 'કોણ છો',
  'શું છે', 'તમારું નામ', 'તમારું નામ શું',
  'શું કરી શકો', 'શું કરી શકું', 'મને સમજાવો',
  'શું મતલબ', 'તમે શું કરો', 'કેમ કરો',
  'આભાર', 'નમસ્તે', 'અલવિદા',
  // Marathi
  'tumcha naav', 'tu kon', 'kasa ahes', 'kashi ahes',
  // Tamil
  'un peyar', 'nee yaaru', 'eppadi irukk', 'nallaa irukk',
  // Bengali
  'tomar naam', 'tumi ke', 'kemon acho',
  // Punjabi
  'tuhada naam', 'tu kaun', 'ki haal',
  // Telugu
  'nee peru', 'meeru evaru', 'ela unnaru',
  // Mixed/Hinglish
  'naam kya hai', 'name kya hai', 'kaun ho', 'kon ho',
  // Transliterated with "6" patterns (speech recognition artifact)
  'naam kya 6', 'name kya 6', 'kaun 6o',
]

// Patterns that indicate a QUESTION directed at the assistant (NOT a search/command)
const CONVERSATIONAL_QUESTION_PATTERNS = [
  // "what is/are" questions about concepts, feelings, people — NOT about places/things to search
  /^what (is|are|was|were) (your|my|this|that|it|the matter|the problem|going on|up|happening|the meaning)/i,
  /^kya (hai|he|hain|tha|thi) (tumhara|tera|tumhari|teri|yeh|woh|mera|meri|aapka)/i,
  /^શું છે (તમારું|તારું|આ|તે|મારું|મને)/,
]

// Check if a user message is conversational (NOT a task/command)
export function isConversationalMessage(userText: string): boolean {
  const text = userText.toLowerCase().trim()

  // Short greetings (including Gujarati)
  if (/^(hi|hello|hey|namaste|namaskar|helo|yo|sup|yo yo|kya haal|kem cho|kem 6o|કેમ છો|નમસ્તે|હેલો)$/.test(text)) return true

  // EXACT phrase matches for common conversational questions
  // These are STRONG signals that the user is chatting, NOT commanding
  const exactConversationalPhrases = [
    'what is your name', 'whats your name', "what's your name",
    'what is your age', 'whats your age', "what's your age",
    'who are you', 'how are you', 'what are you',
    'tell me your name', 'tell me about yourself',
    'what can you do', 'what do you do',
    'are you real', 'are you a robot', 'are you a bot', 'are you ai',
    'do you have a name', 'what should i call you',
    'your name please', 'say your name',
  ]
  for (const phrase of exactConversationalPhrases) {
    if (text === phrase || text.startsWith(phrase + ' ') || text.startsWith(phrase + '?')) return true
  }

  // Check against conversational phrases (substring match)
  for (const phrase of CONVERSATIONAL_PHRASES) {
    if (text.includes(phrase)) return true
  }

  // Check conversational question patterns
  for (const pattern of CONVERSATIONAL_QUESTION_PATTERNS) {
    if (pattern.test(text)) return true
  }

  // Pattern-based detection for questions directed at the assistant
  const conversationalPatterns = [
    /^(what|who|where|when|how|why)\s+(is|are|was|were|do|does|did|can|will|would|should)\s+(your|you|the|this|my)/i,
    /^(what|who)\s+(is|are)\s+(your|you|this)/i,
    /what('?s| is) your (name|age|favorite|color|number)/i,
    /tell me (about|your|you)/i,
    /how (old|many|much|do|are|is) you/i,
    /can you (help|do|make|tell|explain|understand|speak|hear)/i,
    /are you (ok|real|human|robot|ai|a bot|a person|there|busy|sure)/i,
    /do you (know|like|have|want|need|think|remember)/i,
    // "what is X" where X is a concept, NOT a place/thing to search for
    /^what (is|are) (the|a|an|this|that|your|my|it)/i,
    // Variations with contractions
    /what'?s (your|the|this|that)/i,
    // "ur" instead of "your" (speech recognition variation)
    /what (is|'?s) ur (name|age|favorite|color)/i,
    // Gujarati transliterated patterns with "6" = "છે/છો/છું"
    /^(taru|tamaru)\s+(name|naam|nam)\s+(su|shu)\s*6?/i,
    /^(kem|kon)\s+(cho|chho|6o|6)\s*$/i,
    /^(su|shu)\s+(kar|6)\s*(saki|saku|6)/i,
  ]
  for (const pattern of conversationalPatterns) {
    if (pattern.test(text)) return true
  }

  return false
}

// Find apps matching a query — supports exact, alias, and fuzzy matching
export function findApps(query: string): AppMatchInfo[] {
  const q = query.toLowerCase().trim()
  if (!q) return []

  // NEVER match assistant names as app names
  if (ASSISTANT_NAME_BLACKLIST.has(q)) return []

  const results: { match: AppMatchInfo; score: number }[] = []

  for (const [key, app] of Object.entries(APP_REGISTRY)) {
    let score = 0

    // Exact key match
    if (key === q) score = 100
    // Key contains query
    else if (key.includes(q)) score = 80
    // Query contains key — but ONLY if key is at least 3 chars to prevent false matches
    // (e.g., "nexa" contains "x" would falsely match the X/Twitter app)
    else if (key.length >= 3 && q.includes(key)) score = 70
    // Name match
    else if (app.name.toLowerCase().includes(q)) score = 75
    // Alias match — also require alias to be at least 3 chars for q.includes(a) to prevent false matches
    else if (app.aliases?.some(a => a === q || (a.length >= 3 && a.includes(q)) || (a.length >= 3 && q.includes(a)))) score = 65
    // Fuzzy match (typo tolerance)
    else {
      const dist = levenshtein(q, key)
      const maxDist = Math.max(1, Math.floor(q.length * 0.4)) // Allow 40% typo
      if (dist <= maxDist) score = 50 - dist
      // Also check aliases with fuzzy
      else if (app.aliases?.some(a => {
        const aliasDist = levenshtein(q, a)
        return aliasDist <= Math.max(1, Math.floor(q.length * 0.4))
      })) score = 40
    }

    if (score > 0) {
      results.push({
        match: {
          key,
          name: app.name,
          icon: app.icon,
          webUrl: app.webUrl,
          appUrl: app.appUrl,
          category: app.category,
          packageName: app.packageName,
        },
        score,
      })
    }
  }

  // Sort by score descending, return top 5
  results.sort((a, b) => b.score - a.score)
  return results.slice(0, 5).map(r => r.match)
}

// Helper: Build Gmail compose URL (works in any browser — no email client needed!)
function buildGmailUrl(to: string, subject: string, body: string): string {
  const params = new URLSearchParams()
  params.set('view', 'cm')
  params.set('fs', '1')
  params.set('to', to)
  if (subject) params.set('su', subject)
  if (body) params.set('body', body)
  return `https://mail.google.com/mail/?${params.toString()}`
}

// Helper: Build WhatsApp Web URL (works in any browser!)
function buildWhatsAppUrl(phone: string, message: string): string {
  const cleanPhone = phone.replace(/[^0-9+]/g, '')
  const base = `https://wa.me/${cleanPhone}`
  return message ? `${base}?text=${encodeURIComponent(message)}` : base
}

// Helper: resolve a contact name or number from user input
function resolveContact(
  input: string,
  contacts?: { name: string; number: string }[]
): { number: string; name: string } {
  const trimmed = input.trim()
  let number = ''
  let name = ''

  if (trimmed.startsWith('contact:')) {
    name = trimmed.replace('contact:', '').trim().toLowerCase()
    const found = contacts?.find(c => c.name.toLowerCase() === name || c.name.toLowerCase().includes(name))
    if (found) { number = found.number.replace(/[^0-9+]/g, ''); name = found.name }
  } else if (/^\d/.test(trimmed)) {
    number = trimmed.replace(/[^0-9+]/g, '')
  } else {
    const found = contacts?.find(c =>
      c.name.toLowerCase() === trimmed.toLowerCase() || c.name.toLowerCase().includes(trimmed.toLowerCase())
    )
    if (found) { number = found.number.replace(/[^0-9+]/g, ''); name = found.name }
    else { name = trimmed }
  }

  return { number, name }
}

// Parse action tags from AI response text
// If userMessage is provided, we check if it's conversational and strip all actions
export function parseActions(text: string, contacts?: { name: string; number: string }[], userMessage?: string): { cleanText: string; actions: NexaAction[] } {
  // CONVERSATIONAL GUARD LAYER 1: If the user's message is clearly conversational,
  // strip ALL action tags from the AI response. The AI sometimes generates
  // [ACTION:open|google] or [ACTION:search|...] for questions like
  // "what is your name" — this prevents that bug.
  if (userMessage && isConversationalMessage(userMessage)) {
    // Remove all action tags but keep the text
    const cleanText = text.replace(/\[ACTION:\s*\w+\s*\|\s*[^\]]+?\s*\]/gi, '').trim()
    console.log('[NEXA] 🛑 Conversational guard: stripped all actions for message:', userMessage)
    return { cleanText, actions: [] }
  }

  // CONVERSATIONAL GUARD LAYER 2: Check individual action content.
  // Even if the primary guard didn't catch it (e.g., edge case in isConversationalMessage),
  // we check if specific actions are obviously wrong for the user's message.
  // Keywords that indicate a CONVERSATIONAL question (NOT a search/command)
  const conversationalKeywords = [
    'your name', 'who are you', 'how are you', 'what are you', 'my name',
    'your age', 'your favorite', 'do you know', 'can you help',
    'tumhara naam', 'tera naam', 'apna naam', 'taru naam', 'tamaru naam',
    'naam kya', 'name su', 'naam su', 'kaise ho', 'kem cho',
    'kon ho', 'kaun ho', 'kon cho', 'kon 6o',
  ]
  const userMsgLower = (userMessage || '').toLowerCase()
  const isUserConversational = conversationalKeywords.some(kw => userMsgLower.includes(kw))

  // Helper: Check if an action should be blocked because it's a search/open
  // for a conversational question
  function isConversationalAction(type: string, data: string): boolean {
    if (!isUserConversational) return false
    const dataLower = data.toLowerCase()
    // Block search/open actions when user asked a conversational question
    if (type === 'search') return true
    if (type === 'open' && (dataLower === 'google' || dataLower === 'chrome' || dataLower === 'browser')) {
      return true
    }
    return false
  }

  const actions: NexaAction[] = []
  const actionRegex = /\[ACTION:\s*(\w+)\s*\|\s*([^\]]+?)\s*\]/gi
  let match: RegExpExecArray | null
  let cleanText = text

  while ((match = actionRegex.exec(text)) !== null) {
    const fullMatch = match[0]
    const actionType = match[1].toLowerCase().trim()
    const actionData = match[2].trim()

    switch (actionType) {
      case 'open': {
        // CONVERSATIONAL GUARD LAYER 2: Block opening Google/Chrome for conversational questions
        if (isConversationalAction(actionType, actionData)) {
          console.log('[NEXA] 🛑 Blocked conversational action: open|' + actionData)
          cleanText = cleanText.replace(fullMatch, '')
          break
        }
        const appKey = actionData.toLowerCase().trim()
        const app = APP_REGISTRY[appKey]
        if (app) {
          actions.push({
            type: 'open',
            label: `Opening ${app.name} ${app.icon}`,
            url: app.webUrl,
            appUrl: app.appUrl,
            icon: app.icon,
            category: app.category,
            packageName: app.packageName,
          })
        } else {
          // Try fuzzy matching for unknown app names
          const fuzzyMatches = findApps(appKey)
          if (fuzzyMatches.length > 0) {
            const best = fuzzyMatches[0]
            actions.push({
              type: 'open',
              label: `Opening ${best.name} ${best.icon}`,
              url: best.webUrl,
              appUrl: best.appUrl,
              icon: best.icon,
              category: best.category,
              packageName: best.packageName,
            })
          } else if (actionData.startsWith('http')) {
            actions.push({ type: 'open', label: `Opening ${actionData}`, url: actionData, icon: '🔗' })
          } else {
            // App not found — generate search fallback
            actions.push({
              type: 'appnotfound',
              label: `App not found: ${actionData}`,
              query: actionData,
              url: `https://www.google.com/search?q=${encodeURIComponent(actionData + ' app download')}`,
              icon: '❓',
              data: actionData,
            })
          }
        }
        break
      }
      case 'search': {
        // CONVERSATIONAL GUARD LAYER 2: Block search actions for conversational questions
        if (isConversationalAction(actionType, actionData)) {
          console.log('[NEXA] 🛑 Blocked conversational action: search|' + actionData)
          cleanText = cleanText.replace(fullMatch, '')
          break
        }
        actions.push({
          type: 'search',
          label: `Searching: ${actionData}`,
          query: actionData,
          url: `https://www.google.com/search?q=${encodeURIComponent(actionData)}`,
          icon: '🔍',
        })
        break
      }
      case 'whatsapp': {
        const parts = actionData.split('|')
        const firstPart = parts[0]?.trim() || ''
        const message = parts.slice(1).join('|').trim()
        const resolved = resolveContact(firstPart, contacts)
        if (resolved.number) {
          actions.push({
            type: 'whatsapp',
            label: `WhatsApp ${resolved.name || resolved.number} 💬`,
            url: buildWhatsAppUrl(resolved.number, message),
            appUrl: `whatsapp://send?phone=${resolved.number}${message ? `&text=${encodeURIComponent(message)}` : ''}`,
            data: message,
            contactName: resolved.name,
            number: resolved.number,
            icon: '💬',
          })
        } else {
          actions.push({ type: 'whatsapp', label: 'Opening WhatsApp 💬', url: 'https://web.whatsapp.com', appUrl: 'whatsapp://', icon: '💬' })
        }
        break
      }
      case 'call': {
        const resolved = resolveContact(actionData.trim(), contacts)
        actions.push({
          type: 'call',
          label: `Calling ${resolved.name || resolved.number} 📞`,
          url: `tel:${resolved.number}`,
          appUrl: `tel:${resolved.number}`,
          contactName: resolved.name,
          number: resolved.number,
          icon: '📞',
        })
        break
      }
      case 'sms': {
        const smsParts = actionData.split('|')
        const smsTarget = smsParts[0]?.trim() || ''
        const smsMessage = smsParts.slice(1).join('|').trim()
        const resolved = resolveContact(smsTarget, contacts)
        if (resolved.number) {
          actions.push({
            type: 'sms', label: `Message ${resolved.name || resolved.number} 📱`,
            url: buildWhatsAppUrl(resolved.number, smsMessage),
            appUrl: `sms:${resolved.number}${smsMessage ? `?body=${encodeURIComponent(smsMessage)}` : ''}`,
            data: smsMessage, contactName: resolved.name, number: resolved.number, icon: '📱',
          })
        } else {
          actions.push({ type: 'sms', label: 'Opening WhatsApp 💬', url: 'https://web.whatsapp.com', appUrl: 'whatsapp://', icon: '💬' })
        }
        break
      }
      case 'email': {
        const emailParts = actionData.split('|')
        const emailAddr = emailParts[0]?.trim() || ''
        const emailSubject = emailParts[1]?.trim() || ''
        const emailBody = emailParts.slice(2).join('|').trim()
        actions.push({
          type: 'email', label: `Email to ${emailAddr} 📧`,
          url: buildGmailUrl(emailAddr, emailSubject, emailBody),
          appUrl: `mailto:${emailAddr}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`,
          data: emailBody, email: emailAddr, icon: '📧',
        })
        break
      }
      case 'message': {
        const msgParts = actionData.split('|')
        const msgTarget = msgParts[0]?.trim() || ''
        const msgText = msgParts.slice(1).join('|').trim()
        const resolved = resolveContact(msgTarget, contacts)
        if (resolved.number) {
          actions.push({
            type: 'message', label: `Message ${resolved.name || resolved.number} 💬`,
            url: buildWhatsAppUrl(resolved.number, msgText),
            appUrl: `whatsapp://send?phone=${resolved.number}${msgText ? `&text=${encodeURIComponent(msgText)}` : ''}`,
            data: msgText, contactName: resolved.name, number: resolved.number, icon: '💬',
          })
        } else {
          actions.push({ type: 'message', label: 'Opening WhatsApp 💬', url: 'https://web.whatsapp.com', appUrl: 'whatsapp://', icon: '💬' })
        }
        break
      }
      case 'timer': {
        const seconds = parseInt(actionData, 10) || 0
        const mins = Math.floor(seconds / 60)
        const secs = seconds % 60
        const label = mins > 0 ? `Timer: ${mins}m ${secs > 0 ? secs + 's' : ''}` : `Timer: ${secs}s`
        actions.push({ type: 'timer', label, seconds, icon: '⏱️' })
        break
      }
      case 'map': {
        actions.push({
          type: 'map', label: `Opening map: ${actionData} 🗺️`, query: actionData,
          url: `https://www.google.com/maps/search/${encodeURIComponent(actionData)}`,
          appUrl: `comgooglemaps://?q=${encodeURIComponent(actionData)}`, icon: '🗺️',
        })
        break
      }
      case 'play': {
        const playQuery = actionData.trim()
        actions.push({
          type: 'play', label: `Playing: ${playQuery} 🎵`, query: playQuery,
          url: `https://www.youtube.com/results?search_query=${encodeURIComponent(playQuery)}`,
          appUrl: `vnd.youtube://search?q=${encodeURIComponent(playQuery)}`, icon: '🎵',
        })
        break
      }
      case 'note': {
        actions.push({ type: 'note', label: 'Note saved 📝', data: actionData, icon: '📝' })
        break
      }
      case 'generate_image': {
        actions.push({ type: 'generate_image', label: `Generating image: ${actionData} 🎨`, data: actionData, icon: '🎨' })
        break
      }
    }
    cleanText = cleanText.replace(fullMatch, '')
  }

  cleanText = cleanText.replace(/\s{2,}/g, ' ').trim()
  return { cleanText, actions }
}

// Build action prompt block with contacts info
export function getActionPromptBlock(contacts?: { name: string; number: string }[]): string {
  const appList = Object.entries(APP_REGISTRY)
    .filter(([_, app]) => app.webUrl)
    .map(([key, app]) => `${app.icon} ${key}`)
    .join(', ')

  let contactsBlock = ''
  if (contacts && contacts.length > 0) {
    contactsBlock = `
USER'S CONTACTS (Prime Contacts):
${contacts.map(c => `- "${c.name}" → ${c.number}`).join('\n')}

When the user says "message mummy", "call papa", "WhatsApp bhai" etc., use the EXACT contact name from above in the action tag.
For WhatsApp messages to a contact: [ACTION:whatsapp|contact:name|message]
For calls to a contact: [ACTION:call|contact:name]
For SMS to a contact: [ACTION:sms|contact:name|message]
If a contact name is not found, tell the user to add it in Settings > Prime Contacts.`
  }

  return `
TASK EXECUTION — You can EXECUTE real actions for the user! When the user asks you to DO something, respond with BOTH text AND an action tag.

Available apps (can be opened directly): ${appList}

Available actions:
1. [ACTION:open|appname] — Open ANY app. Supports 100+ apps including games, browsers, camera, settings, and more!
2. [ACTION:search|query] — Search Google
3. [ACTION:message|name_or_number|text] — Send a message to anyone via WhatsApp
4. [ACTION:whatsapp|name_or_number|text] — Same as message
5. [ACTION:call|contact_name_or_number] — Call someone
6. [ACTION:sms|contact_name_or_number|text] — Send SMS
7. [ACTION:email|email@address|subject|body] — Send email via Gmail
8. [ACTION:timer|seconds] — Set a timer
9. [ACTION:map|place] — Open Google Maps
10. [ACTION:play|song name] — Play music on YouTube (DO NOT combine with open|youtube)
11. [ACTION:note|text] — Save a note
12. [ACTION:generate_image|description] — Generate an AI image from a text description. Use when user asks to create, draw, make, or generate a picture/image/drawing/artwork. The description should be detailed and in English for best results.

NATURAL RESPONSE PATTERNS for opening apps:
- "Opening Instagram... 📸" / "Instagram khol rahi hoon! 📸"
- "Launching YouTube now... 🎬" / "YouTube chala rahi hoon! 🎬"
- "Starting WhatsApp... 💬" / "WhatsApp khol rahi hoon! 💬"
- "Opening Chrome... 🌐" / "Chrome khol rahi hoon! 🌐"

IMPORTANT RULES:
- ALWAYS include an action tag when the user asks you to DO something
- Include action tags at the END of your response
- You can include MULTIPLE action tags per response
- DO NOT combine [ACTION:open|youtube] with [ACTION:play|...] — play already opens YouTube!
- CRITICAL: When user says "open karo", "kholo", "chalao", "avvi", "karo", "launch", "start" with an app name, use [ACTION:open|appname] ONLY
- ONE action per intent. "YouTube karo" = [ACTION:open|youtube]. That's it.
- Gujarati: "kholo", "avvi", "joye", "ondh karo", "chalu karo" all mean "open/launch"
- If the app name is not in the list, still use [ACTION:open|appname] — the system will try fuzzy matching
${contactsBlock}

EXAMPLES:
"YouTube open karo" → "YouTube khol rahi hoon! 🎬 [ACTION:open|youtube]"
"Instagram kholo" → "Opening Instagram... 📸 [ACTION:open|instagram]"
"Launch Chrome" → "Launching Chrome now... 🌐 [ACTION:open|chrome]"
"Open BGMI" → "Opening BGMI... 🎮 [ACTION:open|pubg]"
"Free Fire chalao" → "Free Fire chala rahi hoon! 🔥 [ACTION:open|freefire]"
"Camera kholo" → "Camera khol rahi hoon! 📷 [ACTION:open|camera]"
"Settings open karo" → "Settings khol rahi hoon! ⚙️ [ACTION:open|settings]"
"Mummy ko WhatsApp karo hello" → "Mummy ko WhatsApp pe message kar rahi hoon! 💬 [ACTION:whatsapp|contact:mummy|hello]"
"Swiggy kholo aur YouTube pe gana chalao" → "Dono kar rahi hoon! 🍔🎵 [ACTION:open|swiggy] [ACTION:play|trending songs]"
"Zoom meeting kholo" → "Zoom khol rahi hoon! 📹 [ACTION:open|zoom]"
"Canva open karo" → "Canva khol rahi hoon! 🎨 [ACTION:open|canva]"
"Ek cat ki photo banao" → "Cat ki photo bana rahi hoon! 🎨 [ACTION:generate_image|a cute cat sitting on a windowsill, soft sunlight, detailed, high quality]"
"Draw a sunset" → "Sunset draw kar rahi hoon! 🎨 [ACTION:generate_image|beautiful sunset over the ocean, golden and orange sky, dramatic clouds, high quality]"
"Make an image of a mountain" → "Mountain ki image bana rahi hoon! 🎨 [ACTION:generate_image|majestic snow-capped mountain landscape, clear blue sky, reflection in lake, detailed, high quality]"

"Hello, kaise ho?" → "Main bilkul theek hoon! Bolo kya help chahiye? 😊" (NO action for normal chat)
`
}

// Client-side fallback action detector — works even if AI doesn't generate action tags
export function detectActionsFromText(userText: string, contacts?: { name: string; number: string }[]): NexaAction[] {
  const actions: NexaAction[] = []
  const text = userText.toLowerCase().trim()

  if (text.length < 3) return actions

  // CONVERSATIONAL GUARD: If the message is clearly conversational, return NO actions
  // This prevents "what is your name" from opening Google or any app
  if (isConversationalMessage(userText)) return []

  // Detect "play music/song" intent (before "open" to avoid duplicate)
  const playPatterns = [
    /(?:play|chala[ow]|chalao|bajao|bajwa|sunao|gaana?|song|gana)\s+(.+)/i,
    /(?:youtube\s+pe|youtube\s+me|youtube\s+par)\s+(?:gana|song|music|chala[ow])/i,
    /(?:gana|song|music)\s+(?:chalao|play|chala[ow])/i,
  ]
  let playDetected = false
  for (const pattern of playPatterns) {
    const match = text.match(pattern)
    if (match) {
      const query = match[1] || 'trending songs'
      actions.push({
        type: 'play', label: `Playing: ${query} 🎵`, query,
        url: `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`,
        appUrl: `vnd.youtube://search?q=${encodeURIComponent(query)}`, icon: '🎵',
      })
      playDetected = true
      break
    }
  }

  // ===== MESSAGING INTENTS =====
  const messagePatterns = [
    /(?:whatsapp|wa)\s+(?:pe|par|se|karo|message|msg|bhejo)\s+(.+)/i,
    /(?:message|msg|bhejo|bhej|text)\s+(?:karo\s+)?(.+?)\s+(?:ko|k)\s+(.+)/i,
    /(.+?)\s+ko\s+(?:whatsapp|message|msg|bhejo|bhej|sms)\s*(?:karo\s*)?(.+)/i,
    /(.+?)\s+ko\s+(?:message|msg|bhejo|bhej)\s+(?:karo\s+)?(.+)/i,
  ]
  for (const pattern of messagePatterns) {
    const match = text.match(pattern)
    if (match) {
      let target = ''
      let message = ''
      if (pattern === messagePatterns[0]) {
        target = match[1] || ''
      } else {
        target = match[1] || ''
        message = match[2] || ''
      }
      const resolved = resolveContact(target, contacts)
      if (resolved.number) {
        actions.push({
          type: 'message', label: `Message ${resolved.name || resolved.number} 💬`,
          url: buildWhatsAppUrl(resolved.number, message),
          appUrl: `whatsapp://send?phone=${resolved.number}${message ? `&text=${encodeURIComponent(message)}` : ''}`,
          data: message, contactName: resolved.name, number: resolved.number, icon: '💬',
        })
      } else {
        actions.push({ type: 'message', label: `Opening WhatsApp 💬`, url: 'https://web.whatsapp.com', appUrl: 'whatsapp://', icon: '💬' })
      }
      break
    }
  }

  // Detect "email/mail karo" intent
  const emailPatterns = [
    /(?:email|mail|e-mail|imeil)\s+(?:karo|bhejo|send)\s+(.+)/i,
    /(.+?)\s+ko\s+(?:email|mail)\s+(?:karo\s+)?(.+)/i,
    /(?:email|mail)\s+(?:karo\s+)?(.+?@.+?\.\w+)\s*(.*)/i,
  ]
  for (const pattern of emailPatterns) {
    const match = text.match(pattern)
    if (match) {
      const emailAddr = match[1]?.includes('@') ? match[1] : ''
      const emailSubject = match[2] || ''
      if (emailAddr) {
        actions.push({ type: 'email', label: `Email to ${emailAddr} 📧`, url: buildGmailUrl(emailAddr, emailSubject, ''), appUrl: `mailto:${emailAddr}?subject=${encodeURIComponent(emailSubject)}`, email: emailAddr, icon: '📧' })
      } else {
        actions.push({ type: 'open', label: 'Opening Gmail 📧', url: 'https://mail.google.com', appUrl: 'googlegmail://', icon: '📧' })
      }
      break
    }
  }

  // ===== SMART APP DETECTION WITH FUZZY MATCHING =====
  const openKeywords = ['open', 'kholo', 'khol', 'chalu', 'chalao', 'start', 'launch', 'chala', 'on kar', 'kholo.', 'kholo!', 'khol do', 'kholade', 'kholo do', 'chalu kar', 'chala do', 'ondh kar', 'ondh karo', 'khol avu', 'kholo avu', 'chalu karavo', 'karo', 'kar', 'avvi', 'ondh', 'jovi', 'joye', 'chalaav', 'chalav', 'suru', 'suru kar', 'bandh karo', 'on karo', 'chalu karo', 'run', 'execute']
  const hasOpenKeyword = openKeywords.some(kw => text.includes(kw))
  const appNames = Object.keys(APP_REGISTRY)

  // PASS 1: Exact app name match WITH open keyword
  if (hasOpenKeyword) {
    for (const appKey of appNames) {
      const app = APP_REGISTRY[appKey]
      const appNameWords = appKey.toLowerCase().split(/\s+/)
      const appMentioned = appNameWords.every(word => text.includes(word))
      if (!appMentioned) continue
      if (appKey === 'youtube' && playDetected) continue
      if (appKey === 'whatsapp' && actions.some(a => a.type === 'message' || a.type === 'whatsapp')) continue
      if (app.webUrl) {
        const alreadyAdded = actions.some(a => a.type === 'open' && (a.url === app.webUrl || a.label.includes(app.name)))
        if (!alreadyAdded) {
          actions.push({
            type: 'open', label: `Opening ${app.name} ${app.icon}`, url: app.webUrl, appUrl: app.appUrl,
            icon: app.icon, category: app.category, packageName: app.packageName,
          })
        }
        break
      }
    }
  }

  // PASS 2: Short text = assume open intent ("youtube", "instagram")
  if (!actions.some(a => a.type === 'open')) {
    for (const appKey of appNames) {
      const app = APP_REGISTRY[appKey]
      const appNameWords = appKey.toLowerCase().split(/\s+/)
      const appMentioned = appNameWords.every(word => text.includes(word))
      if (!appMentioned) continue
      if (appKey === 'youtube' && playDetected) continue
      if (appKey === 'whatsapp' && actions.some(a => a.type === 'message' || a.type === 'whatsapp')) continue
      const isJustAppName = text.trim() === appKey || (text.length < 25 && appMentioned)
      if (isJustAppName && app.webUrl) {
        const alreadyAdded = actions.some(a => a.type === 'open' && (a.url === app.webUrl || a.label.includes(app.name)))
        if (!alreadyAdded) {
          actions.push({
            type: 'open', label: `Opening ${app.name} ${app.icon}`, url: app.webUrl, appUrl: app.appUrl,
            icon: app.icon, category: app.category, packageName: app.packageName,
          })
        }
        break
      }
    }
  }

  // PASS 3: FUZZY MATCHING — try to match with typos/similar names
  if (!actions.some(a => a.type === 'open') && hasOpenKeyword) {
    // Extract the app name from the text (remove open keywords)
    let appQuery = text
    for (const kw of openKeywords) {
      appQuery = appQuery.replace(kw, '').trim()
    }
    appQuery = appQuery.replace(/\s+/g, ' ').trim()
    if (appQuery.length >= 2) {
      const fuzzyMatches = findApps(appQuery)
      if (fuzzyMatches.length > 0) {
        const best = fuzzyMatches[0]
        // If multiple good matches, include them for selection UI
        const matches = fuzzyMatches.slice(0, 3)
        actions.push({
          type: 'open', label: `Opening ${best.name} ${best.icon}`, url: best.webUrl, appUrl: best.appUrl,
          icon: best.icon, category: best.category, packageName: best.packageName,
          matches: matches.length > 1 ? matches : undefined,
        })
      } else {
        // App not found — show search suggestion
        actions.push({
          type: 'appnotfound', label: `App not found: ${appQuery}`,
          query: appQuery, url: `https://www.google.com/search?q=${encodeURIComponent(appQuery + ' app download')}`,
          icon: '❓', data: appQuery,
        })
      }
    }
  }

  // Detect "search" intent
  // IMPORTANT: "what is X" is NOT a search — it's a conversational question!
  // Only match when user EXPLICITLY says "search", "google", "dhundho", etc.
  const searchPatterns = [
    /(?:search|search karo|dhundho|dhundo|find|look up|google)\s+(?:for\s+|karke\s+)?(.+)/i,
  ]
  for (const pattern of searchPatterns) {
    const match = text.match(pattern)
    if (match && match[1]) {
      const query = match[1].trim()
      if (query.length > 2) {
        actions.push({ type: 'search', label: `Searching: ${query} 🔍`, query, url: `https://www.google.com/search?q=${encodeURIComponent(query)}`, icon: '🔍' })
        break
      }
    }
  }

  // Detect "timer" intent
  const timerPatterns = [
    /(\d+)\s*(?:min|minute|minutes|मिनट)\s*(?:ka|ki|ke|ka|timer|set|lagao)/i,
    /timer\s*(?:set|lagao|lagana)\s*(\d+)/i,
    /(\d+)\s*(?:min|minute)\s*(?:timer|ka\s*timer)/i,
  ]
  for (const pattern of timerPatterns) {
    const match = text.match(pattern)
    if (match && match[1]) {
      const minutes = parseInt(match[1], 10)
      if (minutes > 0 && minutes <= 1440) {
        actions.push({ type: 'timer', label: `Timer: ${minutes} min ⏱️`, seconds: minutes * 60, icon: '⏱️' })
        break
      }
    }
  }
  const secMatch = text.match(/(\d+)\s*(?:sec|second|seconds)\s*(?:timer|ka|set)/i)
  if (secMatch && secMatch[1]) {
    const secs = parseInt(secMatch[1], 10)
    if (secs > 0 && secs <= 3600) {
      actions.push({ type: 'timer', label: `Timer: ${secs}s ⏱️`, seconds: secs, icon: '⏱️' })
    }
  }

  // Detect "call" intent
  const callMatch = text.match(/(?:call|coll|phone|fone|कॉल)\s+(?:karo\s+)?(.+)/i)
  if (callMatch && callMatch[1]) {
    const target = callMatch[1].trim()
    const found = contacts?.find(c => target.includes(c.name.toLowerCase()) || c.name.toLowerCase().includes(target))
    if (found) {
      actions.push({ type: 'call', label: `Calling ${found.name} 📞`, url: `tel:${found.number}`, appUrl: `tel:${found.number}`, contactName: found.name, number: found.number, icon: '📞' })
    }
  }

  // Detect "map" intent
  const mapMatch = text.match(/(?:map|maps|location| Jagah|darshao|dikao|dikhao)\s+(.+)/i)
  if (mapMatch && mapMatch[1]) {
    const place = mapMatch[1].trim()
    actions.push({ type: 'map', label: `Map: ${place} 🗺️`, query: place, url: `https://www.google.com/maps/search/${encodeURIComponent(place)}`, appUrl: `comgooglemaps://?q=${encodeURIComponent(place)}`, icon: '🗺️' })
  }

  // Detect "generate image" intent — draw/make/create/banao a photo/image/picture/drawing
  const imagePatterns = [
    /(?:draw|banao|banavo|banava|create|make|generate|generate_image|generate karo|photo banao|image banao|picture banao|drawing banao|chitra banao|tasveer banao|foto banao)\s+(?:ek\s+|a\s+|the\s+)?(?:photo|image|picture|drawing|art|artwork|chitra|tasveer|foto)\s+(?:of|banao|ke|ki|ka|na|ni|no|ne)?\s*(.+)/i,
    /(?:draw|banao|banavo|create|make|generate)\s+(?:a\s+|an\s+|ek\s+)?(.+?)(?:\s+ka\s+photo|\s+ki\s+photo|\s+na\s+photo|\s+ka\s+image|\s+ki\s+image|\s+na\s+image|\s+ka\s+chitra|\s+ki\s+chitra|\s+na\s+chitra|\s+ka\s+picture|\s+ki\s+picture|\s+na\s+picture)$/i,
    /(?:photo|image|picture|drawing|art|artwork|chitra|tasveer|foto)\s+(?:banao|banavo|create|make|draw|generate|generate karo|banava)\s+(.+)/i,
    /(?:photo|image|picture|chitra|tasveer)\s+(?:banao|banavo|generate karo)\s*(.+)/i,
  ]
  for (const pattern of imagePatterns) {
    const match = text.match(pattern)
    if (match && match[1] && match[1].trim().length > 2) {
      const prompt = match[1].trim()
      actions.push({
        type: 'generate_image',
        label: `Generating image: ${prompt} 🎨`,
        data: prompt,
        icon: '🎨',
      })
      break
    }
  }

  return actions
}
