#!/bin/bash
cd /home/z/my-project/mini-services/gemini-ws
while true; do
  echo "Starting NEXA Gemini WS bridge..."
  bun index.ts
  echo "Process exited. Restarting in 3s..."
  sleep 3
done
