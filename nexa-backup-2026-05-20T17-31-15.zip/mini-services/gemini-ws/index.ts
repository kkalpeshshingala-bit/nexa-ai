import { createServer } from 'http'
import { Server } from 'socket.io'
import WebSocket from 'ws'

const PORT = 3003
const SESSION_RENEW_AFTER = 540 // 9 minutes
const KEEPALIVE_INTERVAL = 8000 // 8 seconds

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

interface GeminiSession {
  ws: WebSocket | null
  connected: boolean
  setupComplete: boolean
  keepaliveTimer: ReturnType<typeof setInterval> | null
  sessionTimer: ReturnType<typeof setInterval> | null
  apiKey: string
  model: string
  voice: string
  systemPrompt: string
  socketId: string
}

const sessions = new Map<string, GeminiSession>()

function createSilentPCMBase64(): string {
  // 1024 bytes of silence (512 samples of 16-bit PCM at 16kHz)
  const buffer = Buffer.alloc(1024, 0)
  return buffer.toString('base64')
}

function connectGemini(session: GeminiSession) {
  if (session.ws) {
    try { session.ws.close() } catch {}
  }

  session.connected = false
  session.setupComplete = false

  const wsUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=${session.apiKey}`
  
  console.log(`[${session.socketId}] Connecting to Gemini Live...`)
  const ws = new WebSocket(wsUrl)
  session.ws = ws

  ws.on('open', () => {
    console.log(`[${session.socketId}] Gemini WebSocket connected`)
    session.connected = true

    // Send setup message
    const setupMsg = {
      setup: {
        model: session.model,
        system_instruction: {
          parts: [{ text: session.systemPrompt }]
        },
        generation_config: {
          response_modalities: ["AUDIO"],
          speech_config: {
            voice_config: {
              prebuilt_voice_config: {
                voice_name: session.voice
              }
            }
          },
          temperature: 0.9
        },
        output_audio_transcription: {},
        input_audio_transcription: {}
      }
    }

    ws.send(JSON.stringify(setupMsg))
    console.log(`[${session.socketId}] Setup message sent`)

    // Start keepalive
    if (session.keepaliveTimer) clearInterval(session.keepaliveTimer)
    session.keepaliveTimer = setInterval(() => {
      if (session.connected && session.ws?.readyState === WebSocket.OPEN) {
        const keepaliveMsg = {
          realtime_input: {
            media_chunks: [{
              mime_type: "audio/pcm;rate=16000",
              data: createSilentPCMBase64()
            }]
          }
        }
        try {
          session.ws.send(JSON.stringify(keepaliveMsg))
        } catch {}
      }
    }, KEEPALIVE_INTERVAL)

    // Session renewal timer
    if (session.sessionTimer) clearInterval(session.sessionTimer)
    session.sessionTimer = setInterval(() => {
      console.log(`[${session.socketId}] Session renewal - reconnecting...`)
      io.to(session.socketId).emit('session-renewing')
      connectGemini(session)
    }, SESSION_RENEW_AFTER * 1000)
  })

  ws.on('message', (data: WebSocket.Data) => {
    try {
      const msg = JSON.parse(data.toString())

      // Handle setup complete
      if (msg.setupComplete) {
        session.setupComplete = true
        console.log(`[${session.socketId}] Setup complete`)
        io.to(session.socketId).emit('gemini-setup-complete')
        return
      }

      // Handle server content
      if (msg.serverContent) {
        const serverContent = msg.serverContent

        // Audio data
        if (serverContent.modelTurn?.parts) {
          for (const part of serverContent.modelTurn.parts) {
            if (part.inlineData?.data) {
              io.to(session.socketId).emit('gemini-audio', {
                data: part.inlineData.data,
                mimeType: part.inlineData.mimeType || 'audio/pcm;rate=24000'
              })
            }
          }
        }

        // Output transcription (what NEXA said)
        if (serverContent.outputTranscription?.text) {
          io.to(session.socketId).emit('gemini-output-transcript', {
            text: serverContent.outputTranscription.text
          })
        }

        // Input transcription (what user said)
        if (serverContent.inputTranscription?.text) {
          io.to(session.socketId).emit('gemini-input-transcript', {
            text: serverContent.inputTranscription.text
          })
        }

        // Turn complete
        if (serverContent.turnComplete) {
          io.to(session.socketId).emit('gemini-turn-complete')
        }
      }
    } catch (e) {
      console.error(`[${session.socketId}] Error parsing Gemini message:`, e)
    }
  })

  ws.on('error', (error) => {
    console.error(`[${session.socketId}] Gemini WebSocket error:`, error.message)
    let userMsg = error.message
    if (error.message.includes('401') || error.message.includes('403')) {
      userMsg = 'Invalid API key. Please check your Gemini API key in settings.'
    } else if (error.message.includes('ECONNREFUSED') || error.message.includes('ENOTFOUND')) {
      userMsg = 'Cannot reach Gemini servers. Check your internet connection.'
    }
    io.to(session.socketId).emit('gemini-error', { message: userMsg })
  })

  ws.on('close', (code, reason) => {
    console.log(`[${session.socketId}] Gemini WebSocket closed: code=${code}, reason=${reason.toString()}`)
    session.connected = false
    session.setupComplete = false
    if (code === 4001 || code === 1008) {
      io.to(session.socketId).emit('gemini-error', { message: 'Authentication failed. Check your API key.' })
    }
  })
}

io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`)

  const session: GeminiSession = {
    ws: null,
    connected: false,
    setupComplete: false,
    keepaliveTimer: null,
    sessionTimer: null,
    apiKey: '',
    model: 'models/gemini-2.5-flash-native-audio-preview-12-2025',
    voice: 'Aoede',
    systemPrompt: 'You are NEXA, a helpful AI assistant.',
    socketId: socket.id
  }

  sessions.set(socket.id, session)

  // Initialize Gemini connection with settings
  socket.on('gemini-init', (data: {
    apiKey: string
    model: string
    voice: string
    systemPrompt: string
  }) => {
    console.log(`[${socket.id}] Gemini init: model=${data.model}, voice=${data.voice}, hasKey=${!!data.apiKey}`)
    session.apiKey = data.apiKey
    session.model = data.model
    session.voice = data.voice
    session.systemPrompt = data.systemPrompt

    if (session.apiKey && session.apiKey.length > 5) {
      connectGemini(session)
    } else {
      console.error(`[${socket.id}] No valid API key provided`)
      socket.emit('gemini-error', { message: 'No API key provided. Open settings and add your Gemini API key.' })
    }
  })

  // Reconnect with new settings
  socket.on('gemini-reconnect', (data: {
    apiKey: string
    model: string
    voice: string
    systemPrompt: string
  }) => {
    console.log(`[${socket.id}] Gemini reconnect`)
    session.apiKey = data.apiKey
    session.model = data.model
    session.voice = data.voice
    session.systemPrompt = data.systemPrompt

    if (session.keepaliveTimer) clearInterval(session.keepaliveTimer)
    if (session.sessionTimer) clearInterval(session.sessionTimer)

    if (session.apiKey) {
      connectGemini(session)
    }
  })

  // Send audio chunk to Gemini
  socket.on('gemini-audio-send', (data: { audio: string }) => {
    if (session.connected && session.ws?.readyState === WebSocket.OPEN && session.setupComplete) {
      const msg = {
        realtime_input: {
          media_chunks: [{
            mime_type: "audio/pcm;rate=16000",
            data: data.audio
          }]
        }
      }
      try {
        session.ws.send(JSON.stringify(msg))
      } catch {}
    }
  })

  // Send text to Gemini
  socket.on('gemini-text-send', (data: { text: string }) => {
    if (session.connected && session.ws?.readyState === WebSocket.OPEN && session.setupComplete) {
      const msg = {
        client_content: {
          turns: [{
            role: "user",
            parts: [{ text: data.text }]
          }],
          turn_complete: true
        }
      }
      try {
        session.ws.send(JSON.stringify(msg))
      } catch {}
    }
  })

  // Interrupt NEXA speaking
  socket.on('gemini-interrupt', () => {
    if (session.connected && session.ws?.readyState === WebSocket.OPEN) {
      const msg = {
        client_content: {
          turns: [],
          turn_complete: true
        }
      }
      try {
        session.ws.send(JSON.stringify(msg))
      } catch {}
    }
  })

  // Disconnect
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`)
    if (session.keepaliveTimer) clearInterval(session.keepaliveTimer)
    if (session.sessionTimer) clearInterval(session.sessionTimer)
    if (session.ws) {
      try { session.ws.close() } catch {}
    }
    sessions.delete(socket.id)
  })
})

httpServer.listen(PORT, () => {
  console.log(`NEXA Gemini WebSocket bridge running on port ${PORT}`)
})

process.on('SIGTERM', () => {
  httpServer.close(() => process.exit(0))
})

process.on('SIGINT', () => {
  httpServer.close(() => process.exit(0))
})
