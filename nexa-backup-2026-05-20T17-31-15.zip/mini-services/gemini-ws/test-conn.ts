import { io } from 'socket.io-client'

const socket = io('http://127.0.0.1:3003', {
  transports: ['websocket'],
  timeout: 15000,
  path: '/',
})

socket.on('connect', () => {
  console.log('✅ Connected to bridge! ID:', socket.id)
  
  socket.emit('gemini-init', {
    apiKey: 'AIzaSyAAJ1U0HAgvtc56q8W0BOP7_aV629HkHbI',
    model: 'models/gemini-2.5-flash-native-audio-preview-12-2025',
    voice: 'Aoede',
    systemPrompt: 'You are NEXA. Say hello in one sentence.',
  })
  console.log('📤 Sent gemini-init')
})

socket.on('gemini-setup-complete', () => {
  console.log('✅ Gemini setup complete!')
  socket.emit('gemini-text-send', { text: 'Hello, say hi briefly' })
  console.log('📤 Sent test text')
})

socket.on('gemini-audio', (data) => {
  console.log('🔊 Audio chunk, size:', data.data?.length || 0)
})

socket.on('gemini-output-transcript', (data) => {
  console.log('💬 NEXA says:', data.text)
})

socket.on('gemini-turn-complete', () => {
  console.log('✅ TURN COMPLETE - FULLY WORKING!')
  setTimeout(() => { socket.disconnect(); process.exit(0) }, 500)
})

socket.on('gemini-error', (data) => {
  console.error('❌ Gemini error:', data.message)
  setTimeout(() => process.exit(1), 500)
})

socket.on('connect_error', (err) => {
  console.error('❌ Connection error:', err.message)
  process.exit(1)
})

setTimeout(() => {
  console.log('⏰ Timeout 25s')
  process.exit(1)
}, 25000)
