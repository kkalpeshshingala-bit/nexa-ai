import { io } from 'socket.io-client'

// Try with polling first, then upgrade
const socket = io('http://127.0.0.1:3003', {
  transports: ['polling', 'websocket'],
  timeout: 15000,
  path: '/',
  forceNew: true,
})

console.log('Attempting connection...')

socket.on('connect', () => {
  console.log('✅ Connected! ID:', socket.id, 'Transport:', socket.io.engine.transport.name)
  
  socket.emit('gemini-init', {
    apiKey: 'AIzaSyAAJ1U0HAgvtc56q8W0BOP7_aV629HkHbI',
    model: 'models/gemini-2.5-flash-native-audio-preview-12-2025',
    voice: 'Aoede',
    systemPrompt: 'You are NEXA. Say hello.',
  })
  console.log('📤 Sent gemini-init')
})

socket.io.on('upgrade', (transport) => {
  console.log('🔄 Upgraded to:', transport.name)
})

socket.on('gemini-setup-complete', () => {
  console.log('✅ Gemini setup complete!')
  socket.emit('gemini-text-send', { text: 'Hello' })
})

socket.on('gemini-output-transcript', (data) => {
  console.log('💬 NEXA:', data.text)
})

socket.on('gemini-turn-complete', () => {
  console.log('✅ TURN COMPLETE!')
  setTimeout(() => { socket.disconnect(); process.exit(0) }, 500)
})

socket.on('gemini-error', (data) => {
  console.error('❌ Error:', data.message)
})

socket.on('connect_error', (err) => {
  console.error('❌ Connection error:', err.message)
  setTimeout(() => process.exit(1), 500)
})

setTimeout(() => { console.log('⏰ Timeout'); process.exit(1) }, 25000)
