import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    "preview-chat-7cebd6a5-e823-4b3f-bc2b-e46ea0080048.space-z.ai",
    ".space-z.ai",
  ],
};

export default nextConfig;
